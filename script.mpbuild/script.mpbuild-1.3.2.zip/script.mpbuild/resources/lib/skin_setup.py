# -*- coding: utf-8 -*-
"""
Skin configuration. Since Arctic Fuse 3 ships in our own repo and gets
installed by the main install flow, this module just lets users switch
between AF3 and Estuary at any time.
"""
import json

import xbmc
import xbmcgui


SKIN_AF3 = 'skin.arctic.fuse.3'
SKIN_ESTUARY = 'skin.estuary'


def _jsonrpc(method, params=None):
    body = {'jsonrpc': '2.0', 'method': method, 'id': 1}
    if params is not None:
        body['params'] = params
    raw = xbmc.executeJSONRPC(json.dumps(body))
    try:
        return json.loads(raw).get('result')
    except Exception:
        return None


def _addon_installed(addon_id):
    res = _jsonrpc('Addons.GetAddonDetails', {
        'addonid': addon_id,
        'properties': ['enabled', 'installed'],
    })
    if not res:
        return False
    addon = res.get('addon') or {}
    return bool(addon.get('installed') and addon.get('enabled'))


def _switch_to(skin_id, label):
    res = _jsonrpc('Settings.SetSettingValue', {
        'setting': 'lookandfeel.skin',
        'value': skin_id,
    })
    if res is True:
        xbmcgui.Dialog().notification(
            'MP Build', 'Switched to {0}'.format(label),
            xbmcgui.NOTIFICATION_INFO, 3000)
        return True
    xbmcgui.Dialog().ok('MP Build',
        'Could not switch automatically.[CR][CR]'
        'Try Settings > Interface > Skin manually.')
    return False


def configure():
    """Re-runnable from the MP Build menu."""
    items = [
        'Switch to Arctic Fuse 3',
        'Switch to Estuary (default Kodi)',
        'Cancel',
    ]
    idx = xbmcgui.Dialog().select('Skin Configuration', items)
    if idx < 0 or idx == 2:
        return

    if idx == 0:
        if not _addon_installed(SKIN_AF3):
            xbmcgui.Dialog().ok('MP Build',
                'Arctic Fuse 3 isn\'t installed.[CR][CR]'
                'Run "Install Build (full setup)" from the MP Build menu '
                'to install it.')
            return
        _switch_to(SKIN_AF3, 'Arctic Fuse 3')
    elif idx == 1:
        _switch_to(SKIN_ESTUARY, 'Estuary')
