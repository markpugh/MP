# -*- coding: utf-8 -*-
"""
MP Build installer.

Run from Kodi's Programs add-ons menu. Presents a menu of actions:
- Install Build (chains everything: install addons, authorize debrids, configure scrapers)
- Authorize Real Debrid
- Authorize AllDebrid
- Configure Scrapers
- Reset & Reinstall
- About

Uses the addon's resources/lib/ submodules for the actual work.
"""
import sys

import xbmc
import xbmcaddon
import xbmcgui


ADDON = xbmcaddon.Addon()
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_PATH = ADDON.getAddonInfo('path')
sys.path.insert(0, ADDON_PATH)


def _menu_loop():
    """Show the main menu repeatedly until the user picks Cancel."""
    from resources.lib import installer, debrid_setup, scraper_setup, skin_setup, about

    while True:
        items = [
            'Install Build (full setup)',
            'Authorize Real Debrid',
            'Authorize AllDebrid',
            'Configure Scrapers',
            'Configure Skins',
            'Reset & Reinstall',
            'About',
            'Exit',
        ]
        idx = xbmcgui.Dialog().select(ADDON_NAME, items)
        if idx < 0 or idx == 7:
            return
        try:
            if idx == 0:
                installer.run_full_install()
            elif idx == 1:
                debrid_setup.authorize_rd()
            elif idx == 2:
                debrid_setup.authorize_ad()
            elif idx == 3:
                scraper_setup.configure()
            elif idx == 4:
                skin_setup.configure()
            elif idx == 5:
                installer.reset_and_reinstall()
            elif idx == 6:
                about.show()
        except Exception as e:
            xbmc.log('[mpbuild] Action {0} raised: {1}'.format(idx, e), xbmc.LOGERROR)
            xbmcgui.Dialog().ok(ADDON_NAME, 'Error: {0}'.format(e))


if __name__ == '__main__':
    _menu_loop()
