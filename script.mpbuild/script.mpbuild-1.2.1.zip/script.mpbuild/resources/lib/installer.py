# -*- coding: utf-8 -*-
"""
Core installer. Drives Kodi's addon manager via JSON-RPC to install each
addon from the MP repo in dependency order, then runs follow-up steps
(auth wizards, scraper config).

Why JSON-RPC instead of executebuiltin('InstallAddon')? executebuiltin
returns immediately without telling us whether it succeeded — we'd have
no way to wait for completion or detect failure. JSON-RPC's
Addons.SetAddonEnabled and the file-system check pattern lets us verify
each step.
"""
import json
import os
import shutil
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs


# Order matters — dependencies first.
# Tuple format: (addon_id, label, required_version_or_None)
# When required_version is set, we explicitly check & uninstall any
# wrong-version copy that's already installed (e.g., an older one
# pulled from Kodi's official repo) before installing ours.
INSTALL_ORDER = [
    # Module deps for our existing playback stack
    ('script.module.resolveurl', 'ResolveURL (host resolver)', None),
    ('script.module.cocoscrapers', 'CocoScrapers (torrent scrapers)', None),
    # Module deps for TMDB Helper
    ('script.module.jurialmunkey', 'jurialmunkey common (TMDB Helper dep)', '0.2.35'),
    # Skin dependency — AF3 needs this specific version (2.2.1).
    # Kodi's official repo has 2.1.33 which is older and breaks AF3.
    ('script.skinvariables', 'Skin Variables (AF3 dep)', '2.2.1'),
    # TMDB Helper — feeds metadata + powers AF3 widgets, also our player target
    ('plugin.video.themoviedb.helper', 'TMDb Helper (widgets + metadata)', '6.15.6'),
    # Our addons
    ('plugin.video.mpsuperlite', 'MP SuperLite (playback engine)', None),
    ('plugin.video.mpsupersearch', 'MP SuperSearch (discovery UI)', None),
    # The skin last — it'll pull texturemaker + font/image resources from
    # Kodi's official repo automatically since we set unknownsources=true
    # and addons.allow.any.repo.update=true.
    ('skin.arctic.fuse.3', 'Arctic Fuse 3 (skin)', '3.2.9'),
]


# Dead/stale repos we want to clean up if a previous install attempt left them.
ORPHAN_REPOS = [
    'repository.jurialmunkey',  # We don't use this anymore — bundled in our repo
]


# Default settings to apply post-install. Per-addon-id, key->value.
DEFAULT_SETTINGS = {
    'plugin.video.mpsuperlite': {
        'cached_only': 'false',
        'auto_play': 'true',
        'prefer_hevc': 'true',
        'debrid_priority': '0',   # RD-first
        'max_attempts': '10',
        'max_size': '3',          # 12GB cap
        'quality_max': '1',       # 1080p
    },
    'plugin.video.mpsupersearch': {},
    'script.module.cocoscrapers': {
        'debug.enabled': 'true',
        'debug.location': '0',
    },
    'plugin.video.themoviedb.helper': {
        # Same default TMDB key SuperLite + SuperSearch use — saves the
        # user from having to register one. Friends installing the build
        # don't need to know what an API key is.
        'tmdb_apikey': '9b6d253a9ec18f3c1cab46a7b831de1a',
    },
}


# Active skin to switch to after install. Set to None to leave Kodi on Estuary.
ACTIVE_SKIN_ID = 'skin.arctic.fuse.3'


def _jsonrpc(method, params=None):
    """Call Kodi's JSON-RPC API. Returns parsed result dict, or None on error."""
    body = {'jsonrpc': '2.0', 'method': method, 'id': 1}
    if params is not None:
        body['params'] = params
    raw = xbmc.executeJSONRPC(json.dumps(body))
    try:
        return json.loads(raw).get('result')
    except Exception:
        xbmc.log('[mpbuild] JSON-RPC parse fail: {0}'.format(raw), xbmc.LOGERROR)
        return None


def _addon_installed(addon_id):
    """True if Kodi knows about this addon (installed and enabled)."""
    res = _jsonrpc('Addons.GetAddonDetails', {
        'addonid': addon_id,
        'properties': ['enabled', 'installed', 'version'],
    })
    if not res:
        return False
    addon = res.get('addon') or {}
    return bool(addon.get('installed') and addon.get('enabled'))


def _addon_installed_version(addon_id):
    """Returns the installed version string, or None if not installed."""
    res = _jsonrpc('Addons.GetAddonDetails', {
        'addonid': addon_id,
        'properties': ['enabled', 'installed', 'version'],
    })
    if not res:
        return None
    addon = res.get('addon') or {}
    if not (addon.get('installed') and addon.get('enabled')):
        return None
    return addon.get('version')


def _uninstall_addon(addon_id):
    """Best-effort uninstall."""
    xbmc.log('[mpbuild] uninstalling {0}...'.format(addon_id), xbmc.LOGINFO)
    xbmc.executebuiltin('UninstallAddon({0},true)'.format(addon_id), wait=True)
    # Wait a beat for the uninstall to complete
    deadline = time.time() + 10
    while time.time() < deadline:
        if not _addon_installed(addon_id):
            return True
        xbmc.sleep(500)
    return False


def _force_install_from_repo_zip(addon_id, expected_version):
    """
    Bypass Kodi's repo resolution and install the addon directly from
    OUR local repo zip. Used when we know the repo we ship has the
    specific version a downstream addon needs, and Kodi's default
    InstallAddon would pick a wrong version from elsewhere.

    The zip lives at: special://home/addons/repository.rolotech/...
    No, actually it's served via HTTP from your GitHub Pages URL.
    Easiest path: tell Kodi to install via UpdateAddonRepos (force
    refresh) then InstallAddon, but constrain by uninstalling whatever
    older version is currently there.
    """
    current = _addon_installed_version(addon_id)
    if current and current != expected_version:
        xbmc.log('[mpbuild] {0} v{1} installed, need v{2} — replacing'.format(
            addon_id, current, expected_version), xbmc.LOGINFO)
        _uninstall_addon(addon_id)
        # Force Kodi to refresh repo metadata so it sees the new version
        xbmc.executebuiltin('UpdateAddonRepos', wait=True)
        xbmc.sleep(2000)

    return _install_addon(addon_id)


def _install_addon(addon_id, progress=None, current_pct=0):
    """
    Install an addon by ID. The addon must be available in a configured
    repository (we pre-add the MP repo so anything in there resolves).

    Returns True on success.
    """
    # Already installed? skip.
    if _addon_installed(addon_id):
        xbmc.log('[mpbuild] {0} already installed'.format(addon_id), xbmc.LOGINFO)
        return True

    if progress:
        try:
            progress.update(current_pct, 'Installing {0}...'.format(addon_id))
        except Exception:
            pass

    xbmc.executebuiltin('InstallAddon({0})'.format(addon_id), wait=True)

    # Poll for installation up to 90s (skins take longer with all their deps)
    deadline = time.time() + 90
    while time.time() < deadline:
        if _addon_installed(addon_id):
            xbmc.log('[mpbuild] {0} installed OK'.format(addon_id), xbmc.LOGINFO)
            return True
        xbmc.sleep(1500)

    xbmc.log('[mpbuild] {0} install timeout'.format(addon_id), xbmc.LOGERROR)
    return False


def _disable_unknown_sources_warning():
    """
    Set Kodi's general settings to skip the "unknown sources" prompt and
    allow updates from any repository.

    Kodi 21 settings:
      - addons.unknownsources : true     (allows installs from non-official repos)
      - addons.updatemode : 0            (0 = update from any repo, not just official)
      - general.addonnotifications : false (no toast spam)
    """
    _jsonrpc('Settings.SetSettingValue', {
        'setting': 'addons.unknownsources',
        'value': True,
    })
    _jsonrpc('Settings.SetSettingValue', {
        'setting': 'addons.updatemode',
        'value': 0,
    })
    _jsonrpc('Settings.SetSettingValue', {
        'setting': 'general.addonnotifications',
        'value': False,
    })


def _apply_default_settings():
    """Walk DEFAULT_SETTINGS and apply each via xbmcaddon."""
    for addon_id, settings in DEFAULT_SETTINGS.items():
        if not settings:
            continue
        try:
            addon = xbmcaddon.Addon(addon_id)
        except Exception:
            xbmc.log('[mpbuild] cant get addon {0} for settings'.format(addon_id),
                     xbmc.LOGWARNING)
            continue
        for key, value in settings.items():
            try:
                addon.setSetting(key, value)
            except Exception as e:
                xbmc.log('[mpbuild] failed setting {0}.{1}={2}: {3}'.format(
                    addon_id, key, value, e), xbmc.LOGWARNING)


def run_full_install():
    """Main flow: confirm -> prep -> install all -> auth -> configure scrapers -> done."""
    # Splash first — branded welcome before the install dialog
    try:
        from resources.lib import splash
        splash.show(duration_seconds=2.5)
    except Exception as e:
        xbmc.log('[mpbuild] splash display failed (non-fatal): {0}'.format(e),
                 xbmc.LOGWARNING)

    yes = xbmcgui.Dialog().yesno(
        'MP Build Installer',
        'This will install:[CR]'
        '  - ResolveURL + CocoScrapers (scrapers)[CR]'
        '  - TMDb Helper (widgets + metadata)[CR]'
        '  - MP SuperLite (playback)[CR]'
        '  - MP SuperSearch (discovery)[CR]'
        '  - Arctic Fuse 3 (skin)[CR][CR]'
        'Then optionally walk you through Real Debrid and AllDebrid '
        'authorization, configure scraper providers, and switch to the '
        'Arctic Fuse 3 skin.[CR][CR]'
        'Continue?',
        yeslabel='Install', nolabel='Cancel')
    if not yes:
        return

    progress = xbmcgui.DialogProgress()
    progress.create('MP Build Installer', 'Preparing...')

    try:
        # Step 1: clear UX hurdles
        progress.update(5, 'Configuring Kodi addon settings...')
        _disable_unknown_sources_warning()

        # Step 1b: clean up orphan repos from previous install attempts
        for orphan_id in ORPHAN_REPOS:
            if _addon_installed(orphan_id):
                xbmc.log('[mpbuild] removing orphan repo {0}'.format(orphan_id),
                         xbmc.LOGINFO)
                _uninstall_addon(orphan_id)

        # Force a repo metadata refresh so Kodi sees the latest from our repo
        progress.update(8, 'Refreshing repository metadata...')
        xbmc.executebuiltin('UpdateAddonRepos', wait=True)
        xbmc.sleep(2000)

        # Step 2: install each addon in order
        total = len(INSTALL_ORDER)
        for i, entry in enumerate(INSTALL_ORDER):
            # Backwards compat: accept old 2-tuples
            if len(entry) == 2:
                addon_id, label = entry
                required_version = None
            else:
                addon_id, label, required_version = entry

            if progress.iscanceled():
                progress.close()
                xbmcgui.Dialog().ok('MP Build', 'Installation cancelled.')
                return
            pct = 10 + int(60 * i / total)
            progress.update(pct,
                            'Installing {0}...[CR]({1}/{2})'.format(label, i + 1, total))

            if required_version:
                ok = _force_install_from_repo_zip(addon_id, required_version)
            else:
                ok = _install_addon(addon_id, progress=progress, current_pct=pct)

            if not ok:
                progress.close()
                xbmcgui.Dialog().ok('MP Build',
                    'Failed to install {0}.[CR][CR]Make sure the MP repository '
                    'is added and try again.'.format(label))
                return

        # Step 3: apply default settings
        progress.update(75, 'Applying default settings...')
        _apply_default_settings()

        # Step 3b: drop the TMDB Helper player JSON so SuperLite handles
        # all play actions originating from TMDB Helper (= the AF3 widgets).
        progress.update(80, 'Wiring TMDB Helper to SuperLite...')
        _install_tmdbhelper_player()

        # Step 4: optional debrid auth
        progress.close()

        from resources.lib import debrid_setup
        debrid_setup.run_setup_wizard()

        # Step 5: optional scraper config
        from resources.lib import scraper_setup
        scraper_setup.run_setup_wizard()

        # Step 6: switch to Arctic Fuse 3
        if ACTIVE_SKIN_ID and _addon_installed(ACTIVE_SKIN_ID):
            yes = xbmcgui.Dialog().yesno(
                'MP Build',
                'Switch to Arctic Fuse 3 skin now?[CR][CR]'
                'You can switch back to Estuary later from '
                'Settings > Interface > Skin.',
                yeslabel='Switch', nolabel='Keep Estuary')
            if yes:
                _switch_to_skin(ACTIVE_SKIN_ID)

        # Done
        xbmcgui.Dialog().ok(
            'MP Build',
            'Setup complete![CR][CR]'
            'Launch MP SuperSearch from the home screen, or click any '
            'movie in Arctic Fuse 3 widgets to play through SuperLite.[CR][CR]'
            'To re-run any of these steps, launch MP Build from Programs.')

    finally:
        try:
            progress.close()
        except Exception:
            pass


def _install_tmdbhelper_player():
    """
    Drop the SuperLite player JSON into TMDB Helper's userdata so it
    becomes the default player for movies and episodes initiated from
    AF3 widgets, search results, etc.

    Source file: <our addon>/resources/configs/tmdbhelper_players/<file>.json
    Target: <Kodi profile>/addon_data/plugin.video.themoviedb.helper/players/<file>.json
    """
    try:
        addon = xbmcaddon.Addon()
        src = os.path.join(addon.getAddonInfo('path'), 'resources', 'configs',
                           'tmdbhelper_players', 'plugin.video.mpsuperlite.json')
        if not os.path.isfile(src):
            xbmc.log('[mpbuild] player JSON missing at {0}'.format(src),
                     xbmc.LOGWARNING)
            return False

        dst_dir = xbmcvfs.translatePath(
            'special://profile/addon_data/plugin.video.themoviedb.helper/players/')
        if not os.path.isdir(dst_dir):
            os.makedirs(dst_dir, exist_ok=True)
        dst = os.path.join(dst_dir, 'plugin.video.mpsuperlite.json')
        shutil.copyfile(src, dst)
        xbmc.log('[mpbuild] dropped SuperLite player JSON at {0}'.format(dst),
                 xbmc.LOGINFO)
        return True
    except Exception as e:
        xbmc.log('[mpbuild] failed to install player JSON: {0}'.format(e),
                 xbmc.LOGERROR)
        return False


def _switch_to_skin(skin_id):
    """Set Kodi's active skin via JSON-RPC."""
    res = _jsonrpc('Settings.SetSettingValue', {
        'setting': 'lookandfeel.skin',
        'value': skin_id,
    })
    if res is True:
        xbmcgui.Dialog().notification(
            'MP Build', 'Switched to Arctic Fuse 3',
            xbmcgui.NOTIFICATION_INFO, 3000)
        return True
    return False


def reset_and_reinstall():
    """Uninstall everything MP and start over."""
    yes = xbmcgui.Dialog().yesno(
        'MP Build Reset',
        'This will UNINSTALL MP SuperLite, MP SuperSearch, ResolveURL, '
        'and CocoScrapers, then reinstall fresh.[CR][CR]'
        'Your debrid credentials and settings will be LOST.[CR][CR]Continue?',
        yeslabel='Reset', nolabel='Cancel')
    if not yes:
        return

    # Uninstall in REVERSE dependency order
    for entry in reversed(INSTALL_ORDER):
        addon_id = entry[0]
        try:
            xbmc.executebuiltin('UninstallAddon({0},true)'.format(addon_id), wait=True)
        except Exception as e:
            xbmc.log('[mpbuild] uninstall {0}: {1}'.format(addon_id, e), xbmc.LOGWARNING)

    xbmc.sleep(1500)
    run_full_install()
