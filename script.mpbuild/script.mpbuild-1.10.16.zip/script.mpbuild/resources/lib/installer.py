# -*- coding: utf-8 -*-
"""
Core installer. Drives Kodi's addon manager via JSON-RPC to install each
addon from the MP repo in dependency order, then runs follow-up steps
(auth wizards, scraper config).

Why JSON-RPC instead of executebuiltin('InstallAddon')? executebuiltin
returns immediately without telling us whether it succeeded — we'd have
no way to wait for completion or detect failure. JSON-RPC's
Addons.SetAddonEnabled and the file-system check pattern lets us verify
each step.
"""
import io
import json
import os
import shutil
import time
import zipfile

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

import requests


# Base URL of our GitHub Pages repo. All zips live under this.
REPO_BASE_URL = 'https://markpugh.github.io/MP'


# Order matters — dependencies first.
# Tuple format: (addon_id, label, install_method, version_or_None)
#
# install_method options:
#   'direct'      = download zip from our repo and extract to addons/.
#                   Bypasses Kodi's repo-resolution. Use for any addon
#                   where Kodi might pick a wrong version from xbmc.org.
#   'installaddon'= use Kodi's InstallAddon(id) builtin. Use for addons
#                   that exist only in our repo, OR for resource addons
#                   that exist only in xbmc.org's official repo.
#
INSTALL_ORDER = [
    # --- Module deps for our existing playback stack ---
    # ResolveURL stays as installaddon (one user prompt) because it
    # requires script.module.six and script.module.kodi-six, which
    # aren't bundled in our repo. installaddon's dep resolver pulls
    # them silently from the Kodi official repo. The user sees ONE
    # "Install ResolveURL?" confirmation; the six/kodi-six pulls
    # happen behind it with no extra prompts.
    ('script.module.resolveurl', 'ResolveURL (host resolver)',
        'installaddon', None),
    # CocoScrapers needs requests, which is already installed as one
    # of MP Build's own deps — direct install works.
    ('script.module.cocoscrapers', 'CocoScrapers (torrent scrapers)',
        'direct', '1.0.32'),

    # --- Pinned deps that Kodi tends to mis-resolve from official repo ---
    # We pin these to specific versions and direct-extract the zip from
    # our repo. No reliance on Kodi's repo selection.
    ('script.module.jurialmunkey', 'jurialmunkey common',
        'direct', '0.2.35'),
    # NOTE: script.skinvariables + script.texturemaker were Arctic Fuse 3
    # dependencies only. The build now ships its own skin (skin.mp, an
    # Estuary fork) which needs neither, so they are no longer installed.

    # --- TMDb Helper's transitive deps (v1.5.4) ---
    # These three modules live in jurialmunkey's own repo, NOT in
    # repository.xbmc.org. Kodi's auto-resolve doesn't find them when
    # TMDb Helper installs, so TMDb Helper boots, fails to import
    # `infotagger`, crashes its service, and the entire AF3 widget
    # system goes silent. Installing them BEFORE TMDb Helper makes the
    # imports succeed and the service starts cleanly.
    ('script.module.infotagger', 'InfoTagger (TMDbH dep)',
        'direct', '0.0.8'),
    ('script.module.addon.signals', 'AddonSignals (TMDbH dep)',
        'direct', '0.0.6+matrix.1'),
    ('script.module.qrcode', 'QRCode (TMDbH dep)',
        'direct', '6.1.0+matrix.3'),

    ('plugin.video.themoviedb.helper', 'TMDb Helper (widgets + metadata)',
        'direct', '6.15.6'),

    # Up Next (service.upnext) retired in mpbuild 1.10.7: MP SuperLite now
    # ships its own next-episode card, so the external add-on is no longer
    # installed, and _retire_addons() disables any copy left behind.

    # --- Resource packs (weather icons + studio logos) ---
    # Kept from the previous (AF3-based) builds. They are small, harmless
    # image resource add-ons that TMDb Helper / skins can draw on; skin.mp
    # itself doesn't require them.
    ('resource.images.weathericons.white', 'Weather icons',
        'direct', '0.0.6'),
    ('resource.images.studios.coloured', 'Studio logos',
        'direct', '0.0.23'),

    # --- Our addons ---
    # Direct-install (silent). Pinned to versions in our repo.
    ('plugin.video.mpsuperlite', 'MP SuperLite (playback engine)',
        'direct', '0.9.0'),
    ('plugin.video.mpsupersearch', 'MP SuperSearch (discovery UI)',
        'direct', '1.8.2'),
    ('script.mp.trailerfinder', 'MP Trailer Finder (YouTube trailers)',
        'direct', '0.2.2'),
    # YouTube addon is required by MP Trailer Finder. Lives in Kodi's
    # main repo, not ours. Stays as installaddon — this is the ONE place
    # the user will still see a Kodi-level install prompt. Users still
    # need to sign in to enable playback (handled outside the wizard
    # since OAuth requires browser interaction).
    ('plugin.video.youtube', 'YouTube (for trailer playback)',
        'installaddon', None),

    # --- Subtitles ---
    # a4kSubtitles — the best current multi-provider subtitle service
    # (OpenSubtitles, Podnapisi, BSPlayer, etc.). Needs script.module.requests,
    # which is already present (MP Build depends on it). Direct-install from
    # our repo; set as the default subtitle service in _configure_subtitles().
    ('service.subtitles.a4ksubtitles', 'a4kSubtitles (subtitles)',
        'direct', '3.24.2'),

    # --- The skin, last ---
    # skin.mp is the build's own skin: a rebranded fork of Kodi's Estuary
    # (Omega) with a comic-book look and a branded home that boots straight
    # into MP SuperSearch. Self-contained (only needs xbmc.gui), so by the
    # time we get here it registers and enables cleanly.
    ('skin.mp', 'MP (skin)',
        'direct', '1.1.9'),
]


# Dead/stale repos we want to clean up if a previous install attempt left them.
ORPHAN_REPOS = [
    'repository.jurialmunkey',
]


# Default settings to apply post-install. Per-addon-id, key->value.
DEFAULT_SETTINGS = {
    'plugin.video.mpsuperlite': {
        'cached_only': 'false',
        'auto_play': 'true',
        'prefer_hevc': 'true',
        'prefer_english': 'true',
        'trakt_scrobble': 'true',
        'debrid_priority': 'Real Debrid first',
        'max_attempts': '10',
        'max_size': '12 GB',
        'quality_max': '1080p',
        'upnext_enabled': 'true',
        'resume_enabled': 'true',
    },
    'plugin.video.mpsupersearch': {},
    'script.module.cocoscrapers': {
        'debug.enabled': 'true',
        'debug.location': '0',
    },
    # Deliberately empty. This used to set 'tmdb_apikey', but no such
    # setting exists in TMDb Helper 6.15.6: absent from their
    # settings.xml and referenced nowhere in their code. It bundles
    # its own TMDB key (lib/api/api_keys/tmdb.py) and never wanted one
    # from us. Writing it only produced an orphan value plus a
    # 'requested setting (tmdb_apikey) was not found' log line on every
    # read. Do not re-add it.
    # trakt_watchedindicators: the master switch for "Get watched indicators,
    # episode counts, and resume points". Ships OFF by default — with it off
    # TMDb Helper shows NO watched marks or resume points in its lists even
    # though the watches are on Trakt. The MP skin's watched badge (middle
    # finger) keys off the PlayCount this feeds, so a clean install needs it on.
    'plugin.video.themoviedb.helper': {
        'trakt_watchedindicators': 'true',
    },
    'plugin.video.youtube': {
        # Trailer playback profile. These two MUST be set together.
        #
        # MPEG-DASH off: with it on, the add-on fetches separate adaptive
        # audio and video tracks through its proxy, and an unauthenticated
        # session gets the audio track refused with HTTP 403 while video
        # still plays. Kodi's audio pipeline starves and you get a loud
        # buzz. A single muxed stream avoids the split.
        #
        # Stream selection auto: this setting is only read when DASH is
        # OFF, and its own default ("list") puts InputStream Adaptive into
        # manual-OSD selection, which auto-picks nothing. Video starts,
        # audio never does, and sound only appears if you choose a stream
        # by hand in the OSD. Turning DASH off without also setting this
        # trades the buzz for silence.
        #
        # No API key / client id / secret here on purpose: those are
        # per-user secrets and this repo is public. Set them via the
        # add-on's own config page at http://<device-ip>:<port>/youtube/api
        'kodion.mpd.videos': 'false',
        'kodion.video.stream.select': '1',
    },
}


# Active skin to switch to after install
ACTIVE_SKIN_ID = 'skin.mp'


def _jsonrpc(method, params=None):
    """Call Kodi's JSON-RPC API. Returns parsed result dict, or None on error."""
    body = {'jsonrpc': '2.0', 'method': method, 'id': 1}
    if params is not None:
        body['params'] = params
    raw = xbmc.executeJSONRPC(json.dumps(body))
    try:
        return json.loads(raw).get('result')
    except Exception:
        xbmc.log('[mpbuild] JSON-RPC parse fail: {0}'.format(raw), xbmc.LOGERROR)
        return None


def _addon_installed(addon_id):
    """True if Kodi knows about this addon (installed and enabled)."""
    res = _jsonrpc('Addons.GetAddonDetails', {
        'addonid': addon_id,
        'properties': ['enabled', 'installed', 'version'],
    })
    if not res:
        return False
    addon = res.get('addon') or {}
    return bool(addon.get('installed') and addon.get('enabled'))


def _addon_installed_version(addon_id):
    """Returns the installed version string, or None if not installed."""
    res = _jsonrpc('Addons.GetAddonDetails', {
        'addonid': addon_id,
        'properties': ['enabled', 'installed', 'version'],
    })
    if not res:
        return None
    addon = res.get('addon') or {}
    if not (addon.get('installed') and addon.get('enabled')):
        return None
    return addon.get('version')


def _uninstall_addon(addon_id):
    """Best-effort uninstall."""
    xbmc.log('[mpbuild] uninstalling {0}...'.format(addon_id), xbmc.LOGINFO)
    xbmc.executebuiltin('UninstallAddon({0},true)'.format(addon_id), wait=True)
    # Wait a beat for the uninstall to complete
    deadline = time.time() + 10
    while time.time() < deadline:
        if not _addon_installed(addon_id):
            return True
        xbmc.sleep(500)
    return False


def _direct_install(addon_id, version, progress=None, current_pct=0):
    """
    Bulletproof install: download zip directly from our GitHub Pages and
    extract to special://home/addons/. Bypasses Kodi's repo resolution
    entirely, so we don't lose version-comparison fights against the
    official repo, and we don't depend on third-party repos being up.

    Returns True on success.
    """
    url = '{0}/{1}/{1}-{2}.zip'.format(REPO_BASE_URL, addon_id, version)

    # Already installed at the right version? Skip.
    current = _addon_installed_version(addon_id)
    if current == version:
        xbmc.log('[mpbuild] {0} v{1} already installed'.format(
            addon_id, version), xbmc.LOGINFO)
        return True

    if progress:
        try:
            progress.update(current_pct, 'Downloading {0} v{1}...'.format(
                addon_id, version))
        except Exception:
            pass

    xbmc.log('[mpbuild] direct-install {0} v{1} from {2}'.format(
        addon_id, version, url), xbmc.LOGINFO)

    # Download
    try:
        r = requests.get(url, timeout=180)
        r.raise_for_status()
        zip_data = r.content
    except Exception as e:
        xbmc.log('[mpbuild] download failed for {0}: {1}'.format(
            addon_id, e), xbmc.LOGERROR)
        return False

    # If a wrong-version copy is installed, uninstall via Kodi first so
    # the addon DB is consistent. (We can't just delete the folder —
    # Kodi caches addon entries in Addons33.db.)
    if current and current != version:
        xbmc.log('[mpbuild] removing wrong-version {0} v{1}'.format(
            addon_id, current), xbmc.LOGINFO)
        _uninstall_addon(addon_id)

    # Extract straight to addons/
    addons_dir = xbmcvfs.translatePath('special://home/addons/')
    target_dir = os.path.join(addons_dir, addon_id)

    # Belt-and-suspenders: remove any leftover folder
    if os.path.isdir(target_dir):
        try:
            shutil.rmtree(target_dir)
        except Exception as e:
            xbmc.log('[mpbuild] could not remove existing {0}: {1}'.format(
                target_dir, e), xbmc.LOGWARNING)

    if progress:
        try:
            progress.update(current_pct, 'Extracting {0}...'.format(addon_id))
        except Exception:
            pass

    try:
        with zipfile.ZipFile(io.BytesIO(zip_data)) as zf:
            # Sanity-check: top-level dir in zip should match addon_id
            names = zf.namelist()
            if not names:
                xbmc.log('[mpbuild] zip is empty for {0}'.format(addon_id),
                         xbmc.LOGERROR)
                return False
            top = names[0].split('/')[0]
            if top != addon_id:
                xbmc.log('[mpbuild] zip top dir is "{0}", expected "{1}"'.format(
                    top, addon_id), xbmc.LOGERROR)
                return False
            zf.extractall(addons_dir)
    except Exception as e:
        xbmc.log('[mpbuild] extract failed for {0}: {1}'.format(
            addon_id, e), xbmc.LOGERROR)
        return False

    # Tell Kodi to scan the addons folder so it picks up the new addon
    xbmc.executebuiltin('UpdateLocalAddons', wait=True)
    xbmc.sleep(2500)

    # Brand-new addons appearing on disk (vs replacing an existing one)
    # are registered by Kodi as installed but DISABLED by default. We
    # need to explicitly enable. This is a no-op if already enabled.
    enable_res = _jsonrpc('Addons.SetAddonEnabled', {
        'addonid': addon_id,
        'enabled': True,
    })
    xbmc.log('[mpbuild] enable {0}: {1}'.format(addon_id, enable_res),
             xbmc.LOGINFO)
    xbmc.sleep(1500)

    # Verify it registered AND is enabled
    deadline = time.time() + 30
    while time.time() < deadline:
        installed_ver = _addon_installed_version(addon_id)
        if installed_ver == version:
            xbmc.log('[mpbuild] {0} v{1} ready'.format(addon_id, version),
                     xbmc.LOGINFO)
            return True
        xbmc.sleep(1000)

    # Final diagnostic — was it found at all? Disabled? Wrong version?
    final = _jsonrpc('Addons.GetAddonDetails', {
        'addonid': addon_id,
        'properties': ['enabled', 'installed', 'version'],
    })
    xbmc.log('[mpbuild] {0} verify failed. Final state: {1}'.format(
        addon_id, final), xbmc.LOGERROR)
    return False


def _install_addon(addon_id, progress=None, current_pct=0):
    """
    Install an addon by ID via Kodi's InstallAddon builtin, which
    resolves through configured repositories. Use this only for addons
    that exist in exactly one repo (no version conflict possible).

    Returns True on success.
    """
    if _addon_installed(addon_id):
        xbmc.log('[mpbuild] {0} already installed'.format(addon_id),
                 xbmc.LOGINFO)
        return True

    if progress:
        try:
            progress.update(current_pct, 'Installing {0}...'.format(addon_id))
        except Exception:
            pass

    xbmc.executebuiltin('InstallAddon({0})'.format(addon_id), wait=True)

    # Poll up to 90s — resource addons (font + image packs) can be
    # several MB and slow to download from xbmc.org.
    deadline = time.time() + 90
    while time.time() < deadline:
        if _addon_installed(addon_id):
            xbmc.log('[mpbuild] {0} installed OK'.format(addon_id),
                     xbmc.LOGINFO)
            return True
        xbmc.sleep(1500)

    xbmc.log('[mpbuild] {0} install timeout'.format(addon_id), xbmc.LOGERROR)
    return False


# Add-ons that ship in our repo but that Kodi will NEVER pull in on its own.
#
# A Kodi repository only offers UPDATES for add-ons that are already
# installed. A newly bundled add-on is simply listed and ignored, forever,
# unless something installs it explicitly. service.upnext was published to
# the repo on 2026-06-01 and was still missing from every install three
# months later for exactly this reason: "Check for updates" can never
# introduce it, and nothing else was asking for it.
#
# Anything added to the repo from here on that existing installs need
# should be listed here too.
SELF_HEAL_ADDONS = (
    ('service.subtitles.a4ksubtitles', 'a4kSubtitles (subtitles)'),
)


def _apply_default_settings_for(addon_id):
    """
    Apply DEFAULT_SETTINGS for ONE add-on.

    Deliberately not _apply_default_settings(): that walks every entry and
    would re-assert the YouTube playback settings, clobbering a deliberate
    quality choice the user made later. Self-healing a missing add-on
    should configure that add-on and touch nothing else.
    """
    settings = DEFAULT_SETTINGS.get(addon_id) or {}
    if not settings:
        return
    try:
        addon = xbmcaddon.Addon(addon_id)
    except Exception:
        return
    for key, value in settings.items():
        try:
            addon.setSetting(key, value)
        except Exception as e:
            xbmc.log('[mpbuild] failed setting {0}.{1}={2}: {3}'.format(
                addon_id, key, value, e), xbmc.LOGWARNING)


# Add-ons the build used to install but has since replaced. We disable any
# copy still present (JSON-RPC has no uninstall) so it stops running. Safe
# and reversible — the user can re-enable it in Kodi if they ever want it.
RETIRE_ADDONS = (
    ('service.upnext', 'Up Next (replaced by MP SuperLite\'s own card)'),
)


def _retire_addons(notify=True):
    """Disable any retired add-on still installed. Returns ids disabled."""
    disabled = []
    for addon_id, label in RETIRE_ADDONS:
        try:
            res = _jsonrpc('Addons.GetAddonDetails', {
                'addonid': addon_id, 'properties': ['enabled', 'installed']})
            addon = (res or {}).get('addon') or {}
            if not addon.get('installed') or not addon.get('enabled'):
                continue
            _jsonrpc('Addons.SetAddonEnabled',
                     {'addonid': addon_id, 'enabled': False})
            xbmc.log('[mpbuild] retired (disabled) {0}'.format(addon_id),
                     xbmc.LOGINFO)
            disabled.append(addon_id)
        except Exception as e:
            xbmc.log('[mpbuild] retire {0} failed: {1}'.format(addon_id, e),
                     xbmc.LOGWARNING)
    return disabled


def ensure_bundled_addons(notify=True):
    """
    Install any bundled add-on that is missing, and disable any add-on the
    build has retired. Idempotent and quiet when there is nothing to do, so
    it is safe on every menu launch.

    Returns the list of add-on ids newly installed.
    """
    _retire_addons(notify=notify)
    installed = []
    for addon_id, label in SELF_HEAL_ADDONS:
        try:
            if _addon_installed(addon_id):
                continue
            xbmc.log('[mpbuild] bundled addon {0} is missing; installing'
                     .format(addon_id), xbmc.LOGINFO)
            if notify:
                try:
                    xbmcgui.Dialog().notification(
                        'MP Build', 'Installing {0}...'.format(label),
                        xbmcgui.NOTIFICATION_INFO, 4000)
                except Exception:
                    pass
            if _install_addon(addon_id):
                _apply_default_settings_for(addon_id)
                installed.append(addon_id)
            else:
                xbmc.log('[mpbuild] could not install {0}'.format(addon_id),
                         xbmc.LOGWARNING)
        except Exception as e:
            xbmc.log('[mpbuild] ensure_bundled_addons {0} failed: {1}'.format(
                addon_id, e), xbmc.LOGWARNING)
    return installed


def _disable_unknown_sources_warning():
    """
    Set Kodi's general settings to skip the "unknown sources" prompt and
    allow updates from any repository.

    Kodi 21 settings:
      - addons.unknownsources : true     (allows installs from non-official repos)
      - addons.updatemode : 0            (0 = update from any repo, not just official)
      - general.addonnotifications : false (no toast spam)
    """
    _jsonrpc('Settings.SetSettingValue', {
        'setting': 'addons.unknownsources',
        'value': True,
    })
    _jsonrpc('Settings.SetSettingValue', {
        'setting': 'addons.updatemode',
        'value': 0,
    })
    _jsonrpc('Settings.SetSettingValue', {
        'setting': 'general.addonnotifications',
        'value': False,
    })


def _configure_subtitles():
    """
    Make a4kSubtitles the default subtitle service for movies and TV, and
    set the subtitle language to English. Without a default service set,
    Kodi's "Download/Search subtitle" flow has nothing to call and can
    error out; this wires it up so it works out of the box.
    """
    if not _addon_installed('service.subtitles.a4ksubtitles'):
        xbmc.log('[mpbuild] a4kSubtitles not installed; skipping subtitle config',
                 xbmc.LOGWARNING)
        return

    def _current(setting):
        res = _jsonrpc('Settings.GetSettingValue', {'setting': setting})
        if isinstance(res, dict):
            return res.get('value')
        return res

    # Only claim the default service if the user hasn't picked one, so
    # re-running this never clobbers a manual choice.
    for setting in ('subtitles.movie', 'subtitles.tv'):
        try:
            if not _current(setting):
                _jsonrpc('Settings.SetSettingValue',
                         {'setting': setting,
                          'value': 'service.subtitles.a4ksubtitles'})
        except Exception as e:
            xbmc.log('[mpbuild] subtitle setting {0} failed: {1}'.format(
                setting, e), xbmc.LOGWARNING)
    # Language list: set English if nothing is configured.
    try:
        if not _current('subtitles.languages'):
            _jsonrpc('Settings.SetSettingValue',
                     {'setting': 'subtitles.languages', 'value': ['English']})
    except Exception as e:
        xbmc.log('[mpbuild] subtitle languages failed: {0}'.format(e),
                 xbmc.LOGWARNING)


def _apply_default_settings():
    """Walk DEFAULT_SETTINGS and apply each via xbmcaddon."""
    for addon_id, settings in DEFAULT_SETTINGS.items():
        if not settings:
            continue
        try:
            addon = xbmcaddon.Addon(addon_id)
        except Exception:
            xbmc.log('[mpbuild] cant get addon {0} for settings'.format(addon_id),
                     xbmc.LOGWARNING)
            continue
        for key, value in settings.items():
            try:
                addon.setSetting(key, value)
            except Exception as e:
                xbmc.log('[mpbuild] failed setting {0}.{1}={2}: {3}'.format(
                    addon_id, key, value, e), xbmc.LOGWARNING)


def run_full_install():
    """Main flow: confirm -> prep -> install all -> auth -> configure scrapers -> done."""
    # Set the install-in-progress flag so any concurrent invocation of
    # default.py (e.g. triggered by ReloadSkin re-running the home
    # screen which restores `plugin://script.mpbuild/` navigation) bails
    # out silently instead of showing the menu over our active dialogs.
    # See default.py:_install_in_progress.
    xbmcgui.Window(10000).setProperty('MPBuildInstallInProgress', '1')

    # Splash first — branded welcome before the install dialog
    try:
        from resources.lib import splash
        splash.show(duration_seconds=2.5)
    except Exception as e:
        xbmc.log('[mpbuild] splash display failed (non-fatal): {0}'.format(e),
                 xbmc.LOGWARNING)

    yes = xbmcgui.Dialog().yesno(
        'MP Build Installer',
        'This will install:[CR]'
        '  - ResolveURL + CocoScrapers (scrapers)[CR]'
        '  - TMDb Helper + deps (widgets + metadata)[CR]'
        '  - MP skin (comic-book UI, boots into SuperSearch)[CR]'
        '  - MP SuperLite (playback)[CR]'
        '  - MP SuperSearch (discovery)[CR][CR]'
        'Then optionally walk you through Real Debrid and AllDebrid '
        'authorization, configure scraper providers, and switch to the '
        'MP skin.[CR][CR]'
        'Continue?',
        yeslabel='Install', nolabel='Cancel')
    if not yes:
        try:
            xbmcgui.Window(10000).clearProperty('MPBuildInstallInProgress')
        except Exception:
            pass
        return

    progress = xbmcgui.DialogProgress()
    progress.create('MP Build Installer', 'Preparing...')

    try:
        # Step 1: clear UX hurdles
        progress.update(5, 'Configuring Kodi addon settings...')
        _disable_unknown_sources_warning()

        # Step 1b: clean up orphan repos from previous install attempts
        for orphan_id in ORPHAN_REPOS:
            if _addon_installed(orphan_id):
                xbmc.log('[mpbuild] removing orphan repo {0}'.format(orphan_id),
                         xbmc.LOGINFO)
                _uninstall_addon(orphan_id)

        # Force a repo metadata refresh so Kodi sees the latest from our repo
        progress.update(8, 'Refreshing repository metadata...')
        xbmc.executebuiltin('UpdateAddonRepos', wait=True)
        xbmc.sleep(2000)

        # Step 2: install each addon in order
        total = len(INSTALL_ORDER)
        for i, entry in enumerate(INSTALL_ORDER):
            # Backwards compat: accept old 2- and 3-tuples
            if len(entry) == 2:
                addon_id, label = entry
                method, version = 'installaddon', None
            elif len(entry) == 3:
                addon_id, label, version = entry
                method = 'direct' if version else 'installaddon'
            else:
                addon_id, label, method, version = entry

            if progress.iscanceled():
                progress.close()
                xbmcgui.Dialog().ok('MP Build', 'Installation cancelled.')
                return
            pct = 10 + int(60 * i / total)
            progress.update(pct,
                            'Installing {0}...[CR]({1}/{2})'.format(
                                label, i + 1, total))

            if method == 'direct':
                ok = _direct_install(addon_id, version,
                                     progress=progress, current_pct=pct)
            else:
                ok = _install_addon(addon_id,
                                    progress=progress, current_pct=pct)

            if not ok:
                progress.close()
                xbmcgui.Dialog().ok('MP Build',
                    'Failed to install {0}.[CR][CR]Check the Kodi log for '
                    'details, then try again.'.format(label))
                return

        # Step 3: apply the bundled config snapshot if present.
        # This brings TMDb Helper preferences, CocoScrapers provider
        # list, and SuperLite settings to a fresh install.
        # We apply this BEFORE DEFAULT_SETTINGS so defaults can fill in
        # whatever the snapshot stripped (e.g. tmdb_apikey if it was
        # caught by the secret-key strip even though it's a public key).
        progress.update(75, 'Applying bundled configuration...')
        _apply_config_snapshot(prompt_on_existing=True)

        # Step 3b: apply our default settings AFTER the snapshot. This
        # is the "fill in what the snapshot left empty" layer — defaults
        # like the public TMDb API key, SuperLite quality preferences,
        # CocoScrapers debug toggle, etc. If the snapshot already wrote
        # a value, our defaults are silently no-ops.
        progress.update(78, 'Applying default settings...')
        _apply_default_settings()

        # Step 3b2: make a4kSubtitles the default subtitle service so the
        # "Download/Search subtitle" flow works out of the box.
        progress.update(80, 'Configuring subtitles...')
        _configure_subtitles()

        # Step 3c: drop the TMDB Helper player JSON so SuperLite handles
        # all play actions originating from TMDB Helper.
        progress.update(82, 'Wiring TMDB Helper to SuperLite...')
        _install_tmdbhelper_player()

        # Step 4: optional debrid auth (uses MP SuperLite's own dialog,
        # works regardless of active skin)
        progress.close()

        # Step 4a: offer the laptop/phone web page for typing API keys —
        # the manual alternative to the QR logins. Fully skippable, and
        # also available any time from the MP Build menu.
        try:
            from resources.lib import webconfig
            if xbmcgui.Dialog().yesno(
                    'API Keys',
                    'Prefer to type your keys from a laptop or phone?[CR][CR]'
                    'MP Build can serve a web page where you enter your TMDB '
                    'key, YouTube keys, and Real-Debrid / AllDebrid tokens.'
                    '[CR][CR]Open it now? (The QR logins are still offered '
                    'next, and you can reopen this any time from the MP Build '
                    'menu.)',
                    yeslabel='Open Web Page', nolabel='Skip'):
                webconfig.open_web_entry()
        except Exception as e:
            xbmc.log('[mpbuild] web key entry step failed (non-fatal): {0}'
                     .format(e), xbmc.LOGWARNING)

        from resources.lib import debrid_setup
        debrid_setup.run_setup_wizard()

        # Step 5: Trakt auth with our own QR dialog. Runs BEFORE the
        # skin switch so the user gets the same QR-with-instructions
        # experience as RD and AD, regardless of which skin is active.
        # No more dependency on TMDb Helper's authenticate_trakt
        # script (which renders badly on Estuary).
        from resources.lib import trakt_setup
        trakt_setup.run_setup_wizard()

        # Step 6: optional scraper config
        from resources.lib import scraper_setup
        scraper_setup.run_setup_wizard()

        # Step 7: SKIN SWITCH IS THE LAST STEP. After this point we
        # do NOT show any more dialogs — Kodi's "Keep this skin?"
        # prompt must own the screen uninterrupted for 10 seconds.
        # The reentrancy guard set at function entry stays active
        # throughout the skin transition; _wait_for_skin_ready holds it
        # a little longer to cover the skin-load + Keep-prompt window.
        skin_available = ACTIVE_SKIN_ID and _addon_installed(ACTIVE_SKIN_ID)

        if skin_available:
            xbmcgui.Dialog().ok(
                'MP Build',
                'Almost done![CR][CR]'
                'Click OK to switch to the MP skin.[CR][CR]'
                'When the skin loads, Kodi will ask "Keep this skin?" — '
                'click [B]Keep[/B] within 10 seconds, or it will revert.')
            yes = xbmcgui.Dialog().yesno(
                'MP Build',
                'Ready to switch to the MP skin?',
                yeslabel='Switch', nolabel='Keep Estuary')
            if yes:
                _switch_to_skin(ACTIVE_SKIN_ID)
                # Holds the install-in-progress lock until the MP skin is
                # active (and through the Keep prompt) so no MP Build
                # re-launch ever appears over it.
                _wait_for_skin_ready()

        # Step 8: final completion notification — short, non-modal
        xbmcgui.Dialog().notification(
            'MP Build',
            'Setup complete! Restart Kodi to boot into MP SuperSearch.',
            xbmcgui.NOTIFICATION_INFO, 6000)
        return  # exit cleanly

    finally:
        try:
            progress.close()
        except Exception:
            pass
        # Always clear the install-in-progress flag, even on error or
        # user cancel. Otherwise subsequent MP Build launches would
        # silently no-op until Kodi restart.
        try:
            xbmcgui.Window(10000).clearProperty('MPBuildInstallInProgress')
        except Exception:
            pass


def _rewrite_paths_in_settings_xml(content_bytes, curator_addons_path):
    """
    Walk a captured settings.xml's bytes and rewrite any image:// URLs
    that contain the curator's absolute addons path to use the portable
    special://home/addons/ form instead.

    Background: AF3 stores icon paths inside <setting type="string">
    values like:
      image://C%3a%5cUsers%5cDEV%5cAppData%5cRoaming%5cKodi%5caddons%5c
        plugin.video.mpsupersearch%5cresources%5cmedia%5cicon.png/

    That C:\\Users\\DEV path is the curator's absolute path, URL-
    encoded. On a friend's machine the path is different (different
    Windows username, Mac, Linux, Android, Xbox sandbox, etc.) so the
    icon doesn't render. By rewriting to:
      image://special%3a%2f%2fhome%2faddons%2fplugin.video.mpsupersearch
        %2fresources%2fmedia%2ficon.png/

    we get a path Kodi resolves correctly on every platform.

    Returns (new_bytes, count_rewritten).
    """
    if not curator_addons_path:
        return content_bytes, 0

    try:
        text = content_bytes.decode('utf-8')
    except UnicodeDecodeError:
        return content_bytes, 0

    # Encode the curator path the way Kodi does inside image:// URLs:
    # only special characters get percent-escaped (lowercase hex),
    # ASCII letters/digits keep their original case. This matches what
    # we actually see in captured settings.xml files like
    # `C%3a%5cUsers%5cDEV%5cAppData%5c...`
    def kodi_encode(s):
        out = []
        for ch in s:
            if ch.isalnum() or ch in ('.', '-', '_'):
                out.append(ch)
            else:
                out.append('%{0:02x}'.format(ord(ch)))
        return ''.join(out)

    # Build encodings for both backslash and forward-slash variants
    # of the curator path. Captured paths use whichever the OS uses.
    norm_back = curator_addons_path.replace('/', '\\')
    norm_fwd = curator_addons_path.replace('\\', '/')

    encoded_variants = set()
    for variant in (norm_back, norm_fwd, curator_addons_path):
        encoded_variants.add(kodi_encode(variant))
        # Also generate uppercase-hex variant for tolerance
        enc_lower = kodi_encode(variant)
        enc_upper = ''
        i = 0
        while i < len(enc_lower):
            if enc_lower[i] == '%' and i + 2 < len(enc_lower):
                enc_upper += '%' + enc_lower[i+1:i+3].upper()
                i += 3
            else:
                enc_upper += enc_lower[i]
                i += 1
        encoded_variants.add(enc_upper)

    # The replacement: special://home/addons/ encoded with backslash-
    # equivalent slashes (since the rest of the path likely uses %5c
    # backslashes in Windows captures, but special:// uses forward
    # slashes natively). Forward-slash form is universally accepted.
    portable_encoded = kodi_encode('special://home/addons/')

    rewritten = 0
    new_text = text
    for enc in encoded_variants:
        if enc and enc in new_text:
            count = new_text.count(enc)
            new_text = new_text.replace(enc, portable_encoded)
            rewritten += count

    return new_text.encode('utf-8'), rewritten


def _apply_config_snapshot(prompt_on_existing=True):
    """
    If the build ships a config snapshot at
    resources/configs/mp-build-snapshot.zip, extract it into Kodi's
    addon_data folder. This brings TMDb Helper settings, scraper
    provider prefs, and SuperLite settings to a fresh install.

    On the way in, settings.xml files are scanned for image:// URLs
    containing the curator's absolute addons path (recorded in the
    snapshot's _snapshot_meta.json). Those paths are rewritten to the
    portable special://home/addons/ form so icons work on every
    platform regardless of the curator's OS or username.

    Behavior:
      - If no snapshot exists: silent no-op.
      - If snapshot exists and target addon_data has no overlap:
        extract directly.
      - If overlap exists and prompt_on_existing=True: ask user
        whether to overwrite.
      - If prompt_on_existing=False: always overwrite.

    Returns True if snapshot was applied, False if skipped/missing.
    """
    try:
        addon = xbmcaddon.Addon()
        snap = os.path.join(addon.getAddonInfo('path'),
                            'resources', 'configs', 'mp-build-snapshot.zip')
        if not os.path.isfile(snap):
            xbmc.log('[mpbuild] no snapshot at {0} — skipping'.format(snap),
                     xbmc.LOGINFO)
            return False

        addon_data_root = xbmcvfs.translatePath('special://profile/addon_data/')
        os.makedirs(addon_data_root, exist_ok=True)

        # Read the curator's addons path from snapshot metadata so we
        # can rewrite settings.xml paths during extraction.
        curator_addons_path = None
        try:
            with zipfile.ZipFile(snap) as zf:
                if '_snapshot_meta.json' in zf.namelist():
                    with zf.open('_snapshot_meta.json') as f:
                        meta = json.load(f)
                    curator_addons_path = meta.get('curator_addons_path')
                    xbmc.log('[mpbuild] snapshot curator path: {0}'.format(
                        curator_addons_path), xbmc.LOGINFO)
        except Exception as e:
            xbmc.log('[mpbuild] could not read snapshot metadata: {0}'.format(e),
                     xbmc.LOGWARNING)

        # Detect overlap: any addon_data folder we'd overwrite?
        overlap = []
        try:
            with zipfile.ZipFile(snap) as zf:
                for name in zf.namelist():
                    parts = name.replace('\\', '/').split('/')
                    if len(parts) >= 2 and parts[0] == 'addon_data':
                        addon_id = parts[1]
                        target = os.path.join(addon_data_root, addon_id)
                        if os.path.isdir(target) and addon_id not in overlap:
                            overlap.append(addon_id)
        except Exception as e:
            xbmc.log('[mpbuild] snapshot inspection failed: {0}'.format(e),
                     xbmc.LOGERROR)
            return False

        if overlap and prompt_on_existing:
            yes = xbmcgui.Dialog().yesno(
                'MP Build',
                'A configuration snapshot is bundled with this build.[CR][CR]'
                'Some addon settings exist on this install already and will '
                'be overwritten if you apply the snapshot:[CR]'
                '  ' + ', '.join(overlap[:5]) +
                ('...' if len(overlap) > 5 else '') +
                '[CR][CR]Apply the bundled snapshot anyway?',
                yeslabel='Apply', nolabel='Keep existing')
            if not yes:
                xbmc.log('[mpbuild] user declined snapshot overwrite',
                         xbmc.LOGINFO)
                return False

        # Extract addon_data/* from the zip, rewriting paths in
        # settings.xml files as we go.
        total_rewritten = 0
        try:
            with zipfile.ZipFile(snap) as zf:
                for member in zf.namelist():
                    if not member.startswith('addon_data/'):
                        continue
                    if member.endswith('/'):
                        continue
                    rel = member[len('addon_data/'):]
                    dst = os.path.join(addon_data_root, rel)
                    os.makedirs(os.path.dirname(dst), exist_ok=True)
                    with zf.open(member) as src_f:
                        data = src_f.read()
                    if member.endswith('settings.xml') and curator_addons_path:
                        data, n = _rewrite_paths_in_settings_xml(
                            data, curator_addons_path)
                        if n:
                            xbmc.log('[mpbuild] rewrote {0} paths in {1}'
                                     .format(n, rel), xbmc.LOGINFO)
                            total_rewritten += n
                    with open(dst, 'wb') as dst_f:
                        dst_f.write(data)
            xbmc.log('[mpbuild] applied config snapshot from {0} ({1} paths '
                     'rewritten)'.format(snap, total_rewritten),
                     xbmc.LOGINFO)
            return True
        except Exception as e:
            xbmc.log('[mpbuild] snapshot extract failed: {0}'.format(e),
                     xbmc.LOGERROR)
            return False
    except Exception as e:
        xbmc.log('[mpbuild] _apply_config_snapshot error: {0}'.format(e),
                 xbmc.LOGERROR)
        return False


def _install_tmdbhelper_player():
    """
    Drop the SuperLite player JSON into TMDB Helper's userdata so it
    becomes the default player for movies and episodes initiated from
    AF3 widgets, search results, etc.

    Source file: <our addon>/resources/configs/tmdbhelper_players/<file>.json
    Target: <Kodi profile>/addon_data/plugin.video.themoviedb.helper/players/<file>.json
    """
    try:
        addon = xbmcaddon.Addon()
        src = os.path.join(addon.getAddonInfo('path'), 'resources', 'configs',
                           'tmdbhelper_players', 'plugin.video.mpsuperlite.json')
        if not os.path.isfile(src):
            xbmc.log('[mpbuild] player JSON missing at {0}'.format(src),
                     xbmc.LOGWARNING)
            return False

        dst_dir = xbmcvfs.translatePath(
            'special://profile/addon_data/plugin.video.themoviedb.helper/players/')
        if not os.path.isdir(dst_dir):
            os.makedirs(dst_dir, exist_ok=True)
        dst = os.path.join(dst_dir, 'plugin.video.mpsuperlite.json')
        shutil.copyfile(src, dst)
        xbmc.log('[mpbuild] dropped SuperLite player JSON at {0}'.format(dst),
                 xbmc.LOGINFO)
        return True
    except Exception as e:
        xbmc.log('[mpbuild] failed to install player JSON: {0}'.format(e),
                 xbmc.LOGERROR)
        return False


def _switch_to_skin(skin_id):
    """
    Set Kodi's active skin via JSON-RPC.

    Note: do NOT show any notifications or dialogs after a successful
    switch. Kodi pops up its own "Keep this skin?" 10-second confirm
    dialog the moment the skin changes, and any UI we show on top of
    that blocks the user from clicking Keep in time → Kodi reverts.
    """
    res = _jsonrpc('Settings.SetSettingValue', {
        'setting': 'lookandfeel.skin',
        'value': skin_id,
    })
    return res is True


def _wait_for_skin_ready(max_seconds=15):
    """
    After switching to skin.mp, hold the install-in-progress lock while
    Kodi's "Keep this skin?" prompt runs, so no MP Build re-invocation
    (triggered by the skin load re-running home navigation) appears over
    it. skin.mp is a plain Estuary fork — no skinvariables generation or
    warmup is needed, so this is just a timed hold plus a sanity check
    that the skin actually stuck.
    """
    log_prefix = '[mpbuild][skin-wait]'

    bg = xbmcgui.DialogProgressBG()
    try:
        bg.create('MP Build', 'Applying the MP skin...')
    except Exception:
        bg = None

    try:
        # Wait out the 10s Keep-prompt countdown plus a buffer.
        for i in range(max_seconds):
            if bg:
                try:
                    bg.update(int(i * 100 / max_seconds), 'MP Build',
                              'Waiting for "Keep this skin?" prompt...')
                except Exception:
                    pass
            xbmc.sleep(1000)

        active_skin = _jsonrpc('Settings.GetSettingValue', {
            'setting': 'lookandfeel.skin',
        })
        if isinstance(active_skin, dict):
            active_skin = active_skin.get('value')
        if active_skin != ACTIVE_SKIN_ID:
            xbmc.log('{0} skin is {1}, not {2} — the user may have let the '
                     'Keep prompt revert it'.format(
                         log_prefix, active_skin, ACTIVE_SKIN_ID),
                     xbmc.LOGINFO)
        else:
            xbmc.log('{0} {1} is active'.format(log_prefix, ACTIVE_SKIN_ID),
                     xbmc.LOGINFO)
    finally:
        if bg:
            try:
                bg.close()
            except Exception:
                pass


def reset_and_reinstall():
    """Uninstall everything MP and start over."""
    yes = xbmcgui.Dialog().yesno(
        'MP Build Reset',
        'This will UNINSTALL MP SuperLite, MP SuperSearch, ResolveURL, '
        'and CocoScrapers, then reinstall fresh.[CR][CR]'
        'Your debrid credentials and settings will be LOST.[CR][CR]Continue?',
        yeslabel='Reset', nolabel='Cancel')
    if not yes:
        return

    # Uninstall in REVERSE dependency order
    for entry in reversed(INSTALL_ORDER):
        addon_id = entry[0]
        try:
            xbmc.executebuiltin('UninstallAddon({0},true)'.format(addon_id), wait=True)
        except Exception as e:
            xbmc.log('[mpbuild] uninstall {0}: {1}'.format(addon_id, e), xbmc.LOGWARNING)

    xbmc.sleep(1500)
    run_full_install()
