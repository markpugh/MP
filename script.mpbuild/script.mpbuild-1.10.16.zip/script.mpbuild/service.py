# -*- coding: utf-8 -*-
"""
MP Build startup service.

Optionally boots Kodi straight into MP SuperSearch, behind the SuperSearch
splash. Off by default; enable in MP Build's settings.

Design notes:

  - We wait for the home window to actually be up before doing anything.
    Firing at service start is too early: the skin is still loading, the
    splash would be drawn over a half-built GUI, and ActivateWindow can be
    swallowed entirely.

  - If Kodi started into playback (autoplay, a resumed item, a library
    update kicking something off) we stay out of the way completely.

  - SuperSearch is opened with ActivateWindow(...,return) rather than
    RunAddon. The "return" flag is what makes Back land on the skin.mp
    home (the branded MP page) instead of closing Kodi, so the rest of
    the build stays reachable. RunAddon gives no such guarantee.

  - This runs once per Kodi start, never again. It is not a loop.
"""
import sys

import xbmc
import xbmcaddon
import xbmcgui

ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
sys.path.insert(0, ADDON_PATH)

SUPERSEARCH_ID = 'plugin.video.mpsupersearch'
SUPERSEARCH_URL = 'plugin://{0}/'.format(SUPERSEARCH_ID)

# How long to wait for the skin's home window before giving up.
HOME_TIMEOUT_SECONDS = 60
POLL_SECONDS = 0.5


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log('[mpbuild][service] {0}'.format(msg), level=level)


def _enabled():
    try:
        return ADDON.getSettingBool('boot_to_supersearch')
    except Exception:
        return (ADDON.getSetting('boot_to_supersearch') or '').lower() == 'true'


def _splash_seconds():
    try:
        return max(0, min(15, ADDON.getSettingInt('boot_splash_seconds')))
    except Exception:
        return 4


def _supersearch_installed():
    try:
        xbmcaddon.Addon(SUPERSEARCH_ID)
        return True
    except Exception:
        return False


def _wait_for_home(monitor):
    """
    Block until the home window is active, Kodi aborts, or we time out.
    Returns True if home came up.
    """
    waited = 0.0
    while waited < HOME_TIMEOUT_SECONDS:
        if monitor.abortRequested():
            return False
        if xbmc.getCondVisibility('Window.IsVisible(home)'):
            return True
        if monitor.waitForAbort(POLL_SECONDS):
            return False
        waited += POLL_SECONDS
    _log('home window never appeared within {0}s; standing down'
         .format(HOME_TIMEOUT_SECONDS), xbmc.LOGWARNING)
    return False


def _boot_into_supersearch(monitor):
    """One-shot: boot straight into SuperSearch (if enabled)."""
    if not _enabled():
        return

    if not _supersearch_installed():
        _log('{0} is not installed; nothing to open'.format(SUPERSEARCH_ID),
             xbmc.LOGWARNING)
        return

    if not _wait_for_home(monitor):
        return

    # Let the home screen settle. Widgets are still populating the instant
    # home becomes visible, and stealing focus mid-build looks broken.
    if monitor.waitForAbort(1.5):
        return

    # Something is already playing, or the user has navigated away while we
    # waited. Either way they are busy; do not hijack them.
    if xbmc.getCondVisibility('Player.HasMedia'):
        _log('media already playing at startup; not opening SuperSearch')
        return
    if not xbmc.getCondVisibility('Window.IsVisible(home)'):
        _log('user navigated away during startup; not opening SuperSearch')
        return

    seconds = _splash_seconds()
    try:
        from resources.lib import splash
        # Two branded splashes after Kodi's own: first the MP Build suite
        # splash (the add-on's bundled splash.jpg, shown when no image is
        # given), then the MP SuperSearch splash, then we open SuperSearch.
        splash.show(duration_seconds=min(3, max(2, seconds)))
        if seconds:
            splash.show(duration_seconds=seconds,
                        image=splash.SUPERSEARCH_SPLASH)
    except Exception as e:
        _log('splash failed, continuing: {0}'.format(e), xbmc.LOGWARNING)

    _log('opening SuperSearch')
    # return -> Back lands on the skin.mp home (the branded MP page).
    xbmc.executebuiltin(
        'ActivateWindow(Videos,{0},return)'.format(SUPERSEARCH_URL))


# --- MP View enforcement ---------------------------------------------------
# Kodi only applies the skin's default view when the video window first
# opens; navigating into shows/seasons/episodes is in-window folder
# navigation, so Kodi reverts to its remembered per-content view. To keep
# the build on our own MP View everywhere, we gently re-assert it whenever
# the video window is in front showing media content in a different view.
MP_VIEW_ID = 58
MP_VIEW_NAME = 'MP View'            # matches the <viewtype label> in View_58_MP.xml
_VIDEO_CONTENT = ('movies', 'tvshows', 'seasons', 'episodes',
                  'sets', 'musicvideos', 'videos')


def _enforce_mp_view():
    try:
        # Only when the video window itself is in front (not under the
        # SuperSearch dialog or any other modal).
        if not xbmc.getCondVisibility('Window.IsActive(10025)'):
            return
        if not any(xbmc.getCondVisibility('Container.Content({0})'.format(c))
                   for c in _VIDEO_CONTENT):
            return
        current = (xbmc.getInfoLabel('Container.Viewmode') or '').strip()
        if current and current != MP_VIEW_NAME:
            xbmc.executebuiltin('Container.SetViewMode({0})'.format(MP_VIEW_ID))
    except Exception:
        pass


def _service_loop(monitor):
    """
    Persistent background loop for the lifetime of Kodi:
      - keeps the API-key web page running while `webconfig_enabled` is on,
      - keeps video screens on our MP View.
    Polls fairly often (for snappy view enforcement) but does the heavier
    web-config check only a few times a second.
    """
    try:
        from resources.lib import webconfig
    except Exception as e:
        _log('webconfig unavailable: {0}'.format(e), xbmc.LOGWARNING)
        webconfig = None

    wc = webconfig.WebConfig() if webconfig else None
    tick = 0
    try:
        while not monitor.abortRequested():
            # View enforcement — every tick for responsiveness.
            _enforce_mp_view()

            # Web-config lifecycle — every ~2s.
            if webconfig and (tick % 4 == 0):
                want = webconfig.is_enabled()
                if want and not wc.running:
                    port = webconfig.get_port()
                    if wc.start(port,
                                on_saved=lambda: webconfig.set_enabled(False)):
                        webconfig.publish_url(webconfig.build_url(port))
                    else:
                        webconfig.set_enabled(False)
                elif not want and wc.running:
                    wc.stop()
                    webconfig.clear_url()

            tick += 1
            if monitor.waitForAbort(0.5):
                break
    finally:
        if wc and wc.running:
            wc.stop()
        if webconfig:
            webconfig.clear_url()


def main():
    monitor = xbmc.Monitor()
    _log('service starting')
    _boot_into_supersearch(monitor)
    _log('boot done; entering service loop (web config + MP View)')
    # Keep running to enforce MP View and service the API-key web page.
    _service_loop(monitor)


if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        import traceback
        xbmc.log('[mpbuild][service] fatal: {0}\n{1}'.format(
            e, traceback.format_exc()), xbmc.LOGERROR)
