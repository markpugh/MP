# -*- coding: utf-8 -*-
"""
TMDb Helper next-episodes sync fix.

TMDb Helper 6.15.6 crashes its Trakt next-episodes sync:

    File ".../tmdbhelper/lib/api/trakt/sync/datasync.py", line 318,
      in is_inprogress_show
        if aired_episodes <= watched_episodes:
    TypeError: '<=' not supported between instances of 'int' and 'NoneType'

Trakt returns a null watched count for some shows and None reaches that
comparison. The exception takes down the WHOLE next-episodes sync, which
has two visible consequences:

  1. The trakt_towatch widget fails to populate ("Error getting
     plugin://plugin.video.themoviedb.helper/?info=trakt_towatch...").

  2. Worse day to day: because the sync never completes it is never
     cached, so it re-runs on every widget refresh. Each attempt opens
     its "Updating SyncNextEpisodes" DialogProgressBG, which takes over
     the bottom-right notification slot and repeatedly stomps on MP
     SuperLite's and MP Trailer Finder's own progress messages.

The fix treats a missing count as zero, which is what the surrounding
logic already assumes. Behaviour is unchanged for every non-null case:

    aired=10 watched=None -> in progress   (was: TypeError)
    aired=10 watched=3    -> in progress
    aired=10 watched=10   -> not in progress
    aired=0  watched=0    -> not in progress

This is a third-party file, so a TMDb Helper update will revert it.
apply_patch() is idempotent and is called from default.py on every menu
launch, so the fix re-applies itself the next time the user opens MP
Build. Same self-healing approach as trailer_patch.py.
"""
import os
import re

import xbmc
import xbmcaddon
import xbmcvfs


TH_ID = 'plugin.video.themoviedb.helper'
TARGET_REL = os.path.join('resources', 'tmdbhelper', 'lib', 'api', 'trakt',
                          'sync', 'datasync.py')
BACKUP_SUFFIX = '.mpbuild_orig'

# Injected so we can detect "already patched" without parsing Python.
PATCH_MARKER = 'MPBUILD_SYNCFIX_PATCHED'

# The vulnerable form. Captures the def line, the body indent, and the
# comparison, so the guard is inserted with matching indentation.
VULNERABLE_RE = re.compile(
    r'(def is_inprogress_show\(self, tmdb_id, aired_episodes, watched_episodes\):[ \t]*\r?\n)'
    r'([ \t]+)(if aired_episodes <= watched_episodes:)'
)

GUARD = (
    '{indent}# {marker}: Trakt can return a null watched/aired count, and\n'
    '{indent}# None reaching the comparison below raises TypeError, which\n'
    '{indent}# aborts the entire next-episodes sync. The failed sync is\n'
    '{indent}# never cached, so it re-runs on every widget refresh and its\n'
    '{indent}# background progress dialog keeps taking over the bottom-right\n'
    '{indent}# notification slot. Missing count == zero watched.\n'
    '{indent}aired_episodes = aired_episodes or 0\n'
    '{indent}watched_episodes = watched_episodes or 0\n'
)


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log('[mpbuild][tmdbhelperpatch] {0}'.format(msg), level=level)


def _target_path():
    """Absolute path to datasync.py, or None if TMDb Helper isn't present."""
    try:
        base = xbmcaddon.Addon(TH_ID).getAddonInfo('path')
    except Exception:
        base = xbmcvfs.translatePath('special://home/addons/{0}'.format(TH_ID))
    if not base:
        return None
    path = os.path.join(xbmcvfs.translatePath(base), TARGET_REL)
    return path if os.path.isfile(path) else None


def is_patch_applied(path=None):
    path = path or _target_path()
    if not path:
        return False
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return PATCH_MARKER in f.read()
    except Exception:
        return False


def _clear_bytecode(path):
    """
    Drop cached .pyc for the patched module.

    Python invalidates by source mtime so this is belt-and-braces, but a
    stale .pyc silently serving the unpatched function would be a
    miserable thing to debug.
    """
    cache = os.path.join(os.path.dirname(path), '__pycache__')
    if not os.path.isdir(cache):
        return
    stem = os.path.splitext(os.path.basename(path))[0]
    for name in os.listdir(cache):
        if name.startswith(stem + '.') and name.endswith('.pyc'):
            try:
                os.remove(os.path.join(cache, name))
                _log('removed stale bytecode {0}'.format(name))
            except Exception as e:
                _log('could not remove {0}: {1}'.format(name, e), xbmc.LOGWARNING)


def apply_patch():
    """
    Apply the sync fix. Idempotent and safe to call on every menu launch.

    Returns True if the fix is in place (already or newly applied),
    False if TMDb Helper is missing or the file no longer matches.
    """
    path = _target_path()
    if not path:
        _log('TMDb Helper not installed; nothing to patch')
        return False

    if is_patch_applied(path):
        return True

    try:
        with open(path, 'r', encoding='utf-8') as f:
            src = f.read()
    except Exception as e:
        _log('read failed: {0}'.format(e), xbmc.LOGERROR)
        return False

    match = VULNERABLE_RE.search(src)
    if not match:
        # Either upstream fixed it or they restructured the function.
        # Do not guess at a patch site.
        if 'def is_inprogress_show' not in src:
            _log('is_inprogress_show no longer exists; upstream restructured, '
                 'skipping', xbmc.LOGINFO)
        else:
            _log('is_inprogress_show found but not in the known-vulnerable '
                 'form; assuming upstream fixed it, skipping', xbmc.LOGINFO)
        return False

    backup = path + BACKUP_SUFFIX
    if not os.path.isfile(backup):
        try:
            with open(backup, 'w', encoding='utf-8') as f:
                f.write(src)
        except Exception as e:
            _log('backup failed, not patching: {0}'.format(e), xbmc.LOGWARNING)
            return False

    indent = match.group(2)
    guard = GUARD.format(indent=indent, marker=PATCH_MARKER)
    new_src = (src[:match.end(1)]
               + guard
               + indent + match.group(3)
               + src[match.end(3):])

    # Atomic write: temp file, fsync, replace.
    tmp = path + '.tmp'
    try:
        with open(tmp, 'w', encoding='utf-8', newline='\n') as f:
            f.write(new_src)
            try:
                f.flush()
                os.fsync(f.fileno())
            except Exception:
                pass
        os.replace(tmp, path)
    except Exception as e:
        _log('write failed: {0}'.format(e), xbmc.LOGERROR)
        try:
            os.remove(tmp)
        except Exception:
            pass
        return False

    _clear_bytecode(path)
    _log('patched {0}'.format(path))
    return True


def apply_patch_with_feedback():
    """Menu-invoked variant: tells the user what happened."""
    import xbmcgui

    path = _target_path()
    if not path:
        xbmcgui.Dialog().ok(
            'MP Build',
            'TMDb Helper is not installed, so there is nothing to patch.')
        return False

    if is_patch_applied(path):
        xbmcgui.Dialog().ok(
            'MP Build',
            'The TMDb Helper sync fix is already applied.[CR][CR]'
            'It re-applies itself automatically if a TMDb Helper update '
            'overwrites it.')
        return True

    if apply_patch():
        xbmcgui.Dialog().ok(
            'MP Build',
            'TMDb Helper sync fix applied.[CR][CR]'
            'This stops the failing next-episodes sync from repeatedly '
            'taking over the bottom-right notification area.[CR][CR]'
            'Restart Kodi for it to take effect.')
        return True

    xbmcgui.Dialog().ok(
        'MP Build',
        'Could not apply the fix. TMDb Helper may have changed this code, '
        'in which case the bug is likely fixed upstream.[CR][CR]'
        'Check kodi.log for details.')
    return False
