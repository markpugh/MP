# -*- coding: utf-8 -*-
"""
AF3 context-menu patch for MP Trailer Finder.

Purpose: AF3's stock Trailer context menu item is hardcoded to use
TMDb Helper's discovered trailer URL, hidden when no trailer exists,
and limited to whatever TMDb has cataloged. We want it to ALWAYS work
by routing through MP Trailer Finder, which searches YouTube directly.

Approach: surgical line-level patch of AF3's Dialog_DialogContextMenu.xml.
  - Drop the visibility condition that hides the item when TMDb has no
    trailer (so it's always available).
  - Replace the three-line onclick chain with a single RunScript that
    invokes our addon with the listitem's title and year.

The patch is idempotent — re-running it on already-patched XML is a
no-op. It's also re-applied on every MP Build menu launch (same
pattern as skinvariables version pinning), so any future AF3 update
that overwrites this file gets repatched automatically the next time
the user opens MP Build.

If AF3's XML structure changes upstream and our string-based locator
fails, we fail silently — the stock Trailer item still works for TMDb
trailers, the user just doesn't get our YouTube fallback. We log a
warning and the user can re-install the build to get the patch.
"""
import os
import re
import shutil

import xbmc
import xbmcvfs


AF3_ID = 'skin.arctic.fuse.3'
TARGET_FILE = 'Dialog_DialogContextMenu.xml'
BACKUP_SUFFIX = '.mpbuild_orig'

# Marker we inject so we can detect "already patched" without parsing XML.
PATCH_MARKER = 'MPTRAILERFINDER_PATCHED'

# What we look for to find the Trailer item. Scoped enough to be unique
# but tolerant of minor whitespace variation.
TRAILER_VISIBILITY_RE = re.compile(
    r'<visible>\[!String\.IsEmpty\(Window\(Home\)\.Property\('
    r'TMDbHelper\.ListItem\.Trailer\)\)\]</visible>'
)


def _af3_xml_path():
    """Resolve AF3's 1080i directory inside the user's Kodi addons folder."""
    candidates = [
        'special://home/addons/{0}/1080i/{1}'.format(AF3_ID, TARGET_FILE),
        'special://xbmc/addons/{0}/1080i/{1}'.format(AF3_ID, TARGET_FILE),
    ]
    for path in candidates:
        translated = xbmcvfs.translatePath(path)
        if os.path.isfile(translated):
            return translated
    return None


def is_patch_applied(xml_path=None):
    """Quick check: does this XML already contain our patch marker?"""
    path = xml_path or _af3_xml_path()
    if not path or not os.path.isfile(path):
        return False
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return PATCH_MARKER in f.read()
    except Exception:
        return False


def apply_patch(reload_skin=False):
    """
    Apply (or re-apply) the patch. Returns True on success, False on
    any failure or if AF3 isn't present.

    reload_skin=True triggers Kodi's ReloadSkin() after writing the
    patched XML. This makes the patch take effect immediately, but
    has a major side effect: ReloadSkin re-runs the home screen,
    which can cause MP Build (if invoked from a menu) to re-launch
    itself in parallel with whatever install/wizard flow is already
    running. ONLY use reload_skin=True when called from the menu's
    auto-repair path AFTER the user has already returned to the
    home screen — never from inside an install flow.
    """
    path = _af3_xml_path()
    if not path:
        xbmc.log('[mpbuild][trailerpatch] AF3 not installed or path not found',
                 xbmc.LOGINFO)
        return False

    try:
        with open(path, 'r', encoding='utf-8') as f:
            xml = f.read()
    except Exception as e:
        xbmc.log('[mpbuild][trailerpatch] read failed: {0}'.format(e),
                 xbmc.LOGWARNING)
        return False

    # Already patched? Skip.
    if PATCH_MARKER in xml:
        xbmc.log('[mpbuild][trailerpatch] Already patched, skipping',
                 xbmc.LOGINFO)
        return True

    # Locate the Trailer item by its visibility line. If we can't find
    # it, AF3's structure has changed and we should bail rather than
    # corrupt the XML.
    match = TRAILER_VISIBILITY_RE.search(xml)
    if not match:
        xbmc.log('[mpbuild][trailerpatch] Trailer item not found — AF3 '
                 'structure may have changed; not patching',
                 xbmc.LOGWARNING)
        return False

    # Backup the original on first patch so we can restore later.
    backup = path + BACKUP_SUFFIX
    if not os.path.isfile(backup):
        try:
            shutil.copy2(path, backup)
        except Exception as e:
            xbmc.log('[mpbuild][trailerpatch] backup failed: {0}'.format(e),
                     xbmc.LOGWARNING)
            return False

    # Build the new <item> body. Strategy:
    #   1. Find the <item> that contains the Trailer visibility line.
    #   2. Replace its body with our YouTube-driven action.
    #
    # Use re.search bounded by <item>...</item> spanning the trailer item.
    item_re = re.compile(
        r'(<item>(?:(?!</item>).)*?'
        + TRAILER_VISIBILITY_RE.pattern
        + r'(?:(?!</item>).)*?</item>)',
        re.DOTALL)
    item_match = item_re.search(xml)
    if not item_match:
        xbmc.log('[mpbuild][trailerpatch] Could not isolate trailer <item>',
                 xbmc.LOGWARNING)
        return False

    # Replacement: always visible, bound to MP Trailer Finder.
    # We pass listitem title and year; for episodes we'd ideally use the
    # show title, but ListItem.Title gives reasonable fallback.
    replacement = (
        '<!-- {marker}: original Trailer item replaced by MP Build -->\n'
        '        <item>\n'
        '            <label>$LOCALIZE[31393]</label>\n'
        '            <icon>special://skin/extras/icons/video.png</icon>\n'
        '            <onclick>Dialog.Close(contextmenu,true)</onclick>\n'
        '            <onclick>RunScript(script.mp.trailerfinder,find,$INFO[ListItem.Title],$INFO[ListItem.Year])</onclick>\n'
        '            <visible>[!String.IsEmpty(ListItem.Title)]</visible>\n'
        '        </item>'
    ).format(marker=PATCH_MARKER)

    new_xml = xml[:item_match.start()] + replacement + xml[item_match.end():]

    # Write atomically — write to temp, fsync, rename.
    tmp = path + '.tmp'
    try:
        with open(tmp, 'w', encoding='utf-8') as f:
            f.write(new_xml)
            try:
                f.flush()
                os.fsync(f.fileno())
            except Exception:
                pass
        os.replace(tmp, path)
    except Exception as e:
        xbmc.log('[mpbuild][trailerpatch] write failed: {0}'.format(e),
                 xbmc.LOGERROR)
        try:
            os.remove(tmp)
        except Exception:
            pass
        return False

    xbmc.log('[mpbuild][trailerpatch] Patched {0}'.format(path),
             xbmc.LOGINFO)

    # Force a skin reload IF requested. Only do this from the menu's
    # auto-repair path, never from inside an install flow — see the
    # reload_skin docstring above.
    if reload_skin:
        try:
            xbmc.executebuiltin('ReloadSkin()')
            xbmc.log('[mpbuild][trailerpatch] Triggered skin reload',
                     xbmc.LOGINFO)
        except Exception as e:
            xbmc.log('[mpbuild][trailerpatch] ReloadSkin failed (non-fatal): {0}'.format(e),
                     xbmc.LOGWARNING)

    return True


def apply_patch_with_feedback():
    """
    Like apply_patch() but for menu invocation — shows the user a
    dialog with the result so they can see what happened.
    """
    import xbmcgui

    path = _af3_xml_path()
    if not path:
        xbmcgui.Dialog().ok(
            'MP Build',
            'AF3 (skin.arctic.fuse.3) is not installed. The trailer '
            'patch only works when AF3 is the active skin.')
        return False

    if is_patch_applied():
        # Already patched — offer to re-patch (in case AF3 was updated)
        choice = xbmcgui.Dialog().yesno(
            'MP Build',
            'AF3 trailer patch is already applied. Re-apply anyway?\n'
            '(Useful if AF3 was just updated.)',
            yeslabel='Re-apply', nolabel='Cancel')
        if not choice:
            return True
        # Force re-patch by removing the marker (treat backup as source)
        backup = path + BACKUP_SUFFIX
        if os.path.isfile(backup):
            try:
                shutil.copy2(backup, path)
            except Exception as e:
                xbmcgui.Dialog().notification(
                    'MP Build',
                    'Could not restore backup before re-patching: {0}'.format(e),
                    xbmcgui.NOTIFICATION_ERROR, 4000)
                return False

    result = apply_patch(reload_skin=True)
    if result:
        xbmcgui.Dialog().notification(
            'MP Build',
            'Trailer patch applied. Skin reloading...',
            xbmcgui.NOTIFICATION_INFO, 3000)
    else:
        xbmcgui.Dialog().ok(
            'MP Build',
            'Trailer patch FAILED to apply. Check the Kodi log for '
            '[mpbuild][trailerpatch] entries to see why.')
    return result


def restore_original():
    """
    Restore the pre-patch XML from backup. Used by Reset & Reinstall
    or on demand. Returns True on success.
    """
    path = _af3_xml_path()
    if not path:
        return False
    backup = path + BACKUP_SUFFIX
    if not os.path.isfile(backup):
        return False
    try:
        shutil.copy2(backup, path)
        xbmc.log('[mpbuild][trailerpatch] Restored original XML',
                 xbmc.LOGINFO)
        return True
    except Exception as e:
        xbmc.log('[mpbuild][trailerpatch] restore failed: {0}'.format(e),
                 xbmc.LOGWARNING)
        return False
