# -*- coding: utf-8 -*-
"""
Trakt setup. Uses our own device-flow auth implementation with the same
QR auth dialog used by RD and AD — same UX, runs while Estuary is still
the active skin, no dependency on TMDb Helper's authenticate_trakt
script (which renders ugly on Estuary).

The flow:
  1. POST /oauth/device/code → user_code, device_code, verification_url
  2. Show DialogQRAuth.xml with user_code + QR pointing at verification_url
  3. Poll /oauth/device/token until activated (or user cancels/timeout)
  4. Save returned token blob to TMDb Helper's trakt_token setting
     (the same setting key TMDb Helper would have written to)

API keys: reused from TMDb Helper. They're already shipped with the
addon Mark distributes, so this isn't adding any exposure.
"""
import json
import time

import xbmc
import xbmcaddon
import xbmcgui

import requests

from resources.lib.common import log, log_error, log_warning, ADDON_NAME
from resources.lib.auth.dialog import show_qr_auth


TMDBH = 'plugin.video.themoviedb.helper'

# Trakt API credentials — sourced from TMDb Helper's internal client.
# See plugin.video.themoviedb.helper/resources/tmdbhelper/lib/api/api_keys/trakt.py
CLIENT_ID = 'e6fde6173adf3c6af8fd1b0694b9b84d7c519cefc24482310e1de06c6abe5467'
CLIENT_SECRET = '15119384341d9a61c751d8d515acbc0dd801001d4ebe85d3eef9885df80ee4d9'

DEVICE_CODE_URL = 'https://api.trakt.tv/oauth/device/code'
DEVICE_TOKEN_URL = 'https://api.trakt.tv/oauth/device/token'


def _is_authorized():
    """
    Check if Trakt is already authorized. Looks at TMDb Helper's
    trakt_token setting (where TMDb Helper stores the JSON token blob)
    OR the Home window's TraktIsAuth property.
    """
    try:
        if xbmcgui.Window(10000).getProperty('TraktIsAuth'):
            return True
    except Exception:
        pass

    try:
        helper = xbmcaddon.Addon(TMDBH)
        token_value = helper.getSetting('trakt_token')
        if token_value and len(token_value) > 20:
            return True
    except Exception:
        pass

    return False


def _save_token(token_data):
    """
    Persist the Trakt OAuth token to TMDb Helper's trakt_token setting.

    token_data is the full dict returned by /oauth/device/token. We
    add a created_at timestamp because Trakt's expires_in is relative,
    not absolute — refreshing later needs to know when the original
    token was minted.
    """
    if 'created_at' not in token_data:
        token_data['created_at'] = int(time.time())

    blob = json.dumps(token_data)
    try:
        helper = xbmcaddon.Addon(TMDBH)
        helper.setSetting('trakt_token', blob)
        xbmcgui.Window(10000).setProperty('TraktIsAuth', '1')
        log('Trakt token saved ({0} chars)'.format(len(blob)))
        return True
    except Exception as e:
        log_error('Could not save trakt_token: {0}'.format(e))
        return False


def _get_device_code():
    """POST /oauth/device/code → dict with user_code, device_code, etc. Or None."""
    try:
        r = requests.post(
            DEVICE_CODE_URL,
            json={'client_id': CLIENT_ID},
            headers={'Content-Type': 'application/json'},
            timeout=15)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        log_error('Trakt device/code failed: {0}'.format(e))
        return None


def _check_device_token(device_code):
    """
    POST /oauth/device/token with device_code. Returns:
      ('ok', token_dict)       — auth complete
      ('pending', None)        — user hasn't entered code yet
      ('expired', None)        — code expired
      ('denied', None)         — user denied
      ('error', msg)           — other failure
    """
    try:
        r = requests.post(
            DEVICE_TOKEN_URL,
            json={
                'code': device_code,
                'client_id': CLIENT_ID,
                'client_secret': CLIENT_SECRET,
            },
            headers={'Content-Type': 'application/json'},
            timeout=15)
    except Exception as e:
        return ('error', 'network: {0}'.format(e))

    # Trakt's docs: 200=success, 400=pending, 404=not found,
    # 409=already used, 410=expired, 418=denied, 429=slow down
    if r.status_code == 200:
        try:
            return ('ok', r.json())
        except Exception as e:
            return ('error', 'json: {0}'.format(e))
    if r.status_code == 400:
        return ('pending', None)
    if r.status_code == 410:
        return ('expired', None)
    if r.status_code == 418:
        return ('denied', None)
    if r.status_code == 429:
        return ('pending', None)
    return ('error', 'http {0}'.format(r.status_code))


def _run_trakt_qr_flow():
    """Run the Trakt device flow with our QR dialog. Returns True on success."""
    dc = _get_device_code()
    if not dc:
        xbmcgui.Dialog().notification(
            ADDON_NAME,
            'Trakt device code request failed. Check internet.',
            xbmcgui.NOTIFICATION_ERROR, 4000)
        return False

    user_code = dc.get('user_code') or ''
    device_code = dc.get('device_code') or ''
    verification_url = dc.get('verification_url') or 'https://trakt.tv/activate'
    expires_in = int(dc.get('expires_in') or 600)
    interval = max(1, int(dc.get('interval') or 5))

    log('Trakt device/code: user_code={0!r}, expires_in={1}, interval={2}'.format(
        user_code, expires_in, interval))

    if not user_code or not device_code:
        xbmcgui.Dialog().notification(
            ADDON_NAME,
            'Trakt returned incomplete device code response.',
            xbmcgui.NOTIFICATION_ERROR, 4000)
        return False

    state = {'token': None}
    last_check = [0]

    def poll_fn():
        now = time.time()
        if now - last_check[0] < interval:
            return 'pending'
        last_check[0] = now

        status, payload = _check_device_token(device_code)
        if status == 'ok':
            state['token'] = payload
            return 'ok'
        if status == 'pending':
            return 'pending'
        log_warning('Trakt auth ended: {0} {1}'.format(status, payload))
        return 'error'

    success, err = show_qr_auth(
        title='Authorize Trakt',
        url=verification_url,
        code=user_code,
        qr_data=verification_url,
        poll_fn=poll_fn,
        expires_in=expires_in,
        poll_interval=interval,
    )

    if success and state['token']:
        if _save_token(state['token']):
            xbmcgui.Dialog().notification(
                ADDON_NAME,
                'Trakt authorized!',
                xbmcgui.NOTIFICATION_INFO, 3000)
            return True
        xbmcgui.Dialog().notification(
            ADDON_NAME,
            'Trakt authorized but token save failed.',
            xbmcgui.NOTIFICATION_WARNING, 4000)
        return False

    if err:
        xbmcgui.Dialog().notification(
            ADDON_NAME,
            'Trakt: ' + err,
            xbmcgui.NOTIFICATION_WARNING, 4000)
    return False


def authorize_trakt():
    """Standalone Trakt auth (callable from MP Build menu)."""
    if _is_authorized():
        yes = xbmcgui.Dialog().yesno(
            'Trakt',
            'Trakt is already authorized. Reauthorize?',
            yeslabel='Reauthorize', nolabel='Cancel')
        if not yes:
            return
    _run_trakt_qr_flow()


def run_setup_wizard():
    """
    Called from the full install flow between AD auth and scrapers.
    Walks the user through Trakt auth with our own QR dialog.
    """
    intro = xbmcgui.Dialog().yesno(
        'Trakt Setup',
        "MP Build's home screen widgets (On Deck, To Watch, "
        'Recommendations) read from your Trakt account.[CR][CR]'
        "Without Trakt the widgets will be empty.[CR][CR]"
        "If you don't have a Trakt account, sign up free at trakt.tv "
        'first.[CR][CR]'
        'Authorize Trakt now?',
        yeslabel='Authorize', nolabel='Skip')
    if not intro:
        return

    if _is_authorized():
        log('Trakt already authorized; skipping wizard step')
        return

    _run_trakt_qr_flow()
