# -*- coding: utf-8 -*-
"""
Splash dialog. Shows a branded fullscreen image for a given duration,
then auto-closes. Used as the welcome screen at the start of the
install flow.
"""
import xbmc
import xbmcaddon
import xbmcgui


ADDON = xbmcaddon.Addon()


class _Splash(xbmcgui.WindowXMLDialog):
    """Just an image. No interaction. Auto-closes via the runner."""
    def __init__(self, *args, **kwargs):
        super(_Splash, self).__init__(*args, **kwargs)


def show(duration_seconds=2.5):
    """
    Display the splash for `duration_seconds`, then close.

    Implementation note: WindowXMLDialog.doModal() blocks until close, so
    we use show() (non-blocking) + sleep + close() to control timing.
    """
    try:
        dialog = _Splash('DialogSplash.xml',
                        ADDON.getAddonInfo('path'),
                        'default', '1080i')
        dialog.show()
        # waitForAbort returns True if Kodi is shutting down — bail early
        monitor = xbmc.Monitor()
        monitor.waitForAbort(duration_seconds)
        dialog.close()
        del dialog
    except Exception as e:
        xbmc.log('[mpbuild] splash failed: {0}'.format(e), xbmc.LOGWARNING)
