# -*- coding: utf-8 -*-
"""About / version info."""
import xbmcaddon
import xbmcgui


def show():
    addon = xbmcaddon.Addon()
    version = addon.getAddonInfo('version')
    text = (
        'MP Build {0}[CR][CR]'
        'A custom Kodi setup built around:[CR]'
        '  - MP SuperSearch: TMDB-powered discovery with stackable filters[CR]'
        '  - MP SuperLite: debrid-only playback engine[CR]'
        '  - CocoScrapers + ResolveURL[CR][CR]'
        'Built by RoloTech LLC. Licensed under GPL-3.0.[CR][CR]'
        'Repo: github.com/markpugh/MP'
    ).format(version)
    xbmcgui.Dialog().textviewer('About MP Build', text)
