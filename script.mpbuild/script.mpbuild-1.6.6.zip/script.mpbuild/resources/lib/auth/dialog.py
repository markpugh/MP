# -*- coding: utf-8 -*-
"""
QRAuthDialog — a generic WindowXMLDialog that shows a QR code, a fallback
code/URL, and polls a callback function until it returns 'ok' or 'error'
(or the user cancels, or the timer expires).

Used by both Real Debrid (device-code flow) and AllDebrid (PIN flow). Add
Trakt later by passing in its OAuth device-code params; same dialog.

Polling protocol — pass a callable `poll_fn` that returns one of:
    'pending'  — keep waiting
    'ok'       — success, dialog closes with .result = True
    'error'    — failure, dialog closes with .result = False, .error = str

The callback runs on the dialog's poll thread, NOT the UI thread. Don't
touch xbmcgui controls from poll_fn.
"""
import os
import time

import xbmc
import xbmcgui

from resources.lib.common import log, log_error, temp_dir
from resources.lib.auth.qrgen import make_qr_png


# Control IDs — referenced from DialogQRAuth.xml
CTRL_TITLE = 100
CTRL_QR_IMAGE = 110
CTRL_INSTRUCTION = 120
CTRL_URL = 130
CTRL_CODE = 140
CTRL_STATUS = 150
CTRL_CANCEL = 200


class QRAuthDialog(xbmcgui.WindowXMLDialog):

    def __init__(self, *args, **kwargs):
        super(QRAuthDialog, self).__init__(*args)
        self.title = kwargs.get('title', 'Authorize')
        self.url = kwargs.get('url', '')
        self.code = kwargs.get('code', '')
        self.qr_data = kwargs.get('qr_data') or self.url
        self.poll_fn = kwargs.get('poll_fn')
        self.expires_at = kwargs.get('expires_at') or (time.time() + 600)
        self.poll_interval = max(2, int(kwargs.get('poll_interval', 5)))

        # Output state
        self.result = False        # set True on success
        self.error = ''            # populated on error
        self.canceled = False

        # Pre-generate the QR PNG so onInit can just point an image control at it
        self._qr_path = os.path.join(temp_dir(),
                                     'mpsuperlite_qr_{0}.png'.format(int(time.time())))
        try:
            make_qr_png(self.qr_data, self._qr_path, box_size=14, border=4)
        except Exception as e:
            log_error('QR pre-generation failed: {0}'.format(e))
            self._qr_path = ''

    # ---- lifecycle -----------------------------------------------------

    def onInit(self):
        self._set_label(CTRL_TITLE, self.title)
        self._set_label(CTRL_INSTRUCTION,
                        'Scan with your phone, or visit the URL below and enter the code:')
        self._set_label(CTRL_URL, self.url)
        self._set_label(CTRL_CODE, self.code)
        self._set_label(CTRL_STATUS, 'Waiting for authorization...')
        if self._qr_path and os.path.isfile(self._qr_path):
            try:
                img = self.getControl(CTRL_QR_IMAGE)
                img.setImage(self._qr_path)
            except Exception as e:
                log_error('Could not set QR image: {0}'.format(e))
        try:
            self.setFocusId(CTRL_CANCEL)
        except Exception:
            pass
        # Kick off polling on a Kodi monitor loop (not a thread — Kodi
        # plays nicer with the cooperative xbmc.Monitor pattern).
        self._run_poll_loop()

    def onClick(self, control_id):
        if control_id == CTRL_CANCEL:
            self.canceled = True
            self.close()

    def onAction(self, action):
        # Pressing back/escape acts as cancel
        if action.getId() in (10, 92):  # ACTION_PREVIOUS_MENU, ACTION_NAV_BACK
            self.canceled = True
            self.close()

    # ---- internals -----------------------------------------------------

    def _set_label(self, control_id, text):
        try:
            self.getControl(control_id).setLabel(text)
        except Exception:
            pass

    def _run_poll_loop(self):
        """
        Cooperative polling using xbmc.Monitor.waitForAbort. This blocks
        onInit() but Kodi handles the dialog rendering and input even
        while waitForAbort is sleeping.
        """
        if not self.poll_fn:
            return

        monitor = xbmc.Monitor()
        last_poll = 0
        retry_after_user_confirms = 0

        while not self.canceled and not monitor.abortRequested():
            now = time.time()
            if now > self.expires_at:
                self.error = 'Timed out'
                self._set_label(CTRL_STATUS, 'Authorization timed out.')
                xbmc.sleep(1500)
                self.close()
                return

            if now - last_poll >= self.poll_interval:
                last_poll = now
                try:
                    state = self.poll_fn()
                except Exception as e:
                    log_error('poll_fn raised: {0}'.format(e))
                    state = 'error'
                    self.error = str(e)

                if state == 'ok':
                    self.result = True
                    self._set_label(CTRL_STATUS, '\u2713 Authorized!')
                    xbmc.sleep(1200)
                    self.close()
                    return
                elif state == 'error':
                    msg = 'Authorization failed' + (
                        ': ' + self.error if self.error else '.')
                    self._set_label(CTRL_STATUS, msg)
                    xbmc.sleep(2500)
                    self.close()
                    return
                elif state == 'authorized_but_pending':
                    # RD quirk: occasionally returns error_pending after
                    # the user has confirmed. Retry a few times before
                    # giving up.
                    retry_after_user_confirms += 1
                    if retry_after_user_confirms > 6:
                        self.error = 'Stuck in pending after confirm'
                        state = 'error'
                # else 'pending' — keep waiting

            # Tick the countdown label
            remaining = int(self.expires_at - now)
            if remaining > 0:
                self._set_label(CTRL_STATUS,
                                'Waiting for authorization... ({0}s)'.format(remaining))

            if monitor.waitForAbort(1):
                return

    # ---- cleanup -------------------------------------------------------

    def close(self):
        try:
            if self._qr_path and os.path.isfile(self._qr_path):
                os.remove(self._qr_path)
        except Exception:
            pass
        super(QRAuthDialog, self).close()


def show_qr_auth(title, url, code, poll_fn, expires_in=600, poll_interval=5,
                 qr_data=None):
    """
    Convenience wrapper. Returns (success: bool, error: str).
    """
    from resources.lib.common import ADDON_PATH
    dlg = QRAuthDialog(
        'DialogQRAuth.xml', ADDON_PATH, 'default', '1080i',
        title=title, url=url, code=code, qr_data=qr_data,
        poll_fn=poll_fn,
        expires_at=time.time() + max(60, int(expires_in)),
        poll_interval=poll_interval,
    )
    dlg.doModal()
    success = bool(getattr(dlg, 'result', False))
    error = getattr(dlg, 'error', '') or ''
    del dlg
    return success, error
