# -*- coding: utf-8 -*-
"""
Snapshot capture: package the current user's Kodi config into a single
zip we can ship as the build's default config. Run this on the curator's
machine (Mark's laptop) when something has been tweaked and should
become the new default for everyone.

The capture is deliberately selective:
  - Includes settings.xml files for our addons + relevant deps
  - Includes AF3's skin customization (widgets, hub layout)
  - Includes skinshortcuts/skinvariables overrides
  - Strips per-user auth tokens out of any captured settings.xml
  - Excludes per-user caches, databases, watch state, anything personal

The output is `mp-build-snapshot.zip` saved to a path the user can grab.
The curator commits that zip to their repo, the installer extracts it
into a fresh Kodi userdata on first run.
"""
import os
import re
import shutil
import time
import xml.etree.ElementTree as ET
import zipfile

import xbmc
import xbmcgui
import xbmcvfs


# Paths under userdata/addon_data/<id>/ to capture verbatim.
# Each entry is an addon id; everything in that folder is captured
# EXCEPT directories matching EXCLUDE_DIRS or files matching EXCLUDE_FILES.
CAPTURE_ADDONS = [
    'skin.arctic.fuse.3',
    'script.skinshortcuts',
    'script.skinvariables',
    'plugin.video.themoviedb.helper',
    'plugin.video.mpsuperlite',
    'plugin.video.mpsupersearch',
    'script.module.cocoscrapers',
]

# Directories to exclude inside any captured addon folder.
# These hold per-user caches and databases that are huge AND personal.
EXCLUDE_DIRS = {
    'database_07',           # TMDb Helper local DB
    'database_08',           # newer TMDb Helper DB if version bumps
    'cache',                 # generic addon cache
    'tmdb_cache',            # SuperLite's TMDB cache
    'log_tagger',            # TMDb Helper log artifact
    'log_library',           # TMDb Helper log artifact
    'timer_report',          # TMDb Helper log artifact
    'reconfigured_players',  # we ship our own player JSON, don't override
    '__pycache__',
    # AF3/TMDb Helper rendered image caches — these are pre-computed
    # crops/blurs of artwork, regenerated automatically. Shipping them
    # bloats the snapshot ~12MB for zero functional benefit. The pattern
    # is name + _v + digit, future TMDbH versions may add crop_v3 etc.
    'crop_v1', 'crop_v2', 'crop_v3',
    'blur_v1', 'blur_v2', 'blur_v3', 'blur_v4',
    'desat_v1', 'desat_v2',
}

# Regex pattern for additional image cache directory names that may
# appear in future TMDb Helper versions. Anything matching <word>_v<N>
# at the leaf level looks like an image cache and is excluded.
IMAGE_CACHE_PATTERN = re.compile(r'^[a-z]+_v\d+$')

# Files to exclude verbatim by name (any path).
EXCLUDE_FILES = {
    'cache.db',
    'undesirables.db',
    '.DS_Store',
    'Thumbs.db',
}

# Settings keys that are per-user secrets — strip these from any
# settings.xml we capture. Match by key prefix or substring.
SECRET_KEY_PATTERNS = [
    re.compile(r'.*access_token.*', re.IGNORECASE),
    re.compile(r'.*refresh_token.*', re.IGNORECASE),
    re.compile(r'.*api[_]?key.*', re.IGNORECASE),
    re.compile(r'.*password.*', re.IGNORECASE),
    re.compile(r'.*secret.*', re.IGNORECASE),
    re.compile(r'^rd_.*', re.IGNORECASE),     # Real Debrid creds
    re.compile(r'^ad_.*', re.IGNORECASE),     # AllDebrid creds
    re.compile(r'^trakt.*', re.IGNORECASE),   # Trakt creds
    re.compile(r'^premiumize.*', re.IGNORECASE),
]

# We DO want to keep the bundled TMDb API key (it's not a secret to us).
SECRET_KEY_WHITELIST = {
    'tmdb_apikey',  # We pre-set this for everyone, not a secret
    'tmdb_api_key',
}


def _is_secret_key(key):
    """True if this settings.xml <setting id="X"> looks like a per-user secret."""
    if not key:
        return False
    if key in SECRET_KEY_WHITELIST:
        return False
    return any(p.match(key) for p in SECRET_KEY_PATTERNS)


def _sanitize_settings_xml(src_path, dst_path):
    """
    Copy a settings.xml from src to dst, stripping any <setting> nodes
    whose id matches a secret pattern. Returns count of stripped keys.
    """
    try:
        tree = ET.parse(src_path)
        root = tree.getroot()
    except Exception as e:
        xbmc.log('[mpbuild.capture] could not parse {0}: {1}'.format(
            src_path, e), xbmc.LOGWARNING)
        # Fallback: just copy verbatim. Better than skipping the whole file.
        shutil.copy2(src_path, dst_path)
        return 0

    stripped = 0
    for setting in list(root.findall('.//setting')):
        sid = setting.get('id') or ''
        if _is_secret_key(sid):
            parent_map = {c: p for p in root.iter() for c in p}
            parent = parent_map.get(setting, root)
            parent.remove(setting)
            stripped += 1

    tree.write(dst_path, encoding='utf-8', xml_declaration=True)
    return stripped


def _walk_capture(src_dir, dst_dir):
    """
    Recursively copy src_dir -> dst_dir, applying EXCLUDE_DIRS,
    EXCLUDE_FILES rules. Sanitize any settings.xml encountered.
    Returns (files_copied, secrets_stripped).
    """
    files_copied = 0
    secrets_stripped = 0
    if not os.path.isdir(src_dir):
        return 0, 0
    os.makedirs(dst_dir, exist_ok=True)

    for entry in os.listdir(src_dir):
        src = os.path.join(src_dir, entry)
        dst = os.path.join(dst_dir, entry)
        if os.path.isdir(src):
            if entry in EXCLUDE_DIRS:
                continue
            if IMAGE_CACHE_PATTERN.match(entry):
                continue
            f, s = _walk_capture(src, dst)
            files_copied += f
            secrets_stripped += s
        else:
            if entry in EXCLUDE_FILES:
                continue
            try:
                if entry == 'settings.xml':
                    secrets_stripped += _sanitize_settings_xml(src, dst)
                else:
                    shutil.copy2(src, dst)
                files_copied += 1
            except Exception as e:
                xbmc.log('[mpbuild.capture] could not copy {0}: {1}'.format(
                    src, e), xbmc.LOGWARNING)
    return files_copied, secrets_stripped


def capture():
    """
    Build a snapshot zip of the current Kodi user's MP Build config
    and save it where the user can grab it. This is intended to be
    run by the build curator (you), not by end users.

    Output: ~/Downloads/mp-build-snapshot.zip on Windows/Linux/macOS,
    or special://temp/ if no Downloads folder is detected.
    """
    progress = xbmcgui.DialogProgress()
    progress.create('MP Build — Capture Config',
                    'Walking Kodi config...')

    addon_data_root = xbmcvfs.translatePath('special://profile/addon_data/')
    if not os.path.isdir(addon_data_root):
        progress.close()
        xbmcgui.Dialog().ok('MP Build', 'Could not locate addon_data folder.')
        return False

    # Record the curator's addons folder path so the apply-side
    # rewriter can spot it in image://... URLs and rewrite to
    # portable special://home/addons/ paths. Without this, baked-in
    # absolute paths like image://C%3A%5CUsers%5CDEV%5C... would only
    # work on the curator's machine.
    curator_addons_path = xbmcvfs.translatePath('special://home/addons/')

    # Stage area
    stage = xbmcvfs.translatePath('special://temp/mp-build-snapshot-stage/')
    if os.path.isdir(stage):
        shutil.rmtree(stage, ignore_errors=True)
    os.makedirs(stage, exist_ok=True)

    total_files = 0
    total_secrets = 0
    captured_addons = []

    for i, addon_id in enumerate(CAPTURE_ADDONS):
        if progress.iscanceled():
            progress.close()
            return False
        pct = int(80 * i / len(CAPTURE_ADDONS))
        progress.update(pct, 'Capturing {0}...'.format(addon_id))

        src = os.path.join(addon_data_root, addon_id)
        if not os.path.isdir(src):
            continue
        dst = os.path.join(stage, 'addon_data', addon_id)
        files, secrets = _walk_capture(src, dst)
        if files > 0:
            captured_addons.append((addon_id, files, secrets))
            total_files += files
            total_secrets += secrets

    # Write a manifest so users know what's in the snapshot
    progress.update(85, 'Writing manifest...')
    manifest_path = os.path.join(stage, 'MANIFEST.txt')
    with open(manifest_path, 'w', encoding='utf-8') as mf:
        mf.write('MP Build Config Snapshot\n')
        mf.write('=' * 40 + '\n')
        mf.write('Captured: {0}\n'.format(
            time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())))
        mf.write('Total files: {0}\n'.format(total_files))
        mf.write('Secret values stripped: {0}\n'.format(total_secrets))
        mf.write('\nIncluded addons:\n')
        for aid, files, secrets in captured_addons:
            mf.write('  - {0}: {1} files'.format(aid, files))
            if secrets:
                mf.write(' ({0} secrets stripped)'.format(secrets))
            mf.write('\n')
        mf.write('\nExcluded by default: caches, databases, auth tokens.\n')

    # Write machine-readable metadata for the apply-side path rewriter.
    # The curator's absolute addons path is recorded here so the
    # installer can find image://<curator_path>... references in
    # captured settings.xml files and rewrite them to portable
    # special://home/addons/ paths.
    import json
    meta = {
        'snapshot_version': 1,
        'captured_at': time.strftime('%Y-%m-%dT%H:%M:%S', time.localtime()),
        'curator_addons_path': curator_addons_path,
        'curator_userdata_path': xbmcvfs.translatePath('special://profile/'),
    }
    with open(os.path.join(stage, '_snapshot_meta.json'), 'w', encoding='utf-8') as f:
        json.dump(meta, f, indent=2)

    # Zip everything
    progress.update(90, 'Packaging zip...')
    out_dir = _find_writable_output_dir()
    out_path = os.path.join(out_dir, 'mp-build-snapshot.zip')
    if os.path.isfile(out_path):
        try:
            os.remove(out_path)
        except Exception:
            pass

    try:
        with zipfile.ZipFile(out_path, 'w', zipfile.ZIP_DEFLATED) as zf:
            for root, dirs, files in os.walk(stage):
                for f in files:
                    full = os.path.join(root, f)
                    arcname = os.path.relpath(full, stage)
                    zf.write(full, arcname)
    except Exception as e:
        progress.close()
        xbmcgui.Dialog().ok('MP Build',
            'Failed to write zip: {0}'.format(e))
        shutil.rmtree(stage, ignore_errors=True)
        return False

    # Clean stage
    progress.update(100, 'Done.')
    shutil.rmtree(stage, ignore_errors=True)
    progress.close()

    summary = (
        'Snapshot saved.[CR][CR]'
        'Path: {0}[CR][CR]'
        'Captured {1} files from {2} addons.[CR]'
        'Stripped {3} per-user secrets.[CR][CR]'
        'Next: copy this zip into your repo at[CR]'
        'script.mpbuild/resources/configs/mp-build-snapshot.zip'
        '[CR]then commit and push. Future installs will[CR]'
        'apply this config automatically.'
    ).format(out_path, total_files, len(captured_addons), total_secrets)
    xbmcgui.Dialog().ok('MP Build — Capture Done', summary)
    return True


def _find_writable_output_dir():
    """Try to find Downloads, fall back to Kodi's temp."""
    candidates = [
        os.path.expanduser('~/Downloads'),
        os.path.expanduser('~/downloads'),
        'C:\\Users\\Public\\Downloads',
    ]
    for c in candidates:
        if c and os.path.isdir(c) and os.access(c, os.W_OK):
            return c
    return xbmcvfs.translatePath('special://temp/')
