# -*- coding: utf-8 -*-
"""
Shared helpers for MP Build modules. Mirrors a tiny subset of the same
shape used in MP SuperLite so that the auth/ subpackage we share with
MP SuperLite (DialogQRAuth, qrgen) imports cleanly here too.
"""
import xbmc
import xbmcaddon
import xbmcvfs


LOG_TAG = '[mpbuild]'
ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
ADDON_NAME = ADDON.getAddonInfo('name')


def log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log('{0} {1}'.format(LOG_TAG, msg), level)
    except Exception:
        pass


def log_warning(msg):
    log(msg, xbmc.LOGWARNING)


def log_error(msg):
    log(msg, xbmc.LOGERROR)


def temp_dir():
    """Kodi's temp dir as a native filesystem path."""
    return xbmcvfs.translatePath('special://temp/')
