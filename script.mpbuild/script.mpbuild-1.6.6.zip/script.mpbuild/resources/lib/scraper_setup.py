# -*- coding: utf-8 -*-
"""
CocoScrapers configuration. Based on actual diagnostic data we gathered
testing real movies through SuperLite, we have ground truth on which
providers work, which are dead, and which are partially broken.

Settings format: CocoScrapers stores per-provider enable flags as
provider.<lowercase_name> = true/false.
"""
import xbmc
import xbmcaddon
import xbmcgui


COCOSCRAPERS = 'script.module.cocoscrapers'


# Categorized from real-world testing on Mark's network. May need
# revisiting — we'll know if all providers go dead at once.
PROVIDERS_HEALTHY = [
    '1337x',
    'bitsearch',
    'comet',           # debrid-aware, requires debrid creds (we set those)
    'kickass2',
    'piratebay',       # works despite the log_utils bug, sometimes returns sources
    'torrentdownload',
    'torrentgalaxy',
    'torrentio',       # debrid-aware, often the best single source
    'torrentproject2',
    'torrentquest',
    'knaben',          # works after our str(year) fix
]

PROVIDERS_DEAD = [
    'bitcq',           # site refused connection (HTTP 10061)
    'bitlord',         # broken HTML parser, IndexError on token regex
    'mediafusion',     # JSON decode error, server returns empty
    'nyaa',            # SSL handshake broken
    'torrentfunk',     # 12s timeout, site dead
    'yourbittorrent',  # 5s timeout, site dead
    'ytsmx',           # DNS failure
    'eztv',            # only TV episodes, errors on movies (correctly)
    'isohunt2',        # silent fails, partially functional
]


def _set_provider(provider_name, enabled):
    """Set CocoScrapers' provider.<name> setting."""
    try:
        addon = xbmcaddon.Addon(COCOSCRAPERS)
        addon.setSetting('provider.{0}'.format(provider_name),
                         'true' if enabled else 'false')
        return True
    except Exception as e:
        xbmc.log('[mpbuild] could not set provider {0}: {1}'.format(provider_name, e),
                 xbmc.LOGWARNING)
        return False


def configure():
    """Re-runnable scraper configuration menu."""
    items = [
        'Apply MP defaults (recommended healthy providers)',
        'Enable ALL providers (try everything, slower)',
        'Disable ALL providers (start fresh)',
        'Open CocoScrapers settings (manual)',
        'Cancel',
    ]
    idx = xbmcgui.Dialog().select('CocoScrapers Configuration', items)
    if idx < 0 or idx == 4:
        return

    if idx == 0:
        _apply_defaults()
    elif idx == 1:
        _enable_all()
    elif idx == 2:
        _disable_all()
    elif idx == 3:
        try:
            xbmcaddon.Addon(COCOSCRAPERS).openSettings()
        except Exception as e:
            xbmcgui.Dialog().ok('Error', 'Could not open settings: {0}'.format(e))


def _apply_defaults():
    """Enable healthy providers, disable dead ones."""
    progress = xbmcgui.DialogProgressBG()
    progress.create('MP Build', 'Configuring scraper providers...')
    try:
        total = len(PROVIDERS_HEALTHY) + len(PROVIDERS_DEAD)
        i = 0
        for p in PROVIDERS_HEALTHY:
            _set_provider(p, True)
            i += 1
            progress.update(int(100 * i / total), 'Enabling ' + p)
        for p in PROVIDERS_DEAD:
            _set_provider(p, False)
            i += 1
            progress.update(int(100 * i / total), 'Disabling ' + p)
    finally:
        progress.close()

    xbmcgui.Dialog().notification(
        'MP Build',
        '{0} providers enabled, {1} disabled.'.format(
            len(PROVIDERS_HEALTHY), len(PROVIDERS_DEAD)),
        xbmcgui.NOTIFICATION_INFO, 4000)


def _enable_all():
    for p in PROVIDERS_HEALTHY + PROVIDERS_DEAD:
        _set_provider(p, True)
    xbmcgui.Dialog().notification(
        'MP Build', 'All known providers enabled.',
        xbmcgui.NOTIFICATION_INFO, 3000)


def _disable_all():
    for p in PROVIDERS_HEALTHY + PROVIDERS_DEAD:
        _set_provider(p, False)
    xbmcgui.Dialog().notification(
        'MP Build', 'All providers disabled. Re-run config to re-enable.',
        xbmcgui.NOTIFICATION_INFO, 3000)


def run_setup_wizard():
    """Called from the full install flow."""
    yes = xbmcgui.Dialog().yesno(
        'Scraper Configuration',
        'MP Build can pre-configure CocoScrapers with the providers '
        'known to work reliably and disable the dead ones.[CR][CR]'
        'You can re-run this anytime from the MP Build menu.[CR][CR]'
        'Apply MP defaults now?',
        yeslabel='Apply', nolabel='Skip')
    if yes:
        _apply_defaults()
