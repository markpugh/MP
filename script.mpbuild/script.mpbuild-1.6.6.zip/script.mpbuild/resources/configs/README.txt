This folder holds bundled configuration that ships with the build.

mp-build-snapshot.zip (optional) — packaged via "MP Build > Capture
Config Snapshot" on the curator's machine. When present, the
installer extracts it into Kodi's addon_data on a fresh install,
giving end users the curator's preconfigured AF3 widgets, TMDb
Helper preferences, scraper provider list, etc.

tmdbhelper_players/plugin.video.mpsuperlite.json — the TMDb Helper
player config that wires playback through MP SuperLite. Always
shipped, regardless of whether a snapshot exists.
