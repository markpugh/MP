# -*- coding: utf-8 -*-
"""
Trakt setup. Triggers TMDb Helper's existing Trakt OAuth flow as part of
the install wizard so the user authenticates once cleanly instead of
getting prompted every time AF3's hub widgets fire.

Why this is critical for fresh installs:
  Every widget the curator's snapshot ships with calls Trakt-driven
  endpoints (trakt_ondeck, trakt_towatch, trakt_recommendations). On a
  fresh, unauthenticated Kodi those calls hit TMDb Helper's auto-prompt
  for Trakt sign-in, which the user can't always complete (no QR seen,
  prompt dismissed accidentally, browser not handy). Multiple widgets
  firing in parallel turn into a dialog stampede.

  Doing it once during the install wizard puts all of that into a
  single, deliberate, "follow the QR code on your phone" moment before
  AF3 ever boots widgets. Every Trakt widget after that just works.
"""
import xbmc
import xbmcaddon
import xbmcgui


TMDBH = 'plugin.video.themoviedb.helper'

# Settings keys that indicate Trakt has been authenticated. TMDb Helper
# stores the refresh token in trakt.refreshtoken once OAuth completes.
TRAKT_AUTH_KEYS = ['trakt.refreshtoken', 'trakt.token', 'trakt_refreshtoken']


def _is_authorized():
    """
    Check TMDb Helper's stored Trakt credentials. We probe a few possible
    setting key names since TMDb Helper's storage location has shifted
    across versions and we want this resilient.
    """
    try:
        helper = xbmcaddon.Addon(TMDBH)
        for key in TRAKT_AUTH_KEYS:
            try:
                if helper.getSetting(key):
                    return True
            except Exception:
                continue
    except Exception:
        return False
    return False


def _trigger_auth():
    """
    Run TMDb Helper's authenticate_trakt script entry point. This pops
    the QR + device-code dialog inside TMDb Helper's own context (its
    storage, its API client). Non-blocking — we have to poll for
    completion afterward.
    """
    xbmc.executebuiltin(
        'RunScript({0},authenticate_trakt)'.format(TMDBH))


def _wait_for_auth(timeout=600):
    """
    Poll TMDb Helper's credential storage until Trakt creds appear or
    the timeout elapses. 10 minutes by default — Trakt's device flow
    gives the user that long to enter the code.
    """
    import time
    deadline = time.time() + timeout
    while time.time() < deadline:
        if _is_authorized():
            return True
        xbmc.sleep(1500)
    return False


def authorize_trakt():
    """Standalone Trakt authorization (called from the menu re-run path)."""
    if _is_authorized():
        yes = xbmcgui.Dialog().yesno(
            'Trakt',
            'Trakt is already authorized. Reauthorize?',
            yeslabel='Reauthorize', nolabel='Cancel')
        if not yes:
            return

    xbmcgui.Dialog().notification(
        'MP Build',
        'Opening Trakt authorization...',
        xbmcgui.NOTIFICATION_INFO, 2500)
    _trigger_auth()


def run_setup_wizard():
    """
    Called from the full install flow. Walks the user through Trakt
    authentication. Trakt is strongly recommended because the build's
    widgets are Trakt-driven, but the user can skip it.
    """
    intro = xbmcgui.Dialog().yesno(
        'Trakt Setup',
        "MP Build's home screen widgets (On Deck, To Watch, "
        'Recommendations) read from your Trakt account.[CR][CR]'
        "Without Trakt, the widgets will be empty and you'll be "
        'prompted for auth every time you open the home screen.[CR][CR]'
        "If you don't have a Trakt account, sign up free at trakt.tv "
        'first, then come back and run this.[CR][CR]'
        'Authorize Trakt now?',
        yeslabel='Authorize', nolabel='Skip')
    if not intro:
        xbmcgui.Dialog().notification(
            'MP Build',
            'Skipped Trakt — run later from MP Build menu.',
            xbmcgui.NOTIFICATION_INFO, 4000)
        return

    if _is_authorized():
        # Skip silently if already done — defensive against re-runs
        xbmc.log('[mpbuild] Trakt already authorized; skipping wizard step',
                 xbmc.LOGINFO)
        return

    _trigger_auth()
    if _wait_for_auth(timeout=600):
        xbmcgui.Dialog().notification(
            'Trakt',
            'Authorized successfully!',
            xbmcgui.NOTIFICATION_INFO, 3000)
    else:
        xbmcgui.Dialog().notification(
            'Trakt',
            'Authorization not completed.',
            xbmcgui.NOTIFICATION_WARNING, 3000)
