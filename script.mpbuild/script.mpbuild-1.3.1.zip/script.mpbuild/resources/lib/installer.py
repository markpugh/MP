# -*- coding: utf-8 -*-
"""
Core installer. Drives Kodi's addon manager via JSON-RPC to install each
addon from the MP repo in dependency order, then runs follow-up steps
(auth wizards, scraper config).

Why JSON-RPC instead of executebuiltin('InstallAddon')? executebuiltin
returns immediately without telling us whether it succeeded — we'd have
no way to wait for completion or detect failure. JSON-RPC's
Addons.SetAddonEnabled and the file-system check pattern lets us verify
each step.
"""
import io
import json
import os
import shutil
import time
import zipfile

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

import requests


# Base URL of our GitHub Pages repo. All zips live under this.
REPO_BASE_URL = 'https://markpugh.github.io/MP'


# Order matters — dependencies first.
# Tuple format: (addon_id, label, install_method, version_or_None)
#
# install_method options:
#   'direct'      = download zip from our repo and extract to addons/.
#                   Bypasses Kodi's repo-resolution. Use for any addon
#                   where Kodi might pick a wrong version from xbmc.org.
#   'installaddon'= use Kodi's InstallAddon(id) builtin. Use for addons
#                   that exist only in our repo, OR for resource addons
#                   that exist only in xbmc.org's official repo.
#
INSTALL_ORDER = [
    # --- Module deps for our existing playback stack ---
    # These are only in our repo, no version conflict possible.
    ('script.module.resolveurl', 'ResolveURL (host resolver)',
        'installaddon', None),
    ('script.module.cocoscrapers', 'CocoScrapers (torrent scrapers)',
        'installaddon', None),

    # --- Pinned deps that Kodi tends to mis-resolve from official repo ---
    # We pin these to specific versions and direct-extract the zip from
    # our repo. No reliance on Kodi's repo selection.
    ('script.module.jurialmunkey', 'jurialmunkey common',
        'direct', '0.2.35'),
    ('script.skinvariables', 'Skin Variables (AF3 dep)',
        'direct', '2.2.1'),
    ('script.texturemaker', 'Texture Maker (AF3 dep)',
        'direct', '0.2.10'),
    ('plugin.video.themoviedb.helper', 'TMDb Helper (widgets + metadata)',
        'direct', '6.15.6'),

    # --- AF3's resource deps from xbmc.org (font + image packs) ---
    # These exist only in xbmc.org's repo so InstallAddon won't get
    # the wrong version (no conflict possible). Pre-install them so AF3
    # doesn't fail dep-resolution on first scan.
    ('resource.font.robotocjksc', 'Roboto CJK font',
        'installaddon', None),
    ('resource.images.weathericons.white', 'Weather icons',
        'installaddon', None),
    ('resource.images.studios.coloured', 'Studio logos',
        'installaddon', None),

    # --- Our addons ---
    ('plugin.video.mpsuperlite', 'MP SuperLite (playback engine)',
        'installaddon', None),
    ('plugin.video.mpsupersearch', 'MP SuperSearch (discovery UI)',
        'installaddon', None),

    # --- The skin, last ---
    # Direct-extract because Kodi's repo for AF3 has been flaky and we
    # want exactly v3.2.9. By the time we get here, all its deps are
    # already installed, so Kodi will register and enable it cleanly.
    ('skin.arctic.fuse.3', 'Arctic Fuse 3 (skin)',
        'direct', '3.2.9'),
]


# Dead/stale repos we want to clean up if a previous install attempt left them.
ORPHAN_REPOS = [
    'repository.jurialmunkey',
]


# Default settings to apply post-install. Per-addon-id, key->value.
DEFAULT_SETTINGS = {
    'plugin.video.mpsuperlite': {
        'cached_only': 'false',
        'auto_play': 'true',
        'prefer_hevc': 'true',
        'debrid_priority': '0',
        'max_attempts': '10',
        'max_size': '3',
        'quality_max': '1',
    },
    'plugin.video.mpsupersearch': {},
    'script.module.cocoscrapers': {
        'debug.enabled': 'true',
        'debug.location': '0',
    },
    'plugin.video.themoviedb.helper': {
        'tmdb_apikey': '9b6d253a9ec18f3c1cab46a7b831de1a',
    },
}


# Active skin to switch to after install
ACTIVE_SKIN_ID = 'skin.arctic.fuse.3'


def _jsonrpc(method, params=None):
    """Call Kodi's JSON-RPC API. Returns parsed result dict, or None on error."""
    body = {'jsonrpc': '2.0', 'method': method, 'id': 1}
    if params is not None:
        body['params'] = params
    raw = xbmc.executeJSONRPC(json.dumps(body))
    try:
        return json.loads(raw).get('result')
    except Exception:
        xbmc.log('[mpbuild] JSON-RPC parse fail: {0}'.format(raw), xbmc.LOGERROR)
        return None


def _addon_installed(addon_id):
    """True if Kodi knows about this addon (installed and enabled)."""
    res = _jsonrpc('Addons.GetAddonDetails', {
        'addonid': addon_id,
        'properties': ['enabled', 'installed', 'version'],
    })
    if not res:
        return False
    addon = res.get('addon') or {}
    return bool(addon.get('installed') and addon.get('enabled'))


def _addon_installed_version(addon_id):
    """Returns the installed version string, or None if not installed."""
    res = _jsonrpc('Addons.GetAddonDetails', {
        'addonid': addon_id,
        'properties': ['enabled', 'installed', 'version'],
    })
    if not res:
        return None
    addon = res.get('addon') or {}
    if not (addon.get('installed') and addon.get('enabled')):
        return None
    return addon.get('version')


def _uninstall_addon(addon_id):
    """Best-effort uninstall."""
    xbmc.log('[mpbuild] uninstalling {0}...'.format(addon_id), xbmc.LOGINFO)
    xbmc.executebuiltin('UninstallAddon({0},true)'.format(addon_id), wait=True)
    # Wait a beat for the uninstall to complete
    deadline = time.time() + 10
    while time.time() < deadline:
        if not _addon_installed(addon_id):
            return True
        xbmc.sleep(500)
    return False


def _direct_install(addon_id, version, progress=None, current_pct=0):
    """
    Bulletproof install: download zip directly from our GitHub Pages and
    extract to special://home/addons/. Bypasses Kodi's repo resolution
    entirely, so we don't lose version-comparison fights against the
    official repo, and we don't depend on third-party repos being up.

    Returns True on success.
    """
    url = '{0}/{1}/{1}-{2}.zip'.format(REPO_BASE_URL, addon_id, version)

    # Already installed at the right version? Skip.
    current = _addon_installed_version(addon_id)
    if current == version:
        xbmc.log('[mpbuild] {0} v{1} already installed'.format(
            addon_id, version), xbmc.LOGINFO)
        return True

    if progress:
        try:
            progress.update(current_pct, 'Downloading {0} v{1}...'.format(
                addon_id, version))
        except Exception:
            pass

    xbmc.log('[mpbuild] direct-install {0} v{1} from {2}'.format(
        addon_id, version, url), xbmc.LOGINFO)

    # Download
    try:
        r = requests.get(url, timeout=180)
        r.raise_for_status()
        zip_data = r.content
    except Exception as e:
        xbmc.log('[mpbuild] download failed for {0}: {1}'.format(
            addon_id, e), xbmc.LOGERROR)
        return False

    # If a wrong-version copy is installed, uninstall via Kodi first so
    # the addon DB is consistent. (We can't just delete the folder —
    # Kodi caches addon entries in Addons33.db.)
    if current and current != version:
        xbmc.log('[mpbuild] removing wrong-version {0} v{1}'.format(
            addon_id, current), xbmc.LOGINFO)
        _uninstall_addon(addon_id)

    # Extract straight to addons/
    addons_dir = xbmcvfs.translatePath('special://home/addons/')
    target_dir = os.path.join(addons_dir, addon_id)

    # Belt-and-suspenders: remove any leftover folder
    if os.path.isdir(target_dir):
        try:
            shutil.rmtree(target_dir)
        except Exception as e:
            xbmc.log('[mpbuild] could not remove existing {0}: {1}'.format(
                target_dir, e), xbmc.LOGWARNING)

    if progress:
        try:
            progress.update(current_pct, 'Extracting {0}...'.format(addon_id))
        except Exception:
            pass

    try:
        with zipfile.ZipFile(io.BytesIO(zip_data)) as zf:
            # Sanity-check: top-level dir in zip should match addon_id
            names = zf.namelist()
            if not names:
                xbmc.log('[mpbuild] zip is empty for {0}'.format(addon_id),
                         xbmc.LOGERROR)
                return False
            top = names[0].split('/')[0]
            if top != addon_id:
                xbmc.log('[mpbuild] zip top dir is "{0}", expected "{1}"'.format(
                    top, addon_id), xbmc.LOGERROR)
                return False
            zf.extractall(addons_dir)
    except Exception as e:
        xbmc.log('[mpbuild] extract failed for {0}: {1}'.format(
            addon_id, e), xbmc.LOGERROR)
        return False

    # Tell Kodi to scan the addons folder so it picks up the new addon
    xbmc.executebuiltin('UpdateLocalAddons', wait=True)
    xbmc.sleep(2500)

    # Brand-new addons appearing on disk (vs replacing an existing one)
    # are registered by Kodi as installed but DISABLED by default. We
    # need to explicitly enable. This is a no-op if already enabled.
    enable_res = _jsonrpc('Addons.SetAddonEnabled', {
        'addonid': addon_id,
        'enabled': True,
    })
    xbmc.log('[mpbuild] enable {0}: {1}'.format(addon_id, enable_res),
             xbmc.LOGINFO)
    xbmc.sleep(1500)

    # Verify it registered AND is enabled
    deadline = time.time() + 30
    while time.time() < deadline:
        installed_ver = _addon_installed_version(addon_id)
        if installed_ver == version:
            xbmc.log('[mpbuild] {0} v{1} ready'.format(addon_id, version),
                     xbmc.LOGINFO)
            return True
        xbmc.sleep(1000)

    # Final diagnostic — was it found at all? Disabled? Wrong version?
    final = _jsonrpc('Addons.GetAddonDetails', {
        'addonid': addon_id,
        'properties': ['enabled', 'installed', 'version'],
    })
    xbmc.log('[mpbuild] {0} verify failed. Final state: {1}'.format(
        addon_id, final), xbmc.LOGERROR)
    return False


def _install_addon(addon_id, progress=None, current_pct=0):
    """
    Install an addon by ID via Kodi's InstallAddon builtin, which
    resolves through configured repositories. Use this only for addons
    that exist in exactly one repo (no version conflict possible).

    Returns True on success.
    """
    if _addon_installed(addon_id):
        xbmc.log('[mpbuild] {0} already installed'.format(addon_id),
                 xbmc.LOGINFO)
        return True

    if progress:
        try:
            progress.update(current_pct, 'Installing {0}...'.format(addon_id))
        except Exception:
            pass

    xbmc.executebuiltin('InstallAddon({0})'.format(addon_id), wait=True)

    # Poll up to 90s — resource addons (font + image packs) can be
    # several MB and slow to download from xbmc.org.
    deadline = time.time() + 90
    while time.time() < deadline:
        if _addon_installed(addon_id):
            xbmc.log('[mpbuild] {0} installed OK'.format(addon_id),
                     xbmc.LOGINFO)
            return True
        xbmc.sleep(1500)

    xbmc.log('[mpbuild] {0} install timeout'.format(addon_id), xbmc.LOGERROR)
    return False


def _disable_unknown_sources_warning():
    """
    Set Kodi's general settings to skip the "unknown sources" prompt and
    allow updates from any repository.

    Kodi 21 settings:
      - addons.unknownsources : true     (allows installs from non-official repos)
      - addons.updatemode : 0            (0 = update from any repo, not just official)
      - general.addonnotifications : false (no toast spam)
    """
    _jsonrpc('Settings.SetSettingValue', {
        'setting': 'addons.unknownsources',
        'value': True,
    })
    _jsonrpc('Settings.SetSettingValue', {
        'setting': 'addons.updatemode',
        'value': 0,
    })
    _jsonrpc('Settings.SetSettingValue', {
        'setting': 'general.addonnotifications',
        'value': False,
    })


def _apply_default_settings():
    """Walk DEFAULT_SETTINGS and apply each via xbmcaddon."""
    for addon_id, settings in DEFAULT_SETTINGS.items():
        if not settings:
            continue
        try:
            addon = xbmcaddon.Addon(addon_id)
        except Exception:
            xbmc.log('[mpbuild] cant get addon {0} for settings'.format(addon_id),
                     xbmc.LOGWARNING)
            continue
        for key, value in settings.items():
            try:
                addon.setSetting(key, value)
            except Exception as e:
                xbmc.log('[mpbuild] failed setting {0}.{1}={2}: {3}'.format(
                    addon_id, key, value, e), xbmc.LOGWARNING)


def run_full_install():
    """Main flow: confirm -> prep -> install all -> auth -> configure scrapers -> done."""
    # Splash first — branded welcome before the install dialog
    try:
        from resources.lib import splash
        splash.show(duration_seconds=2.5)
    except Exception as e:
        xbmc.log('[mpbuild] splash display failed (non-fatal): {0}'.format(e),
                 xbmc.LOGWARNING)

    yes = xbmcgui.Dialog().yesno(
        'MP Build Installer',
        'This will install:[CR]'
        '  - ResolveURL + CocoScrapers (scrapers)[CR]'
        '  - TMDb Helper + deps (widgets + metadata)[CR]'
        '  - Arctic Fuse 3 + deps (skin)[CR]'
        '  - MP SuperLite (playback)[CR]'
        '  - MP SuperSearch (discovery)[CR][CR]'
        'Then optionally walk you through Real Debrid and AllDebrid '
        'authorization, configure scraper providers, and switch to the '
        'Arctic Fuse 3 skin.[CR][CR]'
        'Continue?',
        yeslabel='Install', nolabel='Cancel')
    if not yes:
        return

    progress = xbmcgui.DialogProgress()
    progress.create('MP Build Installer', 'Preparing...')

    try:
        # Step 1: clear UX hurdles
        progress.update(5, 'Configuring Kodi addon settings...')
        _disable_unknown_sources_warning()

        # Step 1b: clean up orphan repos from previous install attempts
        for orphan_id in ORPHAN_REPOS:
            if _addon_installed(orphan_id):
                xbmc.log('[mpbuild] removing orphan repo {0}'.format(orphan_id),
                         xbmc.LOGINFO)
                _uninstall_addon(orphan_id)

        # Force a repo metadata refresh so Kodi sees the latest from our repo
        progress.update(8, 'Refreshing repository metadata...')
        xbmc.executebuiltin('UpdateAddonRepos', wait=True)
        xbmc.sleep(2000)

        # Step 2: install each addon in order
        total = len(INSTALL_ORDER)
        for i, entry in enumerate(INSTALL_ORDER):
            # Backwards compat: accept old 2- and 3-tuples
            if len(entry) == 2:
                addon_id, label = entry
                method, version = 'installaddon', None
            elif len(entry) == 3:
                addon_id, label, version = entry
                method = 'direct' if version else 'installaddon'
            else:
                addon_id, label, method, version = entry

            if progress.iscanceled():
                progress.close()
                xbmcgui.Dialog().ok('MP Build', 'Installation cancelled.')
                return
            pct = 10 + int(60 * i / total)
            progress.update(pct,
                            'Installing {0}...[CR]({1}/{2})'.format(
                                label, i + 1, total))

            if method == 'direct':
                ok = _direct_install(addon_id, version,
                                     progress=progress, current_pct=pct)
            else:
                ok = _install_addon(addon_id,
                                    progress=progress, current_pct=pct)

            if not ok:
                progress.close()
                xbmcgui.Dialog().ok('MP Build',
                    'Failed to install {0}.[CR][CR]Check the Kodi log for '
                    'details, then try again.'.format(label))
                return

        # Step 3: apply default settings
        progress.update(75, 'Applying default settings...')
        _apply_default_settings()

        # Step 3b: drop the TMDB Helper player JSON so SuperLite handles
        # all play actions originating from TMDB Helper (= the AF3 widgets).
        progress.update(80, 'Wiring TMDB Helper to SuperLite...')
        _install_tmdbhelper_player()

        # Step 4: optional debrid auth
        progress.close()

        from resources.lib import debrid_setup
        debrid_setup.run_setup_wizard()

        # Step 5: optional scraper config
        from resources.lib import scraper_setup
        scraper_setup.run_setup_wizard()

        # Step 6: switch to Arctic Fuse 3
        if ACTIVE_SKIN_ID and _addon_installed(ACTIVE_SKIN_ID):
            yes = xbmcgui.Dialog().yesno(
                'MP Build',
                'Switch to Arctic Fuse 3 skin now?[CR][CR]'
                'You can switch back to Estuary later from '
                'Settings > Interface > Skin.',
                yeslabel='Switch', nolabel='Keep Estuary')
            if yes:
                _switch_to_skin(ACTIVE_SKIN_ID)

        # Done
        xbmcgui.Dialog().ok(
            'MP Build',
            'Setup complete![CR][CR]'
            'Launch MP SuperSearch from the home screen, or click any '
            'movie in Arctic Fuse 3 widgets to play through SuperLite.[CR][CR]'
            'To re-run any of these steps, launch MP Build from Programs.')

    finally:
        try:
            progress.close()
        except Exception:
            pass


def _install_tmdbhelper_player():
    """
    Drop the SuperLite player JSON into TMDB Helper's userdata so it
    becomes the default player for movies and episodes initiated from
    AF3 widgets, search results, etc.

    Source file: <our addon>/resources/configs/tmdbhelper_players/<file>.json
    Target: <Kodi profile>/addon_data/plugin.video.themoviedb.helper/players/<file>.json
    """
    try:
        addon = xbmcaddon.Addon()
        src = os.path.join(addon.getAddonInfo('path'), 'resources', 'configs',
                           'tmdbhelper_players', 'plugin.video.mpsuperlite.json')
        if not os.path.isfile(src):
            xbmc.log('[mpbuild] player JSON missing at {0}'.format(src),
                     xbmc.LOGWARNING)
            return False

        dst_dir = xbmcvfs.translatePath(
            'special://profile/addon_data/plugin.video.themoviedb.helper/players/')
        if not os.path.isdir(dst_dir):
            os.makedirs(dst_dir, exist_ok=True)
        dst = os.path.join(dst_dir, 'plugin.video.mpsuperlite.json')
        shutil.copyfile(src, dst)
        xbmc.log('[mpbuild] dropped SuperLite player JSON at {0}'.format(dst),
                 xbmc.LOGINFO)
        return True
    except Exception as e:
        xbmc.log('[mpbuild] failed to install player JSON: {0}'.format(e),
                 xbmc.LOGERROR)
        return False


def _switch_to_skin(skin_id):
    """Set Kodi's active skin via JSON-RPC."""
    res = _jsonrpc('Settings.SetSettingValue', {
        'setting': 'lookandfeel.skin',
        'value': skin_id,
    })
    if res is True:
        xbmcgui.Dialog().notification(
            'MP Build', 'Switched to Arctic Fuse 3',
            xbmcgui.NOTIFICATION_INFO, 3000)
        return True
    return False


def reset_and_reinstall():
    """Uninstall everything MP and start over."""
    yes = xbmcgui.Dialog().yesno(
        'MP Build Reset',
        'This will UNINSTALL MP SuperLite, MP SuperSearch, ResolveURL, '
        'and CocoScrapers, then reinstall fresh.[CR][CR]'
        'Your debrid credentials and settings will be LOST.[CR][CR]Continue?',
        yeslabel='Reset', nolabel='Cancel')
    if not yes:
        return

    # Uninstall in REVERSE dependency order
    for entry in reversed(INSTALL_ORDER):
        addon_id = entry[0]
        try:
            xbmc.executebuiltin('UninstallAddon({0},true)'.format(addon_id), wait=True)
        except Exception as e:
            xbmc.log('[mpbuild] uninstall {0}: {1}'.format(addon_id, e), xbmc.LOGWARNING)

    xbmc.sleep(1500)
    run_full_install()
