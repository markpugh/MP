# -*- coding: utf-8 -*-
"""
MP Build installer.

Run from Kodi's Programs add-ons menu. Presents a menu of actions:
- Install Build (chains everything: install addons, authorize debrids, configure scrapers)
- Authorize Real Debrid
- Authorize AllDebrid
- Configure Scrapers
- Reset & Reinstall
- About

Uses the addon's resources/lib/ submodules for the actual work.
"""
import sys

import xbmc
import xbmcaddon
import xbmcgui


ADDON = xbmcaddon.Addon()
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_PATH = ADDON.getAddonInfo('path')
sys.path.insert(0, ADDON_PATH)


INSTALL_LOCK_PROP = 'MPBuildInstallInProgress'


def _install_in_progress():
    """
    Check if run_full_install is currently executing in another
    invocation. Returns True if we should exit silently.

    Kodi treats `plugin://script.mpbuild/` navigation as a directory
    listing request, which re-invokes default.py. During the install
    flow, several things can trigger this re-invocation: ReloadSkin(),
    AF3's home screen rebuild, or Kodi attempting to refresh the
    "current directory" after a skin switch. Without this guard, every
    re-invocation would display the MP Build menu OVER whatever dialog
    is currently active (the Keep-this-skin prompt, the debrid auth
    dialog, etc.), blocking the user from completing the install.
    """
    try:
        return xbmcgui.Window(10000).getProperty(INSTALL_LOCK_PROP) == '1'
    except Exception:
        return False


def _menu_loop():
    """Show the main menu repeatedly until the user picks Cancel."""
    # Reentrancy guard: bail out fast if an install is already running
    # in another script context. See _install_in_progress for why.
    if _install_in_progress():
        xbmc.log('[mpbuild] default.py invoked while install in progress — '
                 'exiting silently to avoid blocking the active dialog',
                 xbmc.LOGINFO)
        return

    from resources.lib import installer, debrid_setup, trakt_setup, scraper_setup, skin_setup, about

    # On every launch, re-drop the TMDb Helper player JSON. This keeps
    # existing installs in sync when we ship player-config fixes — they
    # don't have to re-run the full installer for the new JSON to land.
    # Idempotent: if the file is already current, this is a no-op cost.
    try:
        installer._install_tmdbhelper_player()
    except Exception:
        pass  # never block the menu over this

    # Self-heal the YouTube add-on's stream selection. Turning MPEG-DASH
    # off (needed to avoid the 403'd split audio track) silently puts
    # InputStream Adaptive into manual-OSD selection, so nothing is
    # auto-picked and trailers play with video but no sound. This only
    # corrects that specific inconsistency; it does not override the
    # user's DASH choice. See resources/lib/youtube_setup.py.
    try:
        from resources.lib import youtube_setup
        youtube_setup.enforce_stream_select()
    except Exception:
        pass

    # Re-apply the TMDb Helper next-episodes sync fix. Their sync crashes
    # on a null watched count, and because the failed sync is never cached
    # it re-runs on every widget refresh, repeatedly taking over the
    # bottom-right notification slot from SuperLite and Trailer Finder.
    # TMDb Helper updates revert this, so like the AF3 patch it self-heals
    # on menu launch. Idempotent — no-op if already applied.
    try:
        from resources.lib import tmdbhelper_patch
        tmdbhelper_patch.apply_patch()
    except Exception:
        pass

    # Install any add-on we bundle that is missing. Kodi repositories only
    # ever offer UPDATES for add-ons already installed, so anything newly
    # added to the repo stays missing on existing installs unless we ask
    # for it explicitly. This is why Up Next never arrived despite being
    # published in June. No-op once present.
    try:
        installer.ensure_bundled_addons()
    except Exception:
        pass

    # Make a4kSubtitles the default subtitle service if nothing is set yet
    # (so existing installs get subtitle search working after it self-heals
    # in above). Conditional, so it never clobbers a manual choice.
    try:
        installer._configure_subtitles()
    except Exception:
        pass

    while True:
        items = [
            'Install Build (full setup)',
            'Authorize Real Debrid',
            'Authorize AllDebrid',
            'Authorize Trakt',
            'Enter API Keys (web page, from your laptop/phone)',
            'Configure Scrapers',
            'Configure Skins',
            'Refresh Player Config (run after MP Build updates)',
            'Fix YouTube Trailer Playback (no sound / buzzing)',
            'Apply TMDb Helper Sync Fix (force re-apply)',
            'Clear TMDb Helper Cache (fix missing seasons/episodes)',
            'View MP Log (Up Next / Trakt / playback)',
            'Capture Config Snapshot (curator only)',
            'Reset & Reinstall',
            'About',
            'Exit',
        ]
        idx = xbmcgui.Dialog().select(ADDON_NAME, items)
        if idx < 0 or idx == 15:
            return
        try:
            if idx == 0:
                installer.run_full_install()
                # After a successful full install, exit the menu entirely.
                # If we returned to the menu loop here, the menu picker would
                # re-display on top of whatever final dialog the install flow
                # left behind — most importantly Kodi's "Keep this skin?"
                # 10-second countdown after the skin switch. installer.py's
                # run_full_install() already shows its own completion dialog
                # before triggering the skin switch, so no extra notification
                # needed here.
                return
            elif idx == 1:
                debrid_setup.authorize_rd()
            elif idx == 2:
                debrid_setup.authorize_ad()
            elif idx == 3:
                trakt_setup.authorize_trakt()
            elif idx == 4:
                from resources.lib import webconfig
                webconfig.open_web_entry()
            elif idx == 5:
                scraper_setup.configure()
            elif idx == 6:
                skin_setup.configure()
            elif idx == 7:
                _refresh_player_config()
            elif idx == 8:
                from resources.lib import youtube_setup
                youtube_setup.apply_trailer_profile()
            elif idx == 9:
                from resources.lib import tmdbhelper_patch
                tmdbhelper_patch.apply_patch_with_feedback()
            elif idx == 10:
                _clear_tmdbhelper_cache()
            elif idx == 11:
                from resources.lib import webconfig
                webconfig.show_log_viewer()
            elif idx == 12:
                _capture_snapshot()
            elif idx == 13:
                installer.reset_and_reinstall()
            elif idx == 14:
                about.show()
        except Exception as e:
            import traceback
            xbmc.log('[mpbuild] menu error: {0}\n{1}'.format(e, traceback.format_exc()),
                     xbmc.LOGERROR)
            xbmcgui.Dialog().ok(ADDON_NAME,
                                'An error occurred. Check kodi.log for details.')


def _clear_tmdbhelper_cache():
    """
    Delete TMDb Helper's metadata cache so it re-fetches fresh data. Fixes
    shows whose seasons/episodes come up incomplete — usually caused by the
    shared public TMDB key being rate-limited, which caches partial/failed
    responses. Keeps settings, the API key, players and Trakt auth; only the
    cache databases are removed. Kodi restarts to release DB locks and
    rebuild cleanly.
    """
    import os
    import shutil
    import xbmcvfs

    base = xbmcvfs.translatePath(
        'special://profile/addon_data/plugin.video.themoviedb.helper/')
    if not os.path.isdir(base):
        xbmcgui.Dialog().ok(ADDON_NAME, 'TMDb Helper is not installed.')
        return
    if not xbmcgui.Dialog().yesno(
            ADDON_NAME,
            "Clear TMDb Helper's metadata cache?[CR][CR]"
            'This fixes shows that come up with missing seasons or episodes. '
            'Your settings, API key and Trakt login are kept.[CR][CR]'
            'Tip: for a lasting fix, also enter your own free TMDB API key '
            'via "Enter API Keys" — the shared key gets rate-limited, which '
            'is what causes the gaps.',
            yeslabel='Clear Cache', nolabel='Cancel'):
        return

    removed = 0
    for name in os.listdir(base):
        low = name.lower()
        if (low.startswith('database_') or low.endswith('.db')
                or low in ('cache', 'tmdb_cache', 'blur_v2', 'crop_v2')):
            path = os.path.join(base, name)
            try:
                if os.path.isdir(path):
                    shutil.rmtree(path, ignore_errors=True)
                else:
                    os.remove(path)
                removed += 1
            except Exception as e:
                xbmc.log('[mpbuild] could not remove {0}: {1}'.format(path, e),
                         xbmc.LOGWARNING)
    xbmc.log('[mpbuild] cleared {0} TMDb Helper cache item(s)'.format(removed),
             xbmc.LOGINFO)
    if xbmcgui.Dialog().yesno(
            ADDON_NAME,
            'Cleared {0} cache item(s).[CR][CR]'
            'Restart Kodi now to finish rebuilding the metadata cache?'
            .format(removed),
            yeslabel='Restart', nolabel='Later'):
        xbmc.executebuiltin('RestartApp')


def _capture_snapshot():
    """
    Run the config-capture flow. Intended for the build curator —
    end users don't need this. Captures their current Kodi config
    (skin layout, addon settings, etc.), strips per-user secrets,
    and saves a snapshot zip they can commit to their repo.
    """
    from resources.lib import capture
    capture.capture()


def _refresh_player_config():
    """
    Re-drop the TMDb Helper player JSON, then prompt the user to
    restart Kodi so TMDb Helper picks up the fresh file.
    TMDb Helper caches parsed player files in memory; only a Kodi
    restart guarantees the new config takes effect.
    """
    from resources.lib import installer
    ok = installer._install_tmdbhelper_player()
    if not ok:
        xbmcgui.Dialog().ok(ADDON_NAME,
                            'Could not write player config. '
                            'Check kodi.log for details.')
        return
    yes = xbmcgui.Dialog().yesno(
        ADDON_NAME,
        'Player config refreshed.[CR][CR]'
        'TMDb Helper caches player files in memory. To apply the new '
        'config, Kodi needs to restart now.[CR][CR]'
        'Restart Kodi?',
        yeslabel='Restart Kodi', nolabel='Later')
    if yes:
        xbmc.executebuiltin('RestartApp')


if __name__ == '__main__':
    _menu_loop()
