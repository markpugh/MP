# -*- coding: utf-8 -*-
"""
YouTube add-on playback configuration.

Two settings in plugin.video.youtube interact badly and produce trailers
that play with no sound. Both were hit on this build in August 2026.

1. kodion.mpd.videos ("Use MPEG-DASH for videos")

   With DASH on, the add-on requests separate adaptive audio and video
   tracks through its local proxy. When the add-on is not signed in,
   YouTube refuses the audio track with HTTP 403 while still serving
   video, so playback runs with a starved audio pipeline. Kodi then logs
   a runaway "ActiveAE - large audio sync error" and the result is a
   loud buzz. Turning DASH off asks for a single muxed stream instead
   and avoids the split entirely, at the cost of maximum resolution.

2. kodion.video.stream.select ("Stream selection")

   This is the trap. It is only consulted when DASH is OFF, and its
   default is 2 ("list"). See xbmc_items.py:

       stream_select = settings.stream_select()
       if not use_mpd and 'list' in stream_select:
           props['inputstream.adaptive.stream_selection_type'] = 'manual-osd'
       elif 'auto' in stream_select:
           props['inputstream.adaptive.stream_selection_type'] = 'adaptive'

   So the moment DASH is switched off, InputStream Adaptive is put into
   manual OSD selection and stops auto-picking ANY stream. Video starts,
   audio does not, and the only way to get sound is to open the OSD and
   choose a stream by hand. On an HLS manifest typed "live" (YouTube
   serves plenty of these, 15 video + 2 audio streams is normal) manual
   selection often fails outright.

The invariant this module enforces is therefore:

    if MPEG-DASH is off, stream selection MUST be auto.

That rule is always correct and never overrides a deliberate quality
choice: it says nothing about whether DASH should be on, only that the
two settings must not be left in the combination that kills audio.

apply_trailer_profile() is the heavier hammer, run explicitly from the
menu, which also turns DASH off for reliable trailer playback.

NOTE: this module deliberately does NOT touch the API key, client id or
client secret. Those are per-user secrets and must never ship in the
repo. Set them via the add-on's own API config page (Advanced > HTTP
server, then browse to http://<device-ip>:<port>/youtube/api).
"""
import xbmc
import xbmcaddon
import xbmcgui

YOUTUBE_ID = 'plugin.video.youtube'

SETTING_MPD = 'kodion.mpd.videos'
SETTING_STREAM_SELECT = 'kodion.video.stream.select'

STREAM_SELECT_AUTO = '1'   # 'auto' -> stream_selection_type = adaptive
STREAM_SELECT_LIST = '2'   # 'list' -> stream_selection_type = manual-osd


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log('[mpbuild][youtube] {0}'.format(msg), level=level)


def _addon():
    """Return the YouTube add-on, or None if it isn't installed."""
    try:
        return xbmcaddon.Addon(YOUTUBE_ID)
    except Exception:
        return None


def _get(addon, key):
    try:
        return (addon.getSetting(key) or '').strip()
    except Exception:
        return ''


def _set(addon, key, value):
    try:
        addon.setSetting(key, value)
        return True
    except Exception as e:
        _log('could not set {0}={1}: {2}'.format(key, value, e), xbmc.LOGWARNING)
        return False


def enforce_stream_select(quiet=True):
    """
    Self-heal: if DASH is off, force stream selection to auto.

    Safe to call on every menu launch. Returns True if it changed
    something, False if already consistent or not applicable.
    """
    addon = _addon()
    if addon is None:
        return False

    mpd = _get(addon, SETTING_MPD).lower()
    # An empty value means the setting is still at its default (true).
    dash_off = mpd == 'false'
    if not dash_off:
        return False

    current = _get(addon, SETTING_STREAM_SELECT)
    if current == STREAM_SELECT_AUTO:
        return False

    _log('MPEG-DASH is off but stream selection is {0!r}; forcing auto so '
         'InputStream Adaptive picks an audio track (otherwise trailers '
         'play silent until a stream is chosen in the OSD).'.format(current))
    if not _set(addon, SETTING_STREAM_SELECT, STREAM_SELECT_AUTO):
        return False

    if not quiet:
        xbmcgui.Dialog().notification(
            'MP Build', 'YouTube stream selection set to Auto',
            xbmcgui.NOTIFICATION_INFO, 3000)
    return True


def apply_trailer_profile():
    """
    Explicit menu action: put the YouTube add-on into the configuration
    that plays trailers reliably on this build.

    Turns MPEG-DASH off (avoids the 403'd split audio track) and sets
    stream selection to auto (avoids manual-osd). Reports what changed.
    """
    addon = _addon()
    if addon is None:
        xbmcgui.Dialog().ok(
            'MP Build',
            'The YouTube add-on (plugin.video.youtube) is not installed.')
        return False

    changed = []

    if _get(addon, SETTING_MPD).lower() != 'false':
        if _set(addon, SETTING_MPD, 'false'):
            changed.append('MPEG-DASH: off')

    if _get(addon, SETTING_STREAM_SELECT) != STREAM_SELECT_AUTO:
        if _set(addon, SETTING_STREAM_SELECT, STREAM_SELECT_AUTO):
            changed.append('Stream selection: Auto')

    if changed:
        _log('applied trailer profile: {0}'.format(', '.join(changed)))
        xbmcgui.Dialog().ok(
            'MP Build',
            'YouTube playback settings updated:[CR][CR]'
            + '[CR]'.join(changed)
            + '[CR][CR]Trailers should now play with sound. Video quality '
              'is capped lower while MPEG-DASH is off.')
    else:
        xbmcgui.Dialog().ok(
            'MP Build',
            'YouTube playback settings are already correct.[CR][CR]'
            'MPEG-DASH: off[CR]Stream selection: Auto')
    return True
