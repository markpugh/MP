# -*- coding: utf-8 -*-
"""
MP Build — API-key web entry.

A tiny, LAN-only web page served from the Kodi box so the user can type
API keys/tokens from a laptop or phone instead of pecking them in with a
remote. It is the manual alternative to the QR device-login flows; those
stay exactly as they were.

Security model (home-LAN tool, deliberately simple):
  - Off by default. Controlled by MP Build's `webconfig_enabled` setting;
    the startup service starts/stops this server to match that toggle.
  - Every URL carries a random token; requests without it get 404.
  - Only non-secret fields (the TMDB key) are pre-filled. Secret fields
    render blank and are only written when you actually type something, so
    an empty box never wipes an existing token.
  - Submitting the page writes the settings, then flips `webconfig_enabled`
    back off — which tells the service to stop the server.

This module owns the HTTP server only. The service (service.py) owns the
on/off lifecycle, and default.py shows the URL + QR.
"""
import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

import xbmc
import xbmcaddon
import xbmcgui

from resources.lib.common import log, log_error

ADDON = xbmcaddon.Addon()

# Window property the service publishes the live URL on, so the menu/QR
# dialog can show it without knowing the port or token.
PROP_URL = 'MPBuild.WebConfigURL'

DEFAULT_PORT = 8766


# --- Toggle + URL helpers (shared by the service, menu, and wizard) -------
def is_enabled():
    try:
        return ADDON.getSettingBool('webconfig_enabled')
    except Exception:
        return (ADDON.getSetting('webconfig_enabled') or '').lower() == 'true'


def set_enabled(value):
    """Flip the MP Build toggle. The service reacts and starts/stops."""
    try:
        ADDON.setSettingBool('webconfig_enabled', bool(value))
    except Exception:
        ADDON.setSetting('webconfig_enabled', 'true' if value else 'false')


def get_port():
    try:
        return max(1024, min(65535, ADDON.getSettingInt('webconfig_port')))
    except Exception:
        return DEFAULT_PORT


def local_ip():
    """Best-effort LAN IP of this box.

    xbmc.getIPAddress() comes back empty on a lot of Android TV boxes, so
    we try the socket route first: open a UDP socket toward a public
    address (no packets are actually sent) and read back the LAN interface
    the OS would route through.
    """
    import socket
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
        s.close()
        if ip and not ip.startswith('127.'):
            return ip
    except Exception:
        pass
    try:
        ip = xbmc.getIPAddress() or ''
        if ip and not ip.startswith('127.'):
            return ip
    except Exception:
        pass
    return '127.0.0.1'


def build_url(port):
    return 'http://{0}:{1}/'.format(local_ip(), port)


def publish_url(url):
    xbmcgui.Window(10000).setProperty(PROP_URL, url or '')


def read_url():
    try:
        return xbmcgui.Window(10000).getProperty(PROP_URL) or ''
    except Exception:
        return ''


def clear_url():
    try:
        xbmcgui.Window(10000).clearProperty(PROP_URL)
    except Exception:
        pass


def open_web_entry(timeout=600):
    """
    Turn the web page on, then show a QR + URL dialog on the TV. The
    startup service actually runs the server; we just wait for it to
    publish the URL. When the user submits the page (or cancels), the
    toggle goes off and this returns. Reuses the existing QR auth dialog.

    Returns True if a save was detected, False otherwise.
    """
    set_enabled(True)
    url = ''
    for _ in range(30):  # up to ~15s for the service to come up
        url = read_url()
        if url:
            break
        xbmc.sleep(500)
    if not url:
        set_enabled(False)
        xbmcgui.Dialog().ok(
            'MP Build',
            'Could not start the key-entry web page.[CR][CR]'
            'The MP Build background service needs to be running. Restart '
            'Kodi and try again.')
        return False

    def poll_fn():
        # The page flips the toggle off on submit; that closes this dialog.
        return 'ok' if not is_enabled() else 'pending'

    try:
        from resources.lib.auth.dialog import show_qr_auth
        success, _error = show_qr_auth(
            title='Enter API Keys On Your Phone / Laptop',
            url=url, code='', qr_data=url,
            poll_fn=poll_fn, expires_in=timeout, poll_interval=2)
    except Exception as e:
        log_error('web entry dialog failed: {0}'.format(e))
        success = False

    # Always leave it off afterwards, submitted or not.
    set_enabled(False)
    return success


# Field spec. Each field writes to one or more (addon_id, setting_id)
# targets. `secret=True` means: never pre-fill, and only write when the
# submitted value is non-empty (blank = keep current).
#
# (name, label, help, targets, secret)
FIELDS = [
    ('tmdb_key', 'TMDB API Key',
     'themoviedb.org / Settings / API (the short v3 key, not the read token). '
     'Used by SuperSearch, TMDb Helper and SuperLite.',
     [('plugin.video.themoviedb.helper', 'tmdb_apikey'),
      ('plugin.video.mpsupersearch', 'tmdb_api_key'),
      ('plugin.video.mpsuperlite', 'tmdb_api_key')], False),
    ('rd_token', 'Real-Debrid API Token',
     'real-debrid.com/apitoken — the typed alternative to the Real-Debrid QR login.',
     [('plugin.video.mpsuperlite', 'rd_access_token')], True),
    ('ad_key', 'AllDebrid API Key',
     'alldebrid.com/apikeys — the typed alternative to the AllDebrid QR login.',
     [('plugin.video.mpsuperlite', 'ad_apikey')], True),
    ('trakt_id', 'Trakt Client ID',
     'trakt.tv/oauth/applications — create an app (redirect uri '
     'urn:ietf:wg:oauth:2.0:oob), then paste its Client ID here. After '
     'saving, run SuperLite settings > Trakt > Connect to finish login.',
     [('plugin.video.mpsuperlite', 'trakt_client_id')], True),
    ('trakt_secret', 'Trakt Client Secret',
     'The Client Secret from the same Trakt application.',
     [('plugin.video.mpsuperlite', 'trakt_client_secret')], True),
    ('yt_key', 'YouTube API Key',
     'Google Cloud console — for trailer playback (optional).',
     [('plugin.video.youtube', 'youtube.api.key')], True),
    ('yt_id', 'YouTube Client ID',
     'Google Cloud OAuth client id (optional).',
     [('plugin.video.youtube', 'youtube.api.id')], True),
    ('yt_secret', 'YouTube Client Secret',
     'Google Cloud OAuth client secret (optional).',
     [('plugin.video.youtube', 'youtube.api.secret')], True),
]


def _current_value(targets):
    """Read the first readable current value for a field (for pre-fill)."""
    for addon_id, setting_id in targets:
        try:
            return xbmcaddon.Addon(addon_id).getSetting(setting_id) or ''
        except Exception:
            continue
    return ''


def _apply(values):
    """Write submitted values into the target add-on settings.

    Only non-empty values are written. Returns a list of human-readable
    labels that were actually saved.
    """
    saved = []
    for name, label, _help, targets, secret in FIELDS:
        val = (values.get(name) or '').strip()
        if not val:
            continue
        wrote = False
        for addon_id, setting_id in targets:
            try:
                xbmcaddon.Addon(addon_id).setSetting(setting_id, val)
                wrote = True
            except Exception as e:
                log_error('webconfig: could not write {0}.{1}: {2}'.format(
                    addon_id, setting_id, e))
        if wrote:
            saved.append(label)
    return saved


# --------------------------------------------------------------------------
# HTML
# --------------------------------------------------------------------------
_PAGE = u"""<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>MP Build — API Keys</title>
<style>
  :root {{ --paper:#f4eacd; --ink:#1a1410; --yellow:#ffd23f; --blue:#2c6be8;
           --red:#e8402c; }}
  * {{ box-sizing:border-box; }}
  body {{ margin:0; background:var(--paper);
    background-image:radial-gradient(rgba(44,107,232,.10) 1.4px, transparent 1.5px);
    background-size:14px 14px; color:var(--ink);
    font-family:"Comic Sans MS","Segoe Print",system-ui,sans-serif; }}
  .wrap {{ max-width:640px; margin:0 auto; padding:24px 18px 60px; }}
  h1 {{ font-size:42px; margin:.2em 0 0; letter-spacing:1px; }}
  h1 .pow {{ color:var(--blue); }}
  p.sub {{ margin:.2em 0 1.4em; font-weight:bold; }}
  .card {{ background:#fffaf0; border:4px solid var(--ink); border-radius:18px;
    padding:16px 16px 6px; margin:0 0 18px; box-shadow:6px 6px 0 rgba(26,20,16,.18); }}
  label {{ display:block; font-weight:bold; margin:10px 0 4px; }}
  .hint {{ font-weight:normal; font-size:13px; opacity:.75; }}
  input[type=text] {{ width:100%; padding:11px 12px; font-size:16px;
    border:3px solid var(--ink); border-radius:12px; background:#fff; }}
  .note {{ font-size:13px; opacity:.7; margin:-2px 0 8px; }}
  button {{ font:inherit; font-size:20px; font-weight:bold; cursor:pointer;
    background:var(--yellow); color:var(--ink); border:4px solid var(--ink);
    border-radius:14px; padding:12px 28px; box-shadow:4px 4px 0 rgba(26,20,16,.25); }}
  button:active {{ transform:translate(2px,2px); box-shadow:2px 2px 0 rgba(26,20,16,.25); }}
  .ok {{ background:#eafbea; border-color:#1a7a1a; }}
  .foot {{ font-size:12px; opacity:.6; margin-top:18px; }}
  a {{ color:var(--blue); }}
</style></head>
<body><div class="wrap">
  <h1>MP <span class="pow">BUILD</span></h1>
  <p class="sub">Type your API keys here, then hit Save. This page turns itself
    off afterwards.</p>
  <form method="post" action="{action}">
    {fields}
    <button type="submit">SAVE KEYS</button>
  </form>
  <p class="foot">Real-Debrid, AllDebrid and Trakt can also be set up with the
    QR code on the TV. Leave a box blank to keep its current value. Served only
    on your local network.</p>
</div></body></html>"""

_FIELD = u"""<div class="card">
  <label for="{name}">{label}</label>
  <div class="note">{help}</div>
  <input type="text" id="{name}" name="{name}" value="{value}"
         autocomplete="off" autocapitalize="off" spellcheck="false"
         placeholder="{placeholder}">
</div>"""

_DONE = u"""<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Saved</title>
<style>body{{margin:0;background:#f4eacd;color:#1a1410;
 font-family:"Comic Sans MS","Segoe Print",system-ui,sans-serif;}}
 .wrap{{max-width:560px;margin:0 auto;padding:40px 18px;}}
 .card{{background:#eafbea;border:4px solid #1a7a1a;border-radius:18px;padding:20px;}}
 h1{{font-size:36px;margin:0 0 8px;}}</style></head>
<body><div class="wrap"><div class="card">
<h1>Saved! ✔</h1>
<p><b>{summary}</b></p>
<p>You can close this tab. The key-entry page has switched itself back off
on the Kodi box.</p>
</div></div></body></html>"""


def _esc(s):
    return (s or '').replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;')


def _render_form(action):
    rows = []
    for name, label, help_, targets, secret in FIELDS:
        value = '' if secret else _esc(_current_value(targets))
        placeholder = 'leave blank to keep current' if secret else ''
        rows.append(_FIELD.format(name=name, label=_esc(label), help=_esc(help_),
                                  value=value, placeholder=placeholder))
    return _PAGE.format(action=action, fields='\n'.join(rows))


# --------------------------------------------------------------------------
# Server
# --------------------------------------------------------------------------
class _Server(ThreadingHTTPServer):
    daemon_threads = True
    # carries: .on_saved (callable)


class _Handler(BaseHTTPRequestHandler):
    def _send(self, body, status=200, ctype='text/html; charset=utf-8'):
        data = body.encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        try:
            self.wfile.write(data)
        except Exception:
            pass

    def do_GET(self):
        self._send(_render_form('/save'))

    def do_POST(self):
        try:
            length = int(self.headers.get('Content-Length', 0))
        except (TypeError, ValueError):
            length = 0
        raw = self.rfile.read(length) if length else b''
        parsed = parse_qs(raw.decode('utf-8', 'replace'))
        values = {k: (v[0] if v else '') for k, v in parsed.items()}
        saved = _apply(values)
        summary = ('Saved: ' + ', '.join(saved)) if saved else \
                  'Nothing changed (all boxes were blank).'
        self._send(_DONE.format(summary=_esc(summary)))
        # Flip the toggle off; the service stops the server when it sees this.
        try:
            if self.server.on_saved:
                self.server.on_saved()
        except Exception as e:
            log_error('webconfig on_saved failed: {0}'.format(e))

    def log_message(self, fmt, *args):
        # Route to Kodi log instead of stderr.
        try:
            log('[webconfig] ' + (fmt % args))
        except Exception:
            pass


class WebConfig(object):
    """Owns the HTTP server thread. The service creates one of these."""

    def __init__(self):
        self._srv = None
        self._thread = None

    @property
    def running(self):
        return self._srv is not None

    def start(self, port, on_saved=None):
        if self._srv is not None:
            return True
        try:
            srv = _Server(('0.0.0.0', int(port)), _Handler)
            srv.on_saved = on_saved
            t = threading.Thread(target=srv.serve_forever, name='mp-webconfig',
                                 daemon=True)
            t.start()
            self._srv, self._thread = srv, t
            log('[webconfig] serving on port {0}'.format(port))
            return True
        except Exception as e:
            log_error('webconfig could not start on port {0}: {1}'.format(port, e))
            self._srv = None
            return False

    def stop(self):
        if self._srv is None:
            return
        try:
            self._srv.shutdown()
            self._srv.server_close()
            log('[webconfig] stopped')
        except Exception as e:
            log_error('webconfig stop error: {0}'.format(e))
        finally:
            self._srv = None
            self._thread = None
