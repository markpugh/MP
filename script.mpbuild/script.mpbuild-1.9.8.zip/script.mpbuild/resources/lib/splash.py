# -*- coding: utf-8 -*-
"""
Splash dialog. Shows a branded fullscreen image for a given duration,
then auto-closes. Used as the welcome screen at the start of the install
flow, and as the MP SuperSearch boot splash.
"""
import xbmc
import xbmcaddon
import xbmcgui


ADDON = xbmcaddon.Addon()

# Window property DialogSplash.xml reads the image path from. Set on Home
# rather than on the dialog because it has to exist before the dialog is
# constructed, and Home outlives the dialog.
PROP = 'MPBuild.SplashImage'

# SuperSearch ships its own branding; the suite splash lives here in MP
# Build. special:// so it resolves wherever the add-on is installed.
SUPERSEARCH_SPLASH = ('special://home/addons/plugin.video.mpsupersearch'
                      '/resources/media/splash.jpg')


class _Splash(xbmcgui.WindowXMLDialog):
    """Just an image. No interaction. Auto-closes via the runner."""
    def __init__(self, *args, **kwargs):
        super(_Splash, self).__init__(*args, **kwargs)


def show(duration_seconds=2.5, image=None):
    """
    Display the splash for `duration_seconds`, then close.

    image: optional special:// or filesystem path. When omitted the
    dialog falls back to the bundled splash.jpg (the suite splash).

    Implementation note: WindowXMLDialog.doModal() blocks until close, so
    we use show() (non-blocking) + sleep + close() to control timing.
    """
    home = xbmcgui.Window(10000)
    try:
        home.setProperty(PROP, image or '')
        dialog = _Splash('DialogSplash.xml',
                         ADDON.getAddonInfo('path'),
                         'default', '1080i')
        dialog.show()
        # waitForAbort returns True if Kodi is shutting down — bail early
        monitor = xbmc.Monitor()
        monitor.waitForAbort(duration_seconds)
        dialog.close()
        del dialog
    except Exception as e:
        xbmc.log('[mpbuild] splash failed: {0}'.format(e), xbmc.LOGWARNING)
    finally:
        # Always clear, or the next splash inherits this image.
        try:
            home.clearProperty(PROP)
        except Exception:
            pass
