# -*- coding: utf-8 -*-
"""
Debrid setup. Reuses the auth flows already built into MP SuperLite — we
don't duplicate the QR dialog code, we just trigger the SuperLite actions
that run them.

We invoke them via plugin URL so SuperLite's QR dialog renders inside
SuperLite's own context (its skin file, its log tags, its credential
storage).
"""
import xbmc
import xbmcaddon
import xbmcgui


SUPERLITE = 'plugin.video.mpsuperlite'


def _is_authorized(action):
    """
    Check SuperLite's stored credentials by reading SuperLite's settings
    directly. This works because settings persist via xbmcaddon.Addon and
    don't require importing SuperLite's modules.
    """
    try:
        sl = xbmcaddon.Addon(SUPERLITE)
        if action == 'rd':
            return bool(sl.getSetting('rd_access_token'))
        if action == 'ad':
            return bool(sl.getSetting('ad_apikey'))
    except Exception:
        return False
    return False


def _trigger_action(action):
    """Run a SuperLite auth action via plugin URL."""
    url = 'plugin://{0}/?action={1}'.format(SUPERLITE, action)
    xbmc.executebuiltin('RunPlugin({0})'.format(url))


def _wait_for_auth(action, timeout=600):
    """
    Poll SuperLite's credential storage. Returns True when the action's
    credentials show up (user completed the QR/PIN), or False on timeout.
    """
    import time
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            sl = xbmcaddon.Addon(SUPERLITE)
            # Reload settings since SuperLite writes them in another process
            if action == 'rd' and sl.getSetting('rd_access_token'):
                return True
            if action == 'ad' and sl.getSetting('ad_apikey'):
                return True
        except Exception:
            pass
        xbmc.sleep(1500)
    return False


def authorize_rd():
    """Standalone Real Debrid authorization."""
    if _is_authorized('rd'):
        yes = xbmcgui.Dialog().yesno(
            'Real Debrid',
            'Real Debrid is already authorized. Reauthorize?',
            yeslabel='Reauthorize', nolabel='Cancel')
        if not yes:
            return
        _trigger_action('auth_rd_clear')
        xbmc.sleep(500)

    xbmcgui.Dialog().notification(
        'MP Build',
        'Opening Real Debrid authorization...',
        xbmcgui.NOTIFICATION_INFO, 2500)
    _trigger_action('auth_rd')


def authorize_ad():
    """Standalone AllDebrid authorization."""
    if _is_authorized('ad'):
        yes = xbmcgui.Dialog().yesno(
            'AllDebrid',
            'AllDebrid is already authorized. Reauthorize?',
            yeslabel='Reauthorize', nolabel='Cancel')
        if not yes:
            return
        _trigger_action('auth_ad_clear')
        xbmc.sleep(500)

    xbmcgui.Dialog().notification(
        'MP Build',
        'Opening AllDebrid authorization...',
        xbmcgui.NOTIFICATION_INFO, 2500)
    _trigger_action('auth_ad')


def run_setup_wizard():
    """
    Called from the full install flow. Asks the user which debrids they
    have, walks them through each. Both are recommended for max coverage
    but neither is required.
    """
    intro = xbmcgui.Dialog().yesno(
        'Debrid Setup',
        'MP SuperLite needs Real Debrid OR AllDebrid to play sources.[CR][CR]'
        'Both work great. Authorizing both gives you more cached sources.[CR][CR]'
        'Set up debrid services now?',
        yeslabel='Set Up', nolabel='Skip')
    if not intro:
        xbmcgui.Dialog().notification(
            'MP Build',
            'Skipped debrid setup — run later from MP Build menu.',
            xbmcgui.NOTIFICATION_INFO, 4000)
        return

    # Real Debrid — QR code, web page, or skip.
    _debrid_step(
        'rd', 'Real Debrid',
        'Set up Real Debrid?[CR][CR]'
        'QR Code: scan with your phone (or visit real-debrid.com/device) '
        'and enter the code.[CR]'
        'Web Page: type your API token from your laptop '
        '(real-debrid.com/apitoken).')

    # AllDebrid — QR code, web page, or skip.
    _debrid_step(
        'ad', 'AllDebrid',
        'Set up AllDebrid?[CR][CR]'
        'QR Code: same flow as Real Debrid (QR + PIN).[CR]'
        'Web Page: type your API key from your laptop '
        '(alldebrid.com/apikeys).')


def _debrid_step(action, title, message):
    """One wizard step: QR login, laptop web page, or skip."""
    # yesnocustom -> 1 = yes (QR), 2 = custom (Web Page), 0 = no (Skip),
    # -1 = cancelled.
    choice = xbmcgui.Dialog().yesnocustom(
        title, message,
        customlabel='Web Page', nolabel='Skip', yeslabel='QR Code')
    if choice == 2:
        try:
            from resources.lib import webconfig
            webconfig.open_web_entry()
        except Exception:
            xbmcgui.Dialog().ok('MP Build', 'Could not open the web page.')
        return
    if choice != 1:
        return
    _trigger_action('auth_{0}'.format(action))
    if _wait_for_auth(action, timeout=600):
        xbmcgui.Dialog().notification(
            title, 'Authorized successfully!',
            xbmcgui.NOTIFICATION_INFO, 3000)
    else:
        xbmcgui.Dialog().notification(
            title, 'Authorization not completed.',
            xbmcgui.NOTIFICATION_WARNING, 3000)
