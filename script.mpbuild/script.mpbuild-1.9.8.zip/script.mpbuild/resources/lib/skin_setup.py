# -*- coding: utf-8 -*-
"""
Skin configuration. The MP Build ships its own skin (skin.mp, a rebranded
Estuary fork with a comic-book look that boots into MP SuperSearch). This
module just lets the user switch between skin.mp and stock Estuary at any
time.
"""
import json

import xbmc
import xbmcgui


SKIN_MP = 'skin.mp'
SKIN_ESTUARY = 'skin.estuary'


def _jsonrpc(method, params=None):
    body = {'jsonrpc': '2.0', 'method': method, 'id': 1}
    if params is not None:
        body['params'] = params
    raw = xbmc.executeJSONRPC(json.dumps(body))
    try:
        return json.loads(raw).get('result')
    except Exception:
        return None


def _addon_installed(addon_id):
    res = _jsonrpc('Addons.GetAddonDetails', {
        'addonid': addon_id,
        'properties': ['enabled', 'installed'],
    })
    if not res:
        return False
    addon = res.get('addon') or {}
    return bool(addon.get('installed') and addon.get('enabled'))


def _switch_to(skin_id, label):
    res = _jsonrpc('Settings.SetSettingValue', {
        'setting': 'lookandfeel.skin',
        'value': skin_id,
    })
    if res is True:
        # Don't show a notification here — Kodi's "Keep this skin?"
        # 10-second confirm dialog appears the moment the skin changes,
        # and our notification would overlap it.
        return True
    xbmcgui.Dialog().ok('MP Build',
        'Could not switch automatically.[CR][CR]'
        'Try Settings > Interface > Skin manually.')
    return False


def configure():
    """Re-runnable from the MP Build menu."""
    items = [
        'Switch to MP skin (comic-book, boots into SuperSearch)',
        'Switch to Estuary (default Kodi)',
        'Cancel',
    ]
    idx = xbmcgui.Dialog().select('Skin Configuration', items)
    if idx < 0 or idx == 2:
        return

    if idx == 0:
        if not _addon_installed(SKIN_MP):
            xbmcgui.Dialog().ok('MP Build',
                'The MP skin isn\'t installed.[CR][CR]'
                'Run "Install Build (full setup)" from the MP Build menu '
                'to install it.')
            return
        _switch_to(SKIN_MP, 'MP')
    elif idx == 1:
        _switch_to(SKIN_ESTUARY, 'Estuary')
