# -*- coding: utf-8 -*-
"""
MP Build installer.

Run from Kodi's Programs add-ons menu. Presents a menu of actions:
- Install Build (chains everything: install addons, authorize debrids, configure scrapers)
- Authorize Real Debrid
- Authorize AllDebrid
- Configure Scrapers
- Reset & Reinstall
- About

Uses the addon's resources/lib/ submodules for the actual work.
"""
import sys

import xbmc
import xbmcaddon
import xbmcgui


ADDON = xbmcaddon.Addon()
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_PATH = ADDON.getAddonInfo('path')
sys.path.insert(0, ADDON_PATH)


def _menu_loop():
    """Show the main menu repeatedly until the user picks Cancel."""
    from resources.lib import installer, debrid_setup, trakt_setup, scraper_setup, skin_setup, about

    # On every launch, re-drop the TMDb Helper player JSON. This keeps
    # existing installs in sync when we ship player-config fixes — they
    # don't have to re-run the full installer for the new JSON to land.
    # Idempotent: if the file is already current, this is a no-op cost.
    try:
        installer._install_tmdbhelper_player()
    except Exception:
        pass  # never block the menu over this

    # Also re-pin script.skinvariables to our shipped 2.2.1. Kodi
    # background updates can silently replace this with upstream
    # 2.1.35 which breaks AF3's video-addon-as-widget-source picker.
    # Re-pinning at every menu launch ensures drift gets corrected
    # the next time the user touches MP Build.
    try:
        installer._force_pin_skinvariables()
    except Exception:
        pass

    # Re-apply AF3 context menu trailer patch. AF3 updates can wipe
    # this; re-applying on menu launch self-heals. Idempotent — no-op
    # if already patched.
    try:
        from resources.lib import trailer_patch
        trailer_patch.apply_patch()
    except Exception:
        pass

    while True:
        items = [
            'Install Build (full setup)',
            'Authorize Real Debrid',
            'Authorize AllDebrid',
            'Authorize Trakt',
            'Configure Scrapers',
            'Configure Skins',
            'Refresh Player Config (run after MP Build updates)',
            'Apply AF3 Trailer Patch (force re-apply)',
            'Capture Config Snapshot (curator only)',
            'Reset & Reinstall',
            'About',
            'Exit',
        ]
        idx = xbmcgui.Dialog().select(ADDON_NAME, items)
        if idx < 0 or idx == 11:
            return
        try:
            if idx == 0:
                installer.run_full_install()
                # After a successful full install, exit the menu entirely.
                # If we returned to the menu loop here, the menu picker would
                # re-display on top of whatever final dialog the install flow
                # left behind — most importantly Kodi's "Keep this skin?"
                # 10-second countdown after the skin switch. installer.py's
                # run_full_install() already shows its own completion dialog
                # before triggering the skin switch, so no extra notification
                # needed here.
                return
            elif idx == 1:
                debrid_setup.authorize_rd()
            elif idx == 2:
                debrid_setup.authorize_ad()
            elif idx == 3:
                trakt_setup.authorize_trakt()
            elif idx == 4:
                scraper_setup.configure()
            elif idx == 5:
                skin_setup.configure()
            elif idx == 6:
                _refresh_player_config()
            elif idx == 7:
                from resources.lib import trailer_patch
                trailer_patch.apply_patch_with_feedback()
            elif idx == 8:
                _capture_snapshot()
            elif idx == 9:
                installer.reset_and_reinstall()
            elif idx == 10:
                about.show()
        except Exception as e:
            import traceback
            xbmc.log('[mpbuild] menu error: {0}\n{1}'.format(e, traceback.format_exc()),
                     xbmc.LOGERROR)
            xbmcgui.Dialog().ok(ADDON_NAME,
                                'An error occurred. Check kodi.log for details.')


def _capture_snapshot():
    """
    Run the config-capture flow. Intended for the build curator —
    end users don't need this. Captures their current Kodi config
    (skin layout, addon settings, etc.), strips per-user secrets,
    and saves a snapshot zip they can commit to their repo.
    """
    from resources.lib import capture
    capture.capture()


def _refresh_player_config():
    """
    Re-drop the TMDb Helper player JSON, then prompt the user to
    restart Kodi so TMDb Helper picks up the fresh file.
    TMDb Helper caches parsed player files in memory; only a Kodi
    restart guarantees the new config takes effect.
    """
    from resources.lib import installer
    ok = installer._install_tmdbhelper_player()
    if not ok:
        xbmcgui.Dialog().ok(ADDON_NAME,
                            'Could not write player config. '
                            'Check kodi.log for details.')
        return
    yes = xbmcgui.Dialog().yesno(
        ADDON_NAME,
        'Player config refreshed.[CR][CR]'
        'TMDb Helper caches player files in memory. To apply the new '
        'config, Kodi needs to restart now.[CR][CR]'
        'Restart Kodi?',
        yeslabel='Restart Kodi', nolabel='Later')
    if yes:
        xbmc.executebuiltin('RestartApp')


if __name__ == '__main__':
    _menu_loop()
