# -*- coding: utf-8 -*-
"""
Core installer. Drives Kodi's addon manager via JSON-RPC to install each
addon from the MP repo in dependency order, then runs follow-up steps
(auth wizards, scraper config).

Why JSON-RPC instead of executebuiltin('InstallAddon')? executebuiltin
returns immediately without telling us whether it succeeded — we'd have
no way to wait for completion or detect failure. JSON-RPC's
Addons.SetAddonEnabled and the file-system check pattern lets us verify
each step.
"""
import json
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs


# Order matters — dependencies first
INSTALL_ORDER = [
    # ResolveURL pulls in script.module.six and script.module.kodi-six
    # automatically since they're declared as <import> deps in its addon.xml,
    # so we don't need to install those separately. Same for cocoscrapers.
    ('script.module.resolveurl', 'ResolveURL (host resolver)'),
    ('script.module.cocoscrapers', 'CocoScrapers (torrent scrapers)'),
    ('plugin.video.mpsuperlite', 'MP SuperLite (playback engine)'),
    ('plugin.video.mpsupersearch', 'MP SuperSearch (discovery UI)'),
]


# Default settings to apply post-install. Per-addon-id, key->value.
DEFAULT_SETTINGS = {
    'plugin.video.mpsuperlite': {
        'cached_only': 'false',
        'auto_play': 'true',
        'prefer_hevc': 'true',
        'debrid_priority': '0',   # RD-first
        'max_attempts': '10',
        'max_size': '3',          # 12GB cap (sane default for laptops)
        'quality_max': '1',       # 1080p
    },
    'plugin.video.mpsupersearch': {
        # SuperSearch already has good defaults baked in; nothing to override
    },
    'script.module.cocoscrapers': {
        'debug.enabled': 'true',  # Keep this on so future diagnostics work
        'debug.location': '0',    # 0 = Kodi log, 1 = separate file
    },
}


def _jsonrpc(method, params=None):
    """Call Kodi's JSON-RPC API. Returns parsed result dict, or None on error."""
    body = {'jsonrpc': '2.0', 'method': method, 'id': 1}
    if params is not None:
        body['params'] = params
    raw = xbmc.executeJSONRPC(json.dumps(body))
    try:
        return json.loads(raw).get('result')
    except Exception:
        xbmc.log('[mpbuild] JSON-RPC parse fail: {0}'.format(raw), xbmc.LOGERROR)
        return None


def _addon_installed(addon_id):
    """True if Kodi knows about this addon (installed and enabled)."""
    res = _jsonrpc('Addons.GetAddonDetails', {
        'addonid': addon_id,
        'properties': ['enabled', 'installed'],
    })
    if not res:
        return False
    addon = res.get('addon') or {}
    return bool(addon.get('installed') and addon.get('enabled'))


def _install_addon(addon_id, progress=None, current_pct=0):
    """
    Install an addon by ID. The addon must be available in a configured
    repository (we pre-add the MP repo so anything in there resolves).

    Returns True on success.
    """
    # Already installed? skip.
    if _addon_installed(addon_id):
        xbmc.log('[mpbuild] {0} already installed'.format(addon_id), xbmc.LOGINFO)
        return True

    if progress:
        try:
            progress.update(current_pct, 'Installing {0}...'.format(addon_id))
        except Exception:
            pass

    # Trigger install. executebuiltin('InstallAddon(id)') opens a Yes/No
    # dialog the first time. That's annoying for an installer. We use the
    # raw addon URL approach: set Addons.GetAddons params and let kodi
    # install via repo lookup + executebuiltin together.
    xbmc.executebuiltin('InstallAddon({0})'.format(addon_id), wait=True)

    # Poll for installation up to 60s
    deadline = time.time() + 60
    while time.time() < deadline:
        if _addon_installed(addon_id):
            xbmc.log('[mpbuild] {0} installed OK'.format(addon_id), xbmc.LOGINFO)
            return True
        xbmc.sleep(1000)

    xbmc.log('[mpbuild] {0} install timeout'.format(addon_id), xbmc.LOGERROR)
    return False


def _disable_unknown_sources_warning():
    """
    Set Kodi's general settings to skip the "unknown sources" prompt.
    Without this, every addon install asks the user "are you sure?"

    Kodi 21 settings:
      - addons.unknownsources : true     (allows installs from non-official repos)
      - general.addonnotifications : false (no toast spam)
    """
    _jsonrpc('Settings.SetSettingValue', {
        'setting': 'addons.unknownsources',
        'value': True,
    })
    _jsonrpc('Settings.SetSettingValue', {
        'setting': 'general.addonnotifications',
        'value': False,
    })


def _apply_default_settings():
    """Walk DEFAULT_SETTINGS and apply each via xbmcaddon."""
    for addon_id, settings in DEFAULT_SETTINGS.items():
        if not settings:
            continue
        try:
            addon = xbmcaddon.Addon(addon_id)
        except Exception:
            xbmc.log('[mpbuild] cant get addon {0} for settings'.format(addon_id),
                     xbmc.LOGWARNING)
            continue
        for key, value in settings.items():
            try:
                addon.setSetting(key, value)
            except Exception as e:
                xbmc.log('[mpbuild] failed setting {0}.{1}={2}: {3}'.format(
                    addon_id, key, value, e), xbmc.LOGWARNING)


def run_full_install():
    """Main flow: confirm -> prep -> install all -> auth -> configure scrapers -> done."""
    # Splash first — branded welcome before the install dialog
    try:
        from resources.lib import splash
        splash.show(duration_seconds=2.5)
    except Exception as e:
        xbmc.log('[mpbuild] splash display failed (non-fatal): {0}'.format(e),
                 xbmc.LOGWARNING)

    yes = xbmcgui.Dialog().yesno(
        'MP Build Installer',
        'This will install:[CR]'
        '  - ResolveURL[CR]'
        '  - CocoScrapers[CR]'
        '  - MP SuperLite (playback)[CR]'
        '  - MP SuperSearch (discovery)[CR]'
        '  - Arctic Horizon 2 + Arctic Fuse 3 (skins)[CR][CR]'
        'Then optionally walk you through Real Debrid and AllDebrid '
        'authorization, configure scraper providers, and let you pick '
        'a skin.[CR][CR]'
        'Continue?',
        yeslabel='Install', nolabel='Cancel')
    if not yes:
        return

    progress = xbmcgui.DialogProgress()
    progress.create('MP Build Installer', 'Preparing...')

    try:
        # Step 1: clear UX hurdles
        progress.update(5, 'Configuring Kodi addon settings...')
        _disable_unknown_sources_warning()

        # Step 2: install each addon in order
        total = len(INSTALL_ORDER)
        for i, (addon_id, label) in enumerate(INSTALL_ORDER):
            if progress.iscanceled():
                progress.close()
                xbmcgui.Dialog().ok('MP Build', 'Installation cancelled.')
                return
            pct = 10 + int(60 * i / total)
            progress.update(pct,
                            'Installing {0}...[CR]({1}/{2})'.format(label, i + 1, total))
            ok = _install_addon(addon_id, progress=progress, current_pct=pct)
            if not ok:
                progress.close()
                xbmcgui.Dialog().ok('MP Build',
                    'Failed to install {0}.[CR][CR]Make sure the MP repository '
                    'is added and try again.'.format(label))
                return

        # Step 3: apply default settings
        progress.update(75, 'Applying default settings...')
        _apply_default_settings()

        # Step 4: optional debrid auth
        progress.update(80, 'Ready for debrid authorization...')
        progress.close()

        from resources.lib import debrid_setup
        debrid_setup.run_setup_wizard()

        # Step 5: optional scraper config
        from resources.lib import scraper_setup
        scraper_setup.run_setup_wizard()

        # Step 6: optional skin install + pick
        from resources.lib import skin_setup
        skin_setup.run_setup_wizard()

        # Done
        xbmcgui.Dialog().ok(
            'MP Build',
            'Setup complete![CR][CR]'
            'You can launch MP SuperSearch from Add-ons > Video add-ons '
            'to start browsing.[CR][CR]'
            'To re-run any of these steps, launch MP Build from Programs.')

    finally:
        try:
            progress.close()
        except Exception:
            pass


def reset_and_reinstall():
    """Uninstall everything MP and start over."""
    yes = xbmcgui.Dialog().yesno(
        'MP Build Reset',
        'This will UNINSTALL MP SuperLite, MP SuperSearch, ResolveURL, '
        'and CocoScrapers, then reinstall fresh.[CR][CR]'
        'Your debrid credentials and settings will be LOST.[CR][CR]Continue?',
        yeslabel='Reset', nolabel='Cancel')
    if not yes:
        return

    # Uninstall in REVERSE dependency order
    for addon_id, _ in reversed(INSTALL_ORDER):
        try:
            xbmc.executebuiltin('UninstallAddon({0},true)'.format(addon_id), wait=True)
        except Exception as e:
            xbmc.log('[mpbuild] uninstall {0}: {1}'.format(addon_id, e), xbmc.LOGWARNING)

    xbmc.sleep(1500)
    run_full_install()
