# -*- coding: utf-8 -*-
"""
Skin installation. Installs jurialmunkey's repo (which hosts both
Arctic Horizon 2 and Arctic Fuse 3), then installs both skins. After
installation, prompts the user to pick which one to switch to.

Approach:
- Download jurialmunkey's repo zip via urllib
- Extract directly into Kodi's addons/ directory
- Trigger UpdateLocalAddons so Kodi re-scans
- Install each skin via the now-available repo
- Show a Yes/No/None picker at the end so the user chooses
"""
import json
import os
import time
import zipfile

try:
    from urllib.request import urlopen, Request
except ImportError:
    from urllib2 import urlopen, Request

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs


JM_REPO_ID = 'repository.jurialmunkey'
# Pinned version. If jurialmunkey bumps this, we update the URL.
JM_REPO_ZIP_URL = 'https://jurialmunkey.github.io/repository.jurialmunkey/repository.jurialmunkey-3.4.zip'

SKINS = {
    'ah2': {
        'id': 'skin.arctic.horizon.2',
        'name': 'Arctic Horizon 2',
        'description': 'Classic build look (archived)',
    },
    'af3': {
        'id': 'skin.arctic.fuse.3',
        'name': 'Arctic Fuse 3',
        'description': 'Newer, actively maintained',
    },
}


def _jsonrpc(method, params=None):
    body = {'jsonrpc': '2.0', 'method': method, 'id': 1}
    if params is not None:
        body['params'] = params
    raw = xbmc.executeJSONRPC(json.dumps(body))
    try:
        return json.loads(raw).get('result')
    except Exception:
        return None


def _addon_installed(addon_id):
    res = _jsonrpc('Addons.GetAddonDetails', {
        'addonid': addon_id,
        'properties': ['enabled', 'installed'],
    })
    if not res:
        return False
    addon = res.get('addon') or {}
    return bool(addon.get('installed') and addon.get('enabled'))


def _ensure_repo_installed():
    """Idempotently install jurialmunkey's repo."""
    if _addon_installed(JM_REPO_ID):
        return True

    temp_dir = xbmcvfs.translatePath('special://temp/')
    zip_path = os.path.join(temp_dir, 'repository.jurialmunkey.zip')
    xbmc.log('[mpbuild] downloading jurialmunkey repo...', xbmc.LOGINFO)

    try:
        req = Request(JM_REPO_ZIP_URL,
                      headers={'User-Agent': 'Kodi/MPBuild'})
        with urlopen(req, timeout=30) as resp:
            data = resp.read()
        with open(zip_path, 'wb') as f:
            f.write(data)
    except Exception as e:
        xbmc.log('[mpbuild] repo download failed: {0}'.format(e), xbmc.LOGERROR)
        return False

    addons_dir = xbmcvfs.translatePath('special://home/addons/')
    try:
        with zipfile.ZipFile(zip_path, 'r') as z:
            top_names = set(n.split('/')[0] for n in z.namelist() if n)
            if JM_REPO_ID not in top_names:
                xbmc.log('[mpbuild] repo zip layout unexpected: {0}'.format(top_names),
                         xbmc.LOGERROR)
                return False
            z.extractall(addons_dir)
    except Exception as e:
        xbmc.log('[mpbuild] extraction failed: {0}'.format(e), xbmc.LOGERROR)
        return False

    xbmc.executebuiltin('UpdateLocalAddons', wait=True)

    deadline = time.time() + 15
    while time.time() < deadline:
        if _addon_installed(JM_REPO_ID):
            xbmc.log('[mpbuild] jurialmunkey repo installed', xbmc.LOGINFO)
            return True
        xbmc.sleep(1500)

    xbmc.log('[mpbuild] repo extracted but not visible after 15s', xbmc.LOGWARNING)
    return False


def _install_skin_addon(skin_key):
    skin = SKINS[skin_key]
    if _addon_installed(skin['id']):
        return True

    xbmc.executebuiltin('InstallAddon({0})'.format(skin['id']), wait=True)

    # Skins have many deps so they take longer
    deadline = time.time() + 120
    while time.time() < deadline:
        if _addon_installed(skin['id']):
            return True
        xbmc.sleep(2500)
    return False


def _switch_to_skin(skin_key):
    skin = SKINS.get(skin_key)
    if not skin:
        return False
    res = _jsonrpc('Settings.SetSettingValue', {
        'setting': 'lookandfeel.skin',
        'value': skin['id'],
    })
    return res is True


def install_both_and_choose():
    """Install both skins, prompt user to pick."""
    progress = xbmcgui.DialogProgressBG()
    progress.create('MP Build', 'Setting up skins...')

    try:
        progress.update(10, 'Adding jurialmunkey repository...')
        if not _ensure_repo_installed():
            progress.close()
            xbmcgui.Dialog().ok('MP Build',
                'Could not install the jurialmunkey repository.[CR][CR]'
                'Skin install skipped. Re-run from MP Build > Configure Skins.')
            return False

        results = {}
        for i, (key, skin) in enumerate(SKINS.items()):
            pct = 25 + int(60 * (i + 1) / len(SKINS))
            progress.update(pct, 'Installing {0}...'.format(skin['name']))
            ok = _install_skin_addon(key)
            results[key] = ok
            xbmc.log('[mpbuild] skin {0}: {1}'.format(skin['name'],
                'installed' if ok else 'FAILED'), xbmc.LOGINFO)

        progress.update(95, 'Done.')
    finally:
        try:
            progress.close()
        except Exception:
            pass

    installed_keys = [k for k, ok in results.items() if ok]
    if not installed_keys:
        xbmcgui.Dialog().ok('MP Build',
            'No skins installed successfully.[CR][CR]'
            'Check your network and try again from MP Build > Configure Skins.')
        return False

    if len(installed_keys) == 1:
        only_key = installed_keys[0]
        only_skin = SKINS[only_key]
        msg = ('Only {0} installed (the other failed).[CR][CR]'
               'Switch to it now?').format(only_skin['name'])
        if xbmcgui.Dialog().yesno('MP Build', msg, yeslabel='Switch', nolabel='Later'):
            _switch_to_skin(only_key)
        return True

    # Both installed — let user pick. AF3 first as recommended.
    options = []
    keys = []
    for key in ['af3', 'ah2']:
        if key in installed_keys:
            skin = SKINS[key]
            options.append('{0} ({1})'.format(skin['name'], skin['description']))
            keys.append(key)
    options.append('Keep current skin (Estuary)')

    idx = xbmcgui.Dialog().select('Pick your skin', options, preselect=0)
    if idx < 0 or idx == len(options) - 1:
        return True

    chosen_key = keys[idx]
    if _switch_to_skin(chosen_key):
        xbmcgui.Dialog().notification(
            'MP Build',
            'Switched to {0}!'.format(SKINS[chosen_key]['name']),
            xbmcgui.NOTIFICATION_INFO, 3000)
    else:
        xbmcgui.Dialog().ok('MP Build',
            'Skin installed but couldn\'t switch automatically.[CR][CR]'
            'Go to Settings > Interface > Skin to switch manually.')
    return True


def configure():
    """Re-runnable from the MP Build menu."""
    items = [
        'Install both skins and choose',
        'Switch to Arctic Fuse 3',
        'Switch to Arctic Horizon 2',
        'Switch back to Estuary (default)',
        'Cancel',
    ]
    idx = xbmcgui.Dialog().select('Skin Configuration', items)
    if idx < 0 or idx == 4:
        return

    if idx == 0:
        install_both_and_choose()
    elif idx == 1:
        if not _addon_installed(SKINS['af3']['id']):
            if xbmcgui.Dialog().yesno('MP Build',
                'Arctic Fuse 3 isn\'t installed. Install both skins now?',
                yeslabel='Install', nolabel='Cancel'):
                install_both_and_choose()
            return
        if _switch_to_skin('af3'):
            xbmcgui.Dialog().notification('MP Build', 'Switched to Arctic Fuse 3!',
                xbmcgui.NOTIFICATION_INFO, 3000)
    elif idx == 2:
        if not _addon_installed(SKINS['ah2']['id']):
            if xbmcgui.Dialog().yesno('MP Build',
                'Arctic Horizon 2 isn\'t installed. Install both skins now?',
                yeslabel='Install', nolabel='Cancel'):
                install_both_and_choose()
            return
        if _switch_to_skin('ah2'):
            xbmcgui.Dialog().notification('MP Build', 'Switched to Arctic Horizon 2!',
                xbmcgui.NOTIFICATION_INFO, 3000)
    elif idx == 3:
        res = _jsonrpc('Settings.SetSettingValue', {
            'setting': 'lookandfeel.skin', 'value': 'skin.estuary',
        })
        if res is True:
            xbmcgui.Dialog().notification('MP Build', 'Switched to Estuary',
                xbmcgui.NOTIFICATION_INFO, 3000)


def run_setup_wizard():
    """Called from the full install flow. Installs both, prompts pick."""
    yes = xbmcgui.Dialog().yesno(
        'Skin Setup',
        'Install Arctic Horizon 2 and Arctic Fuse 3? You\'ll pick which '
        'one to use at the end.[CR][CR]'
        'AF3 is newer and actively maintained; AH2 is the classic build '
        'look. Both add a polished home screen with widgets and '
        'Netflix-style browsing.[CR][CR]'
        'Total install: about 2 minutes.',
        yeslabel='Install', nolabel='Skip')
    if yes:
        install_both_and_choose()
