# -*- coding: utf-8 -*-
"""
MP Build installer.

Run from Kodi's Programs add-ons menu. Presents a menu of actions:
- Install Build (chains everything: install addons, authorize debrids, configure scrapers)
- Authorize Real Debrid
- Authorize AllDebrid
- Configure Scrapers
- Reset & Reinstall
- About

Uses the addon's resources/lib/ submodules for the actual work.
"""
import sys

import xbmc
import xbmcaddon
import xbmcgui


ADDON = xbmcaddon.Addon()
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_PATH = ADDON.getAddonInfo('path')
sys.path.insert(0, ADDON_PATH)


def _menu_loop():
    """Show the main menu repeatedly until the user picks Cancel."""
    from resources.lib import installer, debrid_setup, scraper_setup, skin_setup, about

    # On every launch, re-drop the TMDb Helper player JSON. This keeps
    # existing installs in sync when we ship player-config fixes — they
    # don't have to re-run the full installer for the new JSON to land.
    # Idempotent: if the file is already current, this is a no-op cost.
    try:
        installer._install_tmdbhelper_player()
    except Exception:
        pass  # never block the menu over this

    while True:
        items = [
            'Install Build (full setup)',
            'Authorize Real Debrid',
            'Authorize AllDebrid',
            'Configure Scrapers',
            'Configure Skins',
            'Refresh Player Config (run after MP Build updates)',
            'Capture Config Snapshot (curator only)',
            'Reset & Reinstall',
            'About',
            'Exit',
        ]
        idx = xbmcgui.Dialog().select(ADDON_NAME, items)
        if idx < 0 or idx == 9:
            return
        try:
            if idx == 0:
                installer.run_full_install()
            elif idx == 1:
                debrid_setup.authorize_rd()
            elif idx == 2:
                debrid_setup.authorize_ad()
            elif idx == 3:
                scraper_setup.configure()
            elif idx == 4:
                skin_setup.configure()
            elif idx == 5:
                _refresh_player_config()
            elif idx == 6:
                _capture_snapshot()
            elif idx == 7:
                installer.reset_and_reinstall()
            elif idx == 8:
                about.show()
        except Exception as e:
            import traceback
            xbmc.log('[mpbuild] menu error: {0}\n{1}'.format(e, traceback.format_exc()),
                     xbmc.LOGERROR)
            xbmcgui.Dialog().ok(ADDON_NAME,
                                'An error occurred. Check kodi.log for details.')


def _capture_snapshot():
    """
    Run the config-capture flow. Intended for the build curator —
    end users don't need this. Captures their current Kodi config
    (skin layout, addon settings, etc.), strips per-user secrets,
    and saves a snapshot zip they can commit to their repo.
    """
    from resources.lib import capture
    capture.capture()


def _refresh_player_config():
    """
    Re-drop the TMDb Helper player JSON, then prompt the user to
    restart Kodi so TMDb Helper picks up the fresh file.
    TMDb Helper caches parsed player files in memory; only a Kodi
    restart guarantees the new config takes effect.
    """
    from resources.lib import installer
    ok = installer._install_tmdbhelper_player()
    if not ok:
        xbmcgui.Dialog().ok(ADDON_NAME,
                            'Could not write player config. '
                            'Check kodi.log for details.')
        return
    yes = xbmcgui.Dialog().yesno(
        ADDON_NAME,
        'Player config refreshed.[CR][CR]'
        'TMDb Helper caches player files in memory. To apply the new '
        'config, Kodi needs to restart now.[CR][CR]'
        'Restart Kodi?',
        yeslabel='Restart Kodi', nolabel='Later')
    if yes:
        xbmc.executebuiltin('RestartApp')


if __name__ == '__main__':
    _menu_loop()
