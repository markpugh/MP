# -*- coding: utf-8 -*-
"""
Trakt API client for the MP Trakt Helper.

Thin wrapper around the Trakt v2 API. Handles the authenticated request
layer (api key + bearer token + automatic token refresh) and the handful
of endpoints the build actually needs:

  - watched progress for a show  -> what you've seen / what's next
  - add episodes to history      -> mark watched
  - scrobble start/pause/stop    -> real-time "watching now" + auto-watched

Everything is best-effort: a missing token, a network blip, or a non-2xx
response returns a falsy/empty result and logs, never raises into the
player/service path.

Credentials: the user registers a Trakt application (trakt.tv/oauth/
applications, redirect uri urn:ietf:wg:oauth:2.0:oob) and pastes its
client id + secret into settings (or the web config). The device-code
flow in trakt/auth.py turns those into access/refresh tokens.
"""
import json

import requests

from resources.lib.common import log, log_error, now_ts
from resources.lib.auth import storage

API = 'https://api.trakt.tv'
_TIMEOUT = 12

# Cache tmdb-show-id -> trakt id for the session so we don't hit /search
# on every episode. Lives only in-process (fine; it's a pure id map).
_ID_CACHE = {}

# --- Borrowing TMDb Helper's existing Trakt login ---------------------------
# The build already logs into Trakt through TMDb Helper, so by default we
# reuse THAT token instead of asking the user to register a second Trakt app
# and log in again. TMDb Helper stores its authorization as a JSON blob in
# its own `trakt_token` setting ({access_token, refresh_token, expires_in,
# created_at}) and issues it against its own registered app. We read that
# token and use TMDb Helper's client id as the api key. When it's expired we
# refresh it (with TMDb Helper's app creds) and write the new token back to
# TMDb Helper's setting, so both add-ons stay in sync.
#
# A user who doesn't use TMDb Helper for Trakt can still connect MP directly
# (trakt/auth.py device-code flow) — that MP-owned token then takes priority.
_TMDBH_ID = 'plugin.video.themoviedb.helper'
# Known values, used only if we can't read them from TMDb Helper's source.
_TMDBH_FALLBACK_ID = 'e6fde6173adf3c6af8fd1b0694b9b84d7c519cefc24482310e1de06c6abe5467'
_TMDBH_FALLBACK_SECRET = '15119384341d9a61c751d8d515acbc0dd801001d4ebe85d3eef9885df80ee4d9'
_APP_CACHE = {}


def _tmdbh_addon():
    try:
        import xbmcaddon
        return xbmcaddon.Addon(_TMDBH_ID)
    except Exception:
        return None


def _tmdbh_app_creds():
    """TMDb Helper's Trakt app client id/secret. Read from its source so we
    track version changes, falling back to the known public values."""
    if _APP_CACHE:
        return _APP_CACHE
    cid = csec = ''
    a = _tmdbh_addon()
    if a:
        try:
            import os
            import re
            import xbmcvfs
            path = xbmcvfs.translatePath(a.getAddonInfo('path'))
            f = os.path.join(path, 'resources', 'tmdbhelper', 'lib', 'api',
                             'api_keys', 'trakt.py')
            if os.path.exists(f):
                txt = open(f, encoding='utf-8').read()
                m = re.search(r"CLIENT_ID\s*=\s*'([0-9a-fA-F]{32,80})'", txt)
                cid = m.group(1) if m else ''
                m = re.search(r"CLIENT_SECRET\s*=\s*'([0-9a-fA-F]{32,80})'", txt)
                csec = m.group(1) if m else ''
        except Exception as e:
            log('Could not read TMDb Helper Trakt app creds: {0}'.format(e))
    _APP_CACHE['client_id'] = cid or _TMDBH_FALLBACK_ID
    _APP_CACHE['client_secret'] = csec or _TMDBH_FALLBACK_SECRET
    return _APP_CACHE


def _tmdbh_token():
    """Read + parse TMDb Helper's stored Trakt token. Returns a dict with
    access_token/refresh_token/expires_at/raw, or {}."""
    a = _tmdbh_addon()
    if not a:
        return {}
    try:
        import json as _json
        raw = a.getSetting('trakt_token')
        if not raw:
            return {}
        d = _json.loads(raw)
        exp = int(d.get('created_at') or 0) + int(d.get('expires_in') or 0)
        return {
            'access_token': d.get('access_token') or '',
            'refresh_token': d.get('refresh_token') or '',
            'expires_at': exp,
            'raw': d,
        }
    except Exception:
        return {}


def _tmdbh_write_token(raw_dict):
    a = _tmdbh_addon()
    if not a:
        return
    try:
        import json as _json
        a.setSetting('trakt_token', _json.dumps(raw_dict))
    except Exception:
        pass


def _active_client_id():
    """The trakt-api-key to use: MP's own app if the user connected directly,
    otherwise TMDb Helper's app (whose token we're borrowing)."""
    own = storage.trakt_load()
    if own.get('access_token') and own.get('client_id'):
        return own['client_id']
    return _tmdbh_app_creds()['client_id']


def _headers(with_auth=True):
    h = {
        'Content-Type': 'application/json',
        'trakt-api-version': '2',
        'trakt-api-key': _active_client_id(),
    }
    if with_auth:
        tok = get_valid_access_token()
        if tok:
            h['Authorization'] = 'Bearer ' + tok
    return h


def using_tmdbhelper():
    """True when we're relying on TMDb Helper's Trakt login (no MP-own token)."""
    own = storage.trakt_load()
    if own.get('access_token'):
        return False
    return bool(_tmdbh_token().get('access_token'))


def is_configured():
    """True when MP can reach Trakt at all — either its own connection or a
    borrowable TMDb Helper login."""
    return is_authorized()


def is_authorized():
    if storage.trakt_is_authorized():
        return True
    return bool(_tmdbh_token().get('access_token'))


# ---------------------------------------------------------------------------
# Token lifecycle
# ---------------------------------------------------------------------------

def get_valid_access_token():
    """Return a live access token, refreshing if expired. '' on failure.

    Priority: MP's own device-flow token (if the user connected directly),
    then TMDb Helper's borrowed token.
    """
    # 1. MP's own token.
    own = storage.trakt_load()
    if own.get('access_token'):
        if own.get('expires_at', 0) > now_ts() + 60:
            return own['access_token']
        if own.get('refresh_token') and own.get('client_id') and own.get('client_secret'):
            tok = _refresh(own['refresh_token'], own['client_id'],
                           own['client_secret'])
            if tok:
                storage.trakt_save(tok.get('access_token'),
                                   tok.get('refresh_token'),
                                   tok.get('expires_in'))
                return tok.get('access_token') or ''
        # fall through to TMDb Helper if our own refresh failed

    # 2. Borrow TMDb Helper's token.
    t = _tmdbh_token()
    if not t.get('access_token'):
        return ''
    if t.get('expires_at', 0) > now_ts() + 60:
        return t['access_token']
    # Expired — refresh with TMDb Helper's app creds and write it back.
    if not t.get('refresh_token'):
        return ''
    app = _tmdbh_app_creds()
    tok = _refresh(t['refresh_token'], app['client_id'], app['client_secret'])
    if tok and tok.get('access_token'):
        new_raw = dict(t.get('raw') or {})
        new_raw.update(access_token=tok.get('access_token'),
                       refresh_token=tok.get('refresh_token'),
                       expires_in=tok.get('expires_in'),
                       created_at=tok.get('created_at') or int(now_ts()))
        _tmdbh_write_token(new_raw)
        return tok.get('access_token') or ''
    return ''


def _refresh(refresh_token, client_id, client_secret):
    try:
        r = requests.post(API + '/oauth/token', json={
            'refresh_token': refresh_token,
            'client_id': client_id,
            'client_secret': client_secret,
            'redirect_uri': 'urn:ietf:wg:oauth:2.0:oob',
            'grant_type': 'refresh_token',
        }, headers={'Content-Type': 'application/json'}, timeout=_TIMEOUT)
        if r.status_code != 200:
            log_error('Trakt token refresh status {0}'.format(r.status_code))
            return None
        return r.json()
    except Exception as e:
        log_error('Trakt token refresh failed: {0}'.format(e))
        return None


# ---------------------------------------------------------------------------
# Low-level request helpers
# ---------------------------------------------------------------------------

def _get(path, params=None, with_auth=True):
    try:
        r = requests.get(API + path, params=params or {},
                         headers=_headers(with_auth), timeout=_TIMEOUT)
        if r.status_code == 200:
            return r.json()
        log('Trakt GET {0} -> {1}'.format(path, r.status_code))
    except Exception as e:
        log_error('Trakt GET {0} failed: {1}'.format(path, e))
    return None


def _post(path, body):
    try:
        r = requests.post(API + path, data=json.dumps(body or {}),
                          headers=_headers(True), timeout=_TIMEOUT)
        if r.status_code in (200, 201, 204):
            try:
                return r.json()
            except Exception:
                return {}
        log('Trakt POST {0} -> {1}'.format(path, r.status_code))
    except Exception as e:
        log_error('Trakt POST {0} failed: {1}'.format(path, e))
    return None


# ---------------------------------------------------------------------------
# Show id resolution (tmdb/imdb -> trakt)
# ---------------------------------------------------------------------------

def show_trakt_id(tmdb_id=None, imdb_id=None):
    """Resolve a show to an id usable in /shows/{id}.

    Trakt resolves imdb ids directly in the path, so when we have the
    SHOW's imdb id we just use it. Otherwise look the show up by tmdb id
    via /search and cache the numeric trakt id.
    """
    if imdb_id and str(imdb_id).startswith('tt'):
        return str(imdb_id)
    if not tmdb_id:
        return None
    key = str(tmdb_id)
    if key in _ID_CACHE:
        return _ID_CACHE[key]
    data = _get('/search/tmdb/{0}'.format(tmdb_id), {'type': 'show'},
                with_auth=False)
    tid = None
    if data:
        try:
            tid = data[0]['show']['ids']['trakt']
        except (KeyError, IndexError, TypeError):
            tid = None
    if tid:
        _ID_CACHE[key] = tid
    return tid


# ---------------------------------------------------------------------------
# Watched progress / next-episode awareness
# ---------------------------------------------------------------------------

def show_progress(tmdb_id=None, imdb_id=None):
    """GET watched progress for a show.

    Returns the Trakt progress dict (with 'next_episode', 'last_episode',
    'aired', 'completed', 'seasons'), or None.
    """
    sid = show_trakt_id(tmdb_id, imdb_id)
    if not sid:
        return None
    return _get('/shows/{0}/progress/watched'.format(sid),
                {'specials': 'false', 'count_specials': 'false'})


def next_unwatched(tmdb_id=None, imdb_id=None):
    """Return (season, number) of the next unwatched episode per Trakt, or None."""
    prog = show_progress(tmdb_id, imdb_id)
    if not prog:
        return None
    nxt = prog.get('next_episode')
    if not nxt:
        return None
    try:
        return int(nxt['season']), int(nxt['number'])
    except (KeyError, TypeError, ValueError):
        return None


def is_episode_watched(tmdb_id, season, episode, imdb_id=None):
    """True if Trakt has this specific episode marked watched. Best-effort."""
    prog = show_progress(tmdb_id, imdb_id)
    if not prog:
        return False
    try:
        for s in prog.get('seasons') or []:
            if int(s.get('number')) != int(season):
                continue
            for e in s.get('episodes') or []:
                if int(e.get('number')) == int(episode):
                    return bool(e.get('completed'))
    except (TypeError, ValueError):
        pass
    return False


# ---------------------------------------------------------------------------
# Marking watched / scrobbling
# ---------------------------------------------------------------------------

def _ids(tmdb_id, imdb_id):
    ids = {}
    if imdb_id and str(imdb_id).startswith('tt'):
        ids['imdb'] = str(imdb_id)
    if tmdb_id:
        try:
            ids['tmdb'] = int(tmdb_id)
        except (TypeError, ValueError):
            pass
    return ids


def _scrobble_ref(ctx):
    """Build the Trakt scrobble/sync object from a now-playing context dict.

    ctx keys: type ('movie'|'tv'), tmdb_id, imdb_id, season, episode.
    For episodes the ids are the SHOW's; for movies the movie's. Returns
    None when we lack enough to identify the item.
    """
    ids = _ids(ctx.get('tmdb_id'), ctx.get('imdb_id'))
    if not ids:
        return None
    if ctx.get('type') == 'tv':
        try:
            season = int(ctx.get('season'))
            episode = int(ctx.get('episode'))
        except (TypeError, ValueError):
            return None
        return {'show': {'ids': ids},
                'episode': {'season': season, 'number': episode}}
    return {'movie': {'ids': ids}}


def scrobble(action, ctx, progress):
    """Scrobble start/pause/stop for a movie OR episode. Best-effort.

    action in ('start','pause','stop'). Trakt auto-marks the item watched
    when a 'stop' arrives with progress >= 80%, so this is also our primary
    'mark watched' path. Returns True on success.
    """
    if not is_authorized() or action not in ('start', 'pause', 'stop'):
        return False
    ref = _scrobble_ref(ctx or {})
    if not ref:
        return False
    body = dict(ref, progress=max(0.0, min(100.0, float(progress or 0))))
    res = _post('/scrobble/' + action, body)
    if res is not None:
        log('Trakt scrobble {0} @ {1:.0f}% ({2})'.format(
            action, float(progress or 0), ctx.get('type')))
        return True
    return False


def mark_watched(ctx):
    """Explicitly add a movie/episode to history (POST /sync/history).

    Fallback for cases where a scrobble 'stop' didn't land (e.g. Kodi
    killed the player before we could send it). Idempotent-ish: Trakt
    records a watch; we only call this when playback clearly completed.
    """
    if not is_authorized():
        return False
    ref = _scrobble_ref(ctx or {})
    if not ref:
        return False
    if ctx.get('type') == 'tv':
        body = {'shows': [dict(ref['show'], seasons=[{
            'number': ref['episode']['season'],
            'episodes': [{'number': ref['episode']['number']}],
        }])]}
    else:
        body = {'movies': [ref['movie']]}
    res = _post('/sync/history', body)
    if res is not None:
        log('Trakt: marked watched via history ({0})'.format(ctx.get('type')))
        return True
    return False
