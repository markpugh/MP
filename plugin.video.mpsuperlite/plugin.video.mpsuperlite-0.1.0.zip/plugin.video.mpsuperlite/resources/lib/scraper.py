# -*- coding: utf-8 -*-
"""
CocoScrapers wrapper. Translates our metadata dict into the format
CocoScrapers expects, runs the scrape, returns a normalized source list.

CocoScrapers is a Kodi script.module addon (declared as a <requires> in
addon.xml). It exposes a `sources()` factory + a `scrape()` method that
takes a metadata dict and returns a list of source dicts.

Source dict format (after our normalization):
  {
    'provider': 'magnetdl',
    'quality': '1080p' | '720p' | '4K' | 'SD',
    'size_gb': 4.2,
    'debrid': 'real_debrid' | 'all_debrid' | None,
    'cached': True | False,
    'hash': '...',          # for direct debrid lookup
    'url': '...',           # already-resolvable url, OR a magnet/torrent
    'language': 'en',
    'codec': 'h265' | 'h264' | None,
    'hdr': True | False,
    'release_title': 'Tucker.and.Dale.vs.Evil.2010.1080p...',
    '_raw': original_source_dict,   # kept around for ResolveURL
  }
"""
from resources.lib.common import log, log_warning, log_error


_QUALITY_BUCKETS = {
    '4k': '4K', '2160p': '4K', 'uhd': '4K',
    '1440p': '1080p',  # uncommon; treat as 1080p
    '1080p': '1080p',
    '720p': '720p',
    '480p': 'SD', '360p': 'SD', 'sd': 'SD', 'cam': 'SD',
}


def _normalize_quality(q):
    if not q:
        return 'SD'
    s = str(q).strip().lower()
    return _QUALITY_BUCKETS.get(s, 'SD')


def _detect_codec(release_title):
    if not release_title:
        return None
    t = release_title.lower()
    if 'x265' in t or 'h265' in t or 'hevc' in t:
        return 'h265'
    if 'x264' in t or 'h264' in t or 'avc' in t:
        return 'h264'
    return None


def _detect_hdr(release_title):
    if not release_title:
        return False
    t = release_title.lower()
    return any(tag in t for tag in (' hdr', '.hdr', '-hdr', 'dolby vision', 'dovi', 'hdr10'))


def _size_gb(s):
    """CocoScrapers reports size as either a number (GB) or a string like '2.4 GB'."""
    if s is None:
        return 0.0
    try:
        return float(s)
    except (ValueError, TypeError):
        pass
    try:
        s = str(s).lower().strip()
        if 'gb' in s:
            return float(s.replace('gb', '').strip())
        if 'mb' in s:
            return float(s.replace('mb', '').strip()) / 1024.0
    except Exception:
        return 0.0
    return 0.0


def _normalize(src):
    """Take a CocoScrapers source dict and normalize to our schema."""
    title = (src.get('name') or src.get('title') or src.get('release_title')
             or src.get('source') or '')
    debrid = None
    cached = False
    debrid_field = (src.get('debrid') or '').strip().lower() if isinstance(src.get('debrid'), str) else ''
    if debrid_field:
        if 'real' in debrid_field or debrid_field in ('rd', 'real-debrid', 'realdebrid'):
            debrid = 'real_debrid'
        elif 'all' in debrid_field or debrid_field in ('ad', 'all-debrid', 'alldebrid'):
            debrid = 'all_debrid'
        elif 'premium' in debrid_field:
            debrid = 'premiumize'
        else:
            debrid = debrid_field
        cached = True   # if debrid field is set, it's cached on that service
    return {
        'provider': src.get('provider') or src.get('source') or 'unknown',
        'quality': _normalize_quality(src.get('quality')),
        'size_gb': _size_gb(src.get('size')),
        'debrid': debrid,
        'cached': cached or bool(src.get('cached')),
        'hash': src.get('hash') or '',
        'url': src.get('url') or '',
        'language': src.get('language') or 'en',
        'codec': _detect_codec(title),
        'hdr': _detect_hdr(title),
        'release_title': title,
        '_raw': src,
    }


def scrape(meta, progress_cb=None):
    """
    meta: dict from tmdb.get_movie() or tmdb.get_episode().
    progress_cb: optional callable(percent, message) for the progress dialog.

    Returns a list of normalized source dicts (possibly empty).
    """
    try:
        from cocoscrapers import sources as cs_sources
    except ImportError as e:
        log_error('cocoscrapers import failed: {0}'.format(e))
        return []

    try:
        if progress_cb:
            progress_cb(10, 'Searching sources...')
        scraper = cs_sources()
        # CocoScrapers signature: scrape(title, year, imdb, tmdb=None, ...)
        # For TV: scrape(title, year, imdb, tvdb=None, season=None, episode=None, ...)
        if meta.get('mediatype') == 'episode':
            raw = scraper.scrape(
                meta.get('tvshowtitle') or meta.get('title') or '',
                meta.get('year') or 0,
                meta.get('imdb') or '',
                tvdb=meta.get('tvdb') or '',
                season=str(meta.get('season') or ''),
                episode=str(meta.get('episode') or ''),
                progress_callback=progress_cb,
            )
        else:
            raw = scraper.scrape(
                meta.get('title') or '',
                meta.get('year') or 0,
                meta.get('imdb') or '',
                tmdb=meta.get('tmdb') or '',
                progress_callback=progress_cb,
            )
    except TypeError:
        # Older CocoScrapers builds use a slightly different signature; fall
        # back to positional args without progress_callback.
        try:
            scraper = cs_sources()
            if meta.get('mediatype') == 'episode':
                raw = scraper.scrape(
                    meta.get('tvshowtitle') or '', meta.get('year') or 0,
                    meta.get('imdb') or '', meta.get('tvdb') or '',
                    str(meta.get('season') or ''), str(meta.get('episode') or '')
                )
            else:
                raw = scraper.scrape(
                    meta.get('title') or '', meta.get('year') or 0,
                    meta.get('imdb') or '', meta.get('tmdb') or ''
                )
        except Exception as e:
            log_error('cocoscrapers scrape failed: {0}'.format(e))
            return []
    except Exception as e:
        log_error('cocoscrapers scrape failed: {0}'.format(e))
        return []

    if not raw:
        log_warning('cocoscrapers returned no sources')
        return []

    sources = [_normalize(s) for s in raw]
    log('Scraped {0} sources for {1}'.format(len(sources), meta.get('title') or meta.get('tvshowtitle')))
    return sources
