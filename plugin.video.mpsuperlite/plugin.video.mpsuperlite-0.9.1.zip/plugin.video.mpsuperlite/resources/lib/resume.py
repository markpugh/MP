# -*- coding: utf-8 -*-
"""
Local resume store for silent auto-resume.

SuperLite owns playback (it hands Kodi a resolved stream URL), so nothing
else reliably remembers where you stopped — TMDb Helper's own resume path
depends on its Trakt sync, which doesn't hold a reliable per-stream second
offset for debrid URLs. This keeps our own tiny JSON of "last position" per
item, written by the playback service, and read back on the next start so we
can seek straight to it.

Why a flat JSON in the addon profile: it's a handful of entries, read/written
only by the service, and must survive a hard power-off (Xbox users just turn
the box off), so the service writes it periodically during playback, not only
on a clean stop.

Keying:
  movie:<tmdb_id>
  tv:<tmdb_id>:<season>:<episode>

A position is only kept while playback is in the "resumable window": far
enough in to matter, and not so far that the item is effectively finished
(>= the Trakt watched threshold). Crossing out of that window drops the
entry, so a finished item never offers a resume.
"""
import json
import os

from resources.lib.common import profile_dir, log, now_ts

_STORE = 'resume.json'

# Resumable window.
_MIN_SECONDS = 30.0     # must be at least this far in to bother storing
_MIN_PERCENT = 2.0
_MAX_PERCENT = 80.0     # matches the Trakt auto-watched threshold: past this
                        # the item counts as watched, so no resume
_PRUNE_AGE = 180 * 24 * 3600   # forget entries untouched for ~180 days


def _path():
    return os.path.join(profile_dir(), _STORE)


def _load():
    try:
        with open(_path(), 'r', encoding='utf-8') as f:
            d = json.load(f)
            return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def _save_all(d):
    try:
        with open(_path(), 'w', encoding='utf-8') as f:
            json.dump(d, f)
    except Exception as e:
        log('resume: store write failed: {0}'.format(e))


def key(ctx):
    """Build the store key from a now-playing context dict, or None."""
    if not ctx:
        return None
    tid = ctx.get('tmdb_id')
    if not tid:
        return None
    if ctx.get('type') == 'tv':
        return 'tv:{0}:{1}:{2}'.format(tid, ctx.get('season'), ctx.get('episode'))
    return 'movie:{0}'.format(tid)


def _prune(d):
    cutoff = now_ts() - _PRUNE_AGE
    stale = [k for k, v in d.items()
             if not isinstance(v, dict) or int(v.get('ts') or 0) < cutoff]
    for k in stale:
        d.pop(k, None)
    return d


def save(ctx, position, total):
    """Record (or drop) the resume point for ctx.

    Stores position when it's inside the resumable window; clears any stored
    point when it isn't (too early, or finished). Best-effort — never raises.
    """
    k = key(ctx)
    try:
        position = float(position or 0)
        total = float(total or 0)
    except (TypeError, ValueError):
        return
    if not k or total <= 0:
        return
    pct = position / total * 100.0
    if position < _MIN_SECONDS or pct < _MIN_PERCENT or pct > _MAX_PERCENT:
        clear(ctx)
        return
    d = _prune(_load())
    d[k] = {'position': int(position), 'total': int(total), 'ts': now_ts()}
    _save_all(d)


def get(ctx):
    """Return the stored resume entry {position,total,ts} for ctx, or None."""
    k = key(ctx)
    if not k:
        return None
    return _load().get(k)


def clear(ctx):
    """Drop any stored resume point for ctx."""
    k = key(ctx)
    if not k:
        return
    d = _load()
    if k in d:
        d.pop(k, None)
        _save_all(d)
