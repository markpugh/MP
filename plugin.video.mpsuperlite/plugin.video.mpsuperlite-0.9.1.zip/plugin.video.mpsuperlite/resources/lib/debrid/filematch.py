# -*- coding: utf-8 -*-
"""
Pick the right file out of a multi-file (season-pack) torrent.

THE BUG THIS FIXES: Torrentio is queried per-episode (imdb:S:E) and its
pre-resolved URL targets the correct file inside a pack via a fileIdx baked
into the URL. But when that cached URL goes stale and we have to RE-RESOLVE
the torrent ourselves through RD/AD, the old code just grabbed the LARGEST
video file in the torrent. For a single-file torrent that's right; for a
SEASON PACK every episode is roughly the same size, so "largest" is
effectively random — you ask for S02E04 and get whatever episode happens to
be biggest. That's how Blue Lights played "way ahead" on the next episode.

The reliable fix is to identify the wanted file by its NAME (SxxExx / NxNN),
which doesn't depend on any index lining up. We fall back to Torrentio's
fileIdx (positional) and only then to largest-video, so single-file torrents
and movies are unaffected.
"""
import re

VIDEO_EXTS = ('.mp4', '.mkv', '.avi', '.m4v', '.mov', '.wmv', '.flv', '.ts', '.webm')


def is_video(name):
    low = (name or '').lower()
    return any(low.endswith(ext) for ext in VIDEO_EXTS)


def _episode_patterns(season, episode):
    """Regexes that match this specific episode in a release filename.

    Covers the common forms: S02E04, s2e4, S02.E04, S02 E04, 2x04. Each is
    anchored so S02E04 is NOT matched by a query for episode 4 of a file
    named ...E40..., and season 2 is not matched by season 20.
    """
    s = int(season)
    e = int(episode)
    return [
        re.compile(r's0*%d[. _-]{0,2}e0*%d(?!\d)' % (s, e), re.IGNORECASE),
        re.compile(r'(?<!\d)0*%dx0*%d(?!\d)' % (s, e), re.IGNORECASE),
    ]


def match_episode_indices(names, season, episode):
    """Indices into `names` whose filename matches the requested episode."""
    if season is None or episode is None:
        return []
    try:
        pats = _episode_patterns(season, episode)
    except (TypeError, ValueError):
        return []
    hits = []
    for i, n in enumerate(names):
        low = (n or '').lower()
        if any(p.search(low) for p in pats):
            hits.append(i)
    return hits


def choose_index(names, sizes, file_idx=None, season=None, episode=None):
    """Return the index of the file to play, or None if nothing usable.

    names:  list of filenames/paths (torrent file order where available)
    sizes:  parallel list of byte sizes (0 if unknown)
    file_idx: Torrentio's 0-based index into the torrent file list, or None
    season/episode: the episode the user actually asked for

    Priority:
      1. A video file whose NAME matches SxxExx/NxNN (pick the largest such,
         so a tiny same-named sample/subtitle never wins).
      2. The file at Torrentio's fileIdx position, if it's a video.
      3. The largest video file (single-file torrents, movies, or when all
         else is unknown) — the old behaviour, now only a last resort.
    """
    n = len(names)
    if n == 0:
        return None

    def _video_idxs(idxs):
        return [i for i in idxs if is_video(names[i])]

    # 1. Name match — the only index-independent, pack-safe signal.
    hits = _video_idxs(match_episode_indices(names, season, episode))
    if hits:
        return max(hits, key=lambda i: sizes[i] if i < len(sizes) else 0)

    # 2. Torrentio fileIdx (positional into torrent file order).
    if file_idx is not None:
        try:
            fi = int(file_idx)
        except (TypeError, ValueError):
            fi = None
        if fi is not None and 0 <= fi < n and is_video(names[fi]):
            return fi

    # 3. Largest video file (or largest file if none look like video).
    videos = _video_idxs(range(n))
    pool = videos if videos else list(range(n))
    if not pool:
        return None
    return max(pool, key=lambda i: sizes[i] if i < len(sizes) else 0)
