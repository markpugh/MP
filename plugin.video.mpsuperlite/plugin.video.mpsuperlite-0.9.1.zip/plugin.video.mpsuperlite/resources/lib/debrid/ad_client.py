# -*- coding: utf-8 -*-
"""
AllDebrid API client.

AD's magnet API is simpler than RD's — magnet/upload returns a `ready`
boolean indicating whether the torrent is cached. If false, we delete
the magnet and move on. If true, we fetch the file list and unlock the
largest video.

API reference: https://docs.alldebrid.com/

  GET /v4/magnet/upload?agent=&apikey=&magnets[]=    -> {data: {magnets: [{id, ready, hash, ...}]}}
  GET /v4/magnet/files?agent=&apikey=&id[]=          -> {data: {magnets: [{files: [...]}]}}
  GET /v4/link/unlock?agent=&apikey=&link=           -> {data: {link: 'https://...'}}
  GET /v4/magnet/delete?agent=&apikey=&id=
"""
import requests

from resources.lib.common import log, log_warning, log_error
from resources.lib.auth import storage as auth_storage


API_BASE = 'https://api.alldebrid.com/v4'
AGENT = 'mpsuperlite'

VIDEO_EXTS = ('.mp4', '.mkv', '.avi', '.m4v', '.mov', '.wmv', '.flv', '.ts', '.webm')


def _apikey():
    creds = auth_storage.ad_load()
    return creds.get('apikey', '')


def _api(path, params=None):
    apikey = _apikey()
    if not apikey:
        log_error('AD: no API key')
        return None
    p = dict(params or {})
    p.update({'agent': AGENT, 'apikey': apikey})
    try:
        r = requests.get(API_BASE + path, params=p, timeout=10)
        return r
    except Exception as e:
        log_error('AD GET {0} failed: {1}'.format(path, e))
        return None


def upload_magnet(magnet_or_hash):
    """
    Upload a magnet/hash. AD accepts hashes directly in the magnets[] param.
    Returns dict {id, ready, hash, files_count} or None on failure.
    """
    if not magnet_or_hash:
        return None
    r = _api('/magnet/upload', params={'magnets[]': magnet_or_hash})
    if not r or r.status_code != 200:
        return None
    try:
        body = r.json()
    except Exception:
        return None
    if body.get('status') != 'success':
        log_warning('AD upload returned status={0}: {1}'.format(
            body.get('status'), body.get('error', {}).get('message', '')))
        return None
    magnets = (body.get('data') or {}).get('magnets') or []
    if not magnets:
        return None
    m = magnets[0]
    if 'error' in m:
        log_warning('AD upload error for magnet: {0}'.format(m.get('error', {}).get('message')))
        return None
    return m


def magnet_files(magnet_id):
    """Returns list of file dicts."""
    r = _api('/magnet/files', params={'id[]': magnet_id})
    if not r or r.status_code != 200:
        return []
    try:
        body = r.json()
    except Exception:
        return []
    if body.get('status') != 'success':
        return []
    magnets = (body.get('data') or {}).get('magnets') or []
    if not magnets:
        return []
    return _flatten_files(magnets[0].get('files') or [])


def _flatten_files(files, prefix=''):
    """
    AD's /magnet/files returns nested folder structures. Flatten to a list
    of {filename, link, size} dicts.
    """
    out = []
    for f in files:
        name = f.get('n') or f.get('name') or ''
        full_name = (prefix + '/' + name) if prefix else name
        # Folder has 'e' (entries); file has 'l' (link) and 's' (size)
        if 'e' in f and isinstance(f['e'], list):
            out.extend(_flatten_files(f['e'], full_name))
        elif 'l' in f:
            out.append({
                'filename': full_name,
                'link': f.get('l'),
                'size': f.get('s', 0) or 0,
            })
    return out


def unlock_link(host_link):
    r = _api('/link/unlock', params={'link': host_link})
    if not r or r.status_code != 200:
        return None
    try:
        body = r.json()
    except Exception:
        return None
    if body.get('status') != 'success':
        log_warning('AD unlock failed: {0}'.format(
            body.get('error', {}).get('message', '')))
        return None
    return (body.get('data') or {}).get('link')


def delete_magnet(magnet_id):
    _api('/magnet/delete', params={'id': magnet_id})


def _pick_largest_video(files):
    """Return the {filename, link, size} dict of the biggest video file."""
    video_files = [f for f in files if any(
        (f.get('filename') or '').lower().endswith(ext) for ext in VIDEO_EXTS)]
    if not video_files:
        video_files = list(files)
    if not video_files:
        return None
    return max(video_files, key=lambda f: f.get('size', 0) or 0)


def _pick_file(files, file_idx=None, season=None, episode=None):
    """
    Choose the {filename, link, size} dict for the requested episode in a
    season pack — by episode name first, then fileIdx, then largest video.
    Falls back to _pick_largest_video for single-file torrents / movies.

    NB: AD's file list is flattened folder-first, so its order may not match
    Torrentio's fileIdx; the episode-name match (which is order-independent)
    is what actually makes packs correct here.
    """
    if not files:
        return None
    names = [f.get('filename') or '' for f in files]
    sizes = [f.get('size') or 0 for f in files]
    try:
        from resources.lib.debrid import filematch
        idx = filematch.choose_index(
            names, sizes, file_idx=file_idx, season=season, episode=episode)
    except Exception as e:
        log_warning('AD file-select fell back to largest ({0})'.format(e))
        return _pick_largest_video(files)
    if idx is None:
        return _pick_largest_video(files)
    chosen = files[idx]
    log('AD selecting file "{0}" ({1:.2f} GB)'.format(
        (chosen.get('filename') or '')[-60:], (chosen.get('size') or 0) / 1e9))
    return chosen


def try_resolve(magnet_or_hash, progress_cb=None, file_idx=None,
                season=None, episode=None):
    """
    Same contract as rd_client.try_resolve. file_idx/season/episode identify
    which file to play inside a multi-file (season-pack) torrent.
    Returns ('cached', url), ('uncached', None), or ('failed', None).
    """
    if progress_cb:
        try: progress_cb('Adding to AllDebrid...')
        except Exception: pass

    m = upload_magnet(magnet_or_hash)
    if not m:
        return 'failed', None

    magnet_id = m.get('id')
    is_ready = bool(m.get('ready'))

    if not is_ready:
        log('AD magnet {0}: not ready (uncached)'.format(magnet_id))
        if magnet_id:
            delete_magnet(magnet_id)
        return 'uncached', None

    if progress_cb:
        try: progress_cb('Fetching file list...')
        except Exception: pass

    files = magnet_files(magnet_id)
    if not files:
        log_warning('AD magnet {0} ready but no files'.format(magnet_id))
        delete_magnet(magnet_id)
        return 'failed', None

    pick = _pick_file(files, file_idx=file_idx, season=season, episode=episode)
    if not pick or not pick.get('link'):
        log_warning('AD magnet {0}: no playable video file'.format(magnet_id))
        delete_magnet(magnet_id)
        return 'failed', None

    if progress_cb:
        try: progress_cb('Unlocking link...')
        except Exception: pass

    stream_url = unlock_link(pick['link'])
    if not stream_url:
        delete_magnet(magnet_id)
        return 'failed', None

    return 'cached', stream_url


def is_authorized():
    return auth_storage.ad_is_authorized()


def get_token():
    """
    Return the current AllDebrid API key. Used by torrentio.py to
    authenticate Torrentio's debrid cache check. Returns empty string
    if not authorized.
    """
    return _apikey() or ''
