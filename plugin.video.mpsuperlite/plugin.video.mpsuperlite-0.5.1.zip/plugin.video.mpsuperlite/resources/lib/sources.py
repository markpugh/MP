# -*- coding: utf-8 -*-
"""
Source ranking. Takes the normalized list from scraper.scrape() and orders
it according to user preferences (quality cap, cached-only, codec preference).
"""
from resources.lib.common import get_setting, get_bool, log


_QUALITY_RANK = {'4K': 4, '1080p': 3, '720p': 2, 'SD': 1}

# Map setting STRING values -> internal numeric cap.
# These values come from settings.xml's <option> labels — must match exactly.
_QUALITY_CAP_BY_LABEL = {
    '4K (2160p)': 4,
    '1080p': 3,
    '720p': 2,
    'Any': 99,
}

_SIZE_CAP_BY_LABEL = {
    'Unlimited': 0,
    '20 GB': 20.0,
    '15 GB': 15.0,
    '12 GB': 12.0,
    '8 GB': 8.0,
    '4 GB': 4.0,
}


def _quality_score(s):
    return _QUALITY_RANK.get(s.get('quality') or 'SD', 1)


def _has_debrid_path(source):
    """
    True if this source can plausibly resolve through a debrid service.
    A source qualifies if:
      - it has a hash or magnet URL (debrid services can check cache for it)
      - OR it's already marked as debrid-resolved by the scraper

    Direct hoster URLs (Streamtape, Doodstream, Vidoza, etc.) do NOT
    qualify even though they're HTTPS — they bypass the debrid trust
    boundary that the build is built around.
    """
    if source.get('debrid'):
        return True
    if source.get('cached'):
        # Scrapers sometimes mark cached=True for debrid hits without
        # populating the debrid field. Trust the cached flag as a
        # secondary signal.
        return True
    h = source.get('hash')
    if h and len(h) >= 32:
        # Looks like an info-hash. Debrid services can check this.
        return True
    url = (source.get('url') or '').lower()
    if url.startswith('magnet:'):
        return True
    # Anything else — direct hoster, embedded player, file URL — is not
    # going through debrid by definition.
    return False


def filter_and_rank(sources):
    """
    Returns a new list, filtered by user prefs and sorted from best to worst.
    Best == cached on a debrid > higher quality > preferred codec > preferred size.

    Size handling: we filter OUT sources above the cap, then within the
    remaining set we prefer the LARGEST (proxy for highest bitrate inside
    the same quality tier — a 1080p at 8GB is almost always a better
    encode than a 1080p at 1.4GB).

    Note (v0.5.3): the hardcoded debrid gate from v0.5.0 was reverted
    after it broke playback for sources that previously worked. The
    gate's intent was correct (drop non-debrid sources up front) but
    the field-detection heuristic mis-classified legitimate cocoscrapers
    sources as non-debrid in some cases. Defense-in-depth has been
    moved back to where it was emergent in 0.4.x: resolve_first_cached
    is the single chokepoint and only ever returns URLs that came from
    debrid try_resolve calls. The build remains debrid-only by behavior;
    we just don't try to enforce it twice.
    """
    if not sources:
        return []

    cached_only = get_bool('cached_only', False)
    quality_label = get_setting('quality_max') or '1080p'
    cap = _QUALITY_CAP_BY_LABEL.get(quality_label, 3)
    prefer_hevc = get_bool('prefer_hevc', True)
    size_label = get_setting('max_size') or 'Unlimited'
    size_cap = _SIZE_CAP_BY_LABEL.get(size_label, 0)  # 0 = unlimited

    # Filter step
    filtered = []
    dropped_oversize = 0
    for s in sources:
        if cached_only and not s.get('cached'):
            continue
        if _quality_score(s) > cap:
            continue
        # Size cap: drop anything bigger than cap. If size unknown (0), keep it.
        sg = s.get('size_gb') or 0
        if size_cap > 0 and sg > size_cap:
            dropped_oversize += 1
            continue
        filtered.append(s)

    if dropped_oversize:
        log('Dropped {0} sources over {1}GB cap'.format(dropped_oversize, size_cap))

    if not filtered and cached_only:
        log('No cached sources within filters; falling back to uncached.')
        filtered = []
        for s in sources:
            if _quality_score(s) > cap:
                continue
            sg = s.get('size_gb') or 0
            if size_cap > 0 and sg > size_cap:
                continue
            filtered.append(s)

    # Sort step — multi-key, descending
    def sort_key(s):
        codec_pref = 1 if (prefer_hevc and s.get('codec') == 'h265') else 0
        return (
            1 if s.get('cached') else 0,           # cached first
            _quality_score(s),                     # higher quality first
            codec_pref,                            # preferred codec first
            float(s.get('size_gb') or 0),          # bigger first within quality tier
        )

    filtered.sort(key=sort_key, reverse=True)
    return filtered


def picker_label(s):
    """Human-readable line for the source-picker dialog."""
    bits = []
    bits.append(s.get('quality') or 'SD')
    if s.get('cached'):
        bits.append('cached')
    if s.get('codec') == 'h265':
        bits.append('HEVC')
    if s.get('hdr'):
        bits.append('HDR')
    sg = s.get('size_gb') or 0
    if sg > 0:
        bits.append('{0:.1f}GB'.format(sg))
    bits.append(s.get('provider') or '?')
    return ' \u2022 '.join(bits) + '   ' + (s.get('release_title') or '')[:80]
