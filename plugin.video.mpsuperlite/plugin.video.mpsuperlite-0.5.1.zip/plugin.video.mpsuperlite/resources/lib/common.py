# -*- coding: utf-8 -*-
"""
Shared helpers used across MP SuperLite modules: logging, settings, paths.
"""
import os
import sys
import time

import xbmc
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon('plugin.video.mpsuperlite')
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_VERSION = ADDON.getAddonInfo('version')
ADDON_PATH = ADDON.getAddonInfo('path')
ADDON_PROFILE = ADDON.getAddonInfo('profile')

LOG_TAG = '[mpsuperlite]'


def translate_path(p):
    """Compatibility shim: xbmcvfs.translatePath in 19+, xbmc.translatePath in older."""
    if hasattr(xbmcvfs, 'translatePath'):
        return xbmcvfs.translatePath(p)
    return xbmc.translatePath(p)


def log(msg, level=xbmc.LOGINFO):
    """Tagged logger so log scraping is grep-friendly."""
    try:
        xbmc.log('{0} {1}'.format(LOG_TAG, msg), level)
    except Exception:
        pass


def log_warning(msg):
    log(msg, xbmc.LOGWARNING)


def log_error(msg):
    log(msg, xbmc.LOGERROR)


# -- settings -----------------------------------------------------------------

def get_setting(key, default=''):
    try:
        v = ADDON.getSetting(key)
        return v if v is not None else default
    except Exception:
        return default


def set_setting(key, value):
    try:
        ADDON.setSetting(key, str(value) if value is not None else '')
    except Exception as e:
        log_error('set_setting({0}) failed: {1}'.format(key, e))


def get_bool(key, default=False):
    v = get_setting(key, '').strip().lower()
    if v in ('true', '1', 'yes'):
        return True
    if v in ('false', '0', 'no'):
        return False
    return default


def get_int(key, default=0):
    try:
        return int(get_setting(key, str(default)))
    except (ValueError, TypeError):
        return default


# -- paths --------------------------------------------------------------------

def profile_dir():
    p = translate_path(ADDON_PROFILE)
    if not os.path.isdir(p):
        try:
            os.makedirs(p, exist_ok=True)
        except Exception:
            pass
    return p


def temp_dir():
    p = translate_path('special://temp/')
    return p


def now_ts():
    return int(time.time())
