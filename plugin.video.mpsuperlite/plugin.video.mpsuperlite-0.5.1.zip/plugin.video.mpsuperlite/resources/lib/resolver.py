# -*- coding: utf-8 -*-
"""
ResolveURL wrapper. CocoScrapers returns sources whose 'url' field may
already be a direct stream URL, or may be a magnet/torrent link, or may be
a host URL that needs further resolution. ResolveURL handles the latter.

For debrid-cached sources, CocoScrapers usually returns an already-resolved
URL. For non-cached or host-link sources, we need ResolveURL.
"""
from resources.lib.common import log, log_error


def resolve(source):
    """
    source: a normalized source dict (see scraper.py).
    Returns a playable URL string or None if resolution fails.
    """
    url = source.get('url') or ''
    if not url:
        return None

    # If the URL already looks like a direct stream (mp4/mkv/m3u8), trust it.
    lower = url.lower().split('?', 1)[0]
    if lower.endswith(('.mp4', '.mkv', '.m3u8', '.ts', '.avi')):
        return url

    # Try ResolveURL for host links and debrid resolution.
    try:
        import resolveurl
    except ImportError as e:
        log_error('resolveurl import failed: {0}'.format(e))
        return None

    try:
        resolved = resolveurl.resolve(url)
        if resolved:
            log('ResolveURL OK: {0}'.format(source.get('provider')))
            return resolved
        else:
            log_error('ResolveURL returned None for {0}'.format(source.get('provider')))
            return None
    except Exception as e:
        log_error('ResolveURL exception: {0}'.format(e))
        return None
