# -*- coding: utf-8 -*-
"""
Plays a resolved stream URL through Kodi's player, attaching metadata so
the OSD shows title / poster / plot / etc. correctly.
"""
import xbmc
import xbmcgui

from resources.lib.common import log


_TMDB_IMG = 'https://image.tmdb.org/t/p/'


def _build_listitem(meta, stream_url):
    """meta: tmdb metadata dict. stream_url: resolved playable URL."""
    if meta.get('mediatype') == 'episode':
        label = '{0} S{1:02d}E{2:02d} - {3}'.format(
            meta.get('tvshowtitle') or '',
            int(meta.get('season') or 0),
            int(meta.get('episode') or 0),
            meta.get('title') or '',
        )
    else:
        label = meta.get('title') or 'Untitled'

    li = xbmcgui.ListItem(label=label, path=stream_url)

    poster = meta.get('poster') or ''
    fanart = meta.get('fanart') or ''
    art = {}
    if poster:
        art['poster'] = _TMDB_IMG + 'w500' + poster
        art['thumb'] = art['poster']
    if fanart:
        art['fanart'] = _TMDB_IMG + 'w1280' + fanart
    if art:
        li.setArt(art)

    info = {
        'title': meta.get('title') or label,
        'plot': meta.get('episode_plot') or meta.get('plot') or '',
        'year': meta.get('year') or 0,
        'mediatype': meta.get('mediatype') or 'movie',
    }
    if meta.get('mediatype') == 'episode':
        info['tvshowtitle'] = meta.get('tvshowtitle') or ''
        info['season'] = int(meta.get('season') or 0)
        info['episode'] = int(meta.get('episode') or 0)
    if meta.get('runtime'):
        info['duration'] = int(meta['runtime']) * 60
    if meta.get('imdb'):
        info['imdbnumber'] = meta['imdb']

    try:
        li.setInfo('video', info)
    except Exception:
        pass

    li.setProperty('IsPlayable', 'true')
    return li


def play(meta, stream_url):
    """Hand off to Kodi's Player. Blocks return; playback runs async.

    Use this only when invoked OUTSIDE a plugin handle context.
    Inside a plugin handle, use play_resolved() instead — it routes
    through Kodi's full playback pipeline so TMDb Helper's scrobble
    hook fires, watch state updates, and resume points work.
    """
    if not stream_url:
        log('player.play called with empty stream_url')
        return False
    li = _build_listitem(meta, stream_url)
    try:
        xbmc.Player().play(stream_url, li)
        log('Player.play started: {0}'.format(stream_url[:80]))
        return True
    except Exception as e:
        log('Player.play failed: {0}'.format(e))
        return False


def play_resolved(meta, stream_url, handle):
    """
    Resolve the stream URL through Kodi's setResolvedUrl. This is the
    preferred path when invoked via plugin handle — Kodi takes over
    the playback lifecycle, which means:
      - TMDb Helper's scrobble hook fires and reports to Trakt
      - Kodi remembers the watch position (resume on next click)
      - Kodi's watched/unwatched state updates correctly
      - Mid-playback errors get logged through Kodi's normal flow

    handle: the plugin invocation handle from sys.argv[1].
    """
    import xbmcplugin
    if not stream_url:
        log('player.play_resolved called with empty stream_url')
        try:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        except Exception:
            pass
        return False
    li = _build_listitem(meta, stream_url)
    try:
        xbmcplugin.setResolvedUrl(handle, True, li)
        log('Player.setResolvedUrl: {0}'.format(stream_url[:80]))
        return True
    except Exception as e:
        log('Player.setResolvedUrl failed: {0}'.format(e))
        try:
            xbmcplugin.setResolvedUrl(handle, False, li)
        except Exception:
            pass
        return False
