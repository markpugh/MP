# -*- coding: utf-8 -*-
"""
CocoScrapers wrapper. Translates our metadata dict into the format
CocoScrapers expects, runs the scrape, returns a normalized source list.

CocoScrapers is a Kodi script.module addon (declared as a <requires> in
addon.xml). It exposes a `sources()` factory + a `scrape()` method that
takes a metadata dict and returns a list of source dicts.

Source dict format (after our normalization):
  {
    'provider': 'magnetdl',
    'quality': '1080p' | '720p' | '4K' | 'SD',
    'size_gb': 4.2,
    'debrid': 'real_debrid' | 'all_debrid' | None,
    'cached': True | False,
    'hash': '...',          # for direct debrid lookup
    'url': '...',           # already-resolvable url, OR a magnet/torrent
    'language': 'en',
    'codec': 'h265' | 'h264' | None,
    'hdr': True | False,
    'release_title': 'Tucker.and.Dale.vs.Evil.2010.1080p...',
    '_raw': original_source_dict,   # kept around for ResolveURL
  }
"""
from resources.lib.common import log, log_warning, log_error


_QUALITY_BUCKETS = {
    '4k': '4K', '2160p': '4K', 'uhd': '4K',
    '1440p': '1080p',  # uncommon; treat as 1080p
    '1080p': '1080p',
    '720p': '720p',
    '480p': 'SD', '360p': 'SD', 'sd': 'SD', 'cam': 'SD',
}


def _normalize_quality(q):
    if not q:
        return 'SD'
    s = str(q).strip().lower()
    return _QUALITY_BUCKETS.get(s, 'SD')


def _detect_codec(release_title):
    if not release_title:
        return None
    t = release_title.lower()
    if 'x265' in t or 'h265' in t or 'hevc' in t:
        return 'h265'
    if 'x264' in t or 'h264' in t or 'avc' in t:
        return 'h264'
    return None


def _detect_hdr(release_title):
    if not release_title:
        return False
    t = release_title.lower()
    return any(tag in t for tag in (' hdr', '.hdr', '-hdr', 'dolby vision', 'dovi', 'hdr10'))


def _size_gb(s):
    """CocoScrapers reports size as either a number (GB) or a string like '2.4 GB'."""
    if s is None:
        return 0.0
    try:
        return float(s)
    except (ValueError, TypeError):
        pass
    try:
        s = str(s).lower().strip()
        if 'gb' in s:
            return float(s.replace('gb', '').strip())
        if 'mb' in s:
            return float(s.replace('mb', '').strip()) / 1024.0
    except Exception:
        return 0.0
    return 0.0


def _normalize(src):
    """Take a CocoScrapers source dict and normalize to our schema."""
    title = (src.get('name') or src.get('title') or src.get('release_title')
             or src.get('source') or '')
    debrid = None
    cached = False
    debrid_field = (src.get('debrid') or '').strip().lower() if isinstance(src.get('debrid'), str) else ''
    if debrid_field:
        if 'real' in debrid_field or debrid_field in ('rd', 'real-debrid', 'realdebrid'):
            debrid = 'real_debrid'
        elif 'all' in debrid_field or debrid_field in ('ad', 'all-debrid', 'alldebrid'):
            debrid = 'all_debrid'
        elif 'premium' in debrid_field:
            debrid = 'premiumize'
        else:
            debrid = debrid_field
        cached = True   # if debrid field is set, it's cached on that service
    return {
        'provider': src.get('provider') or src.get('source') or 'unknown',
        'quality': _normalize_quality(src.get('quality')),
        'size_gb': _size_gb(src.get('size')),
        'debrid': debrid,
        'cached': cached or bool(src.get('cached')),
        'hash': src.get('hash') or '',
        'url': src.get('url') or '',
        'language': src.get('language') or 'en',
        'codec': _detect_codec(title),
        'hdr': _detect_hdr(title),
        'release_title': title,
        '_raw': src,
    }


def _build_data(meta):
    """
    Build the dict CocoScrapers' source modules expect on .sources(data, hostDict).
    Pattern stolen from Umbrella's getMovieSource / getEpisodeSource. Required
    keys vary per provider but this is the canonical superset.

    CRITICAL details learned the hard way:
    - year MUST be a string. Many providers do .replace(year, '') on strings,
      which TypeErrors with int.
    - tvshowtitle MUST be present even for movies (some providers blindly
      access data['tvshowtitle']; they expect KeyError to mean "this is a
      movie", but the safer fix is to set it to '' so they pass the
      'tvshowtitle' in data check correctly).
    - debrid_service and debrid_token are required by debrid-aware providers
      like comet and torrentio. Without them, those providers KeyError out.
    """
    # Pick first authorized debrid service for providers that need it.
    # comet, torrentio etc use this to filter by what the user can actually play.
    debrid_creds = _get_debrid_creds()

    if meta.get('mediatype') == 'episode':
        d = {
            'title': meta.get('title') or '',
            'tvshowtitle': meta.get('tvshowtitle') or '',
            'year': str(meta.get('year') or ''),
            'imdb': meta.get('imdb') or '',
            'tvdb': meta.get('tvdb') or '',
            'tmdb': meta.get('tmdb') or '',
            'season': str(meta.get('season') or ''),
            'episode': str(meta.get('episode') or ''),
            'aliases': [],
            'premiered': meta.get('premiered') or '',
        }
    else:
        d = {
            'title': meta.get('title') or '',
            # Some providers blindly reference data['tvshowtitle']. We always
            # set it (empty for movies) so the key exists. Providers check
            # `if 'tvshowtitle' in data` to branch — that fails because the
            # key IS present, so we ALSO need to ensure the providers' check
            # is `if data.get('tvshowtitle')` not `if 'tvshowtitle' in data`.
            # We can't fix providers' code, so we omit the key entirely for
            # movies. EZTV will KeyError but it's a TV-only provider anyway.
            'year': str(meta.get('year') or ''),
            'imdb': meta.get('imdb') or '',
            'tmdb': meta.get('tmdb') or '',
            'aliases': [],
            'premiered': meta.get('premiered') or '',
        }

    if debrid_creds:
        d['debrid_service'] = debrid_creds[0]
        d['debrid_token'] = debrid_creds[1]

    return d


def _get_debrid_creds():
    """
    Returns (service_name, token) for the first authorized debrid service,
    in the format CocoScrapers' debrid-aware providers (comet, torrentio)
    expect. service_name is 'Real-Debrid', 'AllDebrid', or 'Premiumize.me'.
    Returns None if no debrid is configured.
    """
    try:
        from resources.lib.auth import storage as auth_storage
        # Try Real Debrid first
        rd_creds = auth_storage.rd_load()
        if rd_creds.get('access_token'):
            return ('Real-Debrid', rd_creds['access_token'])
        # Fall back to AllDebrid
        ad_creds = auth_storage.ad_load()
        if ad_creds.get('apikey'):
            return ('AllDebrid', ad_creds['apikey'])
    except Exception:
        pass
    return None


def _get_host_dict():
    """
    CocoScrapers source modules need to know which file hosts are resolvable.
    They take this as the second argument and use it to filter out useless
    hosts. We pull the list from ResolveURL.

    Defensive layering:
      1. Try resolveurl.relevant_resolvers() — Gujal00's fork (5.1.x).
      2. Try a few alt entry points other forks expose.
      3. Fall back to a baked-in list of common debrid/host domains so
         providers can still attempt source matching.

    Returns a list of host domain strings (lowercase, deduped).
    """
    hosts = []
    try:
        import resolveurl
    except ImportError as e:
        log_error('resolveurl import failed: {0}'.format(e))
        resolveurl = None

    if resolveurl is not None:
        # Try multiple discovery methods — some ResolveURL forks expose
        # different APIs.
        for getter_name in ('relevant_resolvers',):
            try:
                getter = getattr(resolveurl, getter_name, None)
                if not getter:
                    continue
                # Gujal00 5.1.x signature
                resolvers = getter(order_matters=False, include_universal=True,
                                   include_disabled=False)
                for r in resolvers or []:
                    try:
                        hosts += list(getattr(r, 'domains', []) or [])
                    except Exception:
                        pass
                if hosts:
                    break
            except Exception as e:
                log_warning('Could not build hostDict via {0}: {1}'.format(
                    getter_name, e))

    if not hosts:
        # Hardcoded fallback: the universally-supported debrid + host set.
        # This is what gets tested first by every torrent-magnet scraper.
        hosts = [
            # Debrid services
            'real-debrid.com', 'alldebrid.com', 'premiumize.me', 'debrid-link.com',
            # Universal / common direct hosts
            'rapidgator.net', 'uptobox.com', 'mediafire.com', 'mega.nz',
            '1fichier.com', 'turbobit.net', 'nitroflare.com', 'fileboom.me',
            'easybytez.com', 'depfile.com', 'dropfile.to', 'streamtape.com',
            'streamzz.to', 'doodstream.com', 'mixdrop.co', 'voe.sx',
            'filemoon.sx', 'filemoon.to', 'streamhide.to',
        ]
        log_warning('hostDict using hardcoded fallback list ({0} hosts).'.format(len(hosts)))

    # Dedupe + lowercase
    return list({h.lower() for h in hosts if h})


def scrape(meta, progress_cb=None):
    """
    meta: dict from tmdb.get_movie() or tmdb.get_episode().
    progress_cb: optional callable(percent, message) for the progress dialog.

    Returns a list of normalized source dicts (possibly empty).

    CocoScrapers API (verified against 1.0.32, matches Umbrella's usage):
      cocoscrapers.sources()  ->  [(provider_name, source_class), ...]
      Each source_class is a class with a .sources(data, hostDict) method.
      Instantiate it: src = source_class()
      Then call: src.sources(data, hostDict)  ->  list of source dicts
    """
    try:
        import cocoscrapers
    except ImportError as e:
        log_error('cocoscrapers import failed: {0}'.format(e))
        return []

    try:
        provider_list = cocoscrapers.sources()
    except Exception as e:
        log_error('cocoscrapers.sources() failed: {0}'.format(e))
        return []

    if not provider_list:
        log_warning('cocoscrapers returned no providers (none enabled?). '
                    'Open CocoScrapers Module settings and enable providers.')
        return []

    log('cocoscrapers loaded {0} providers'.format(len(provider_list)))

    data = _build_data(meta)
    host_dict = _get_host_dict()
    log('hostDict has {0} resolvable hosts'.format(len(host_dict)))
    log('scrape data: title={0!r} year={1} imdb={2!r} tmdb={3!r}'.format(
        data.get('title') or data.get('tvshowtitle'),
        data.get('year'), data.get('imdb'), data.get('tmdb')))

    # Diagnostic: what's the first 5 hosts in our dict?
    if host_dict:
        log('hostDict sample: {0}'.format(host_dict[:5]))

    raw_all = []
    total = len(provider_list)
    import time as _time
    for idx, entry in enumerate(provider_list, 1):
        if progress_cb:
            try:
                progress_cb(int(10 + 80 * idx / max(total, 1)),
                            'Scraping {0} ({1}/{2})...'.format(
                                entry[0] if isinstance(entry, tuple) else 'provider',
                                idx, total))
            except Exception:
                pass
        provider_name = 'unknown'
        try:
            if isinstance(entry, tuple):
                provider_name, source_cls = entry[0], entry[1]
            else:
                source_cls = entry
            t0 = _time.time()
            instance = source_cls()
            results = instance.sources(data, host_dict)
            elapsed = _time.time() - t0
            n = len(results) if results else 0
            log('provider {0}: returned {1} sources in {2:.1f}s'.format(
                provider_name, n, elapsed))
            if results:
                for r in results:
                    if isinstance(r, dict) and not r.get('provider'):
                        r['provider'] = provider_name
                raw_all.extend(results)
        except Exception as e:
            log_warning('provider {0} raised: {1}'.format(provider_name, e))
            continue

    if not raw_all:
        log_warning('All CocoScrapers providers returned 0 sources for {0}; '
                    'will still try Torrentio'.format(
                        meta.get('title') or meta.get('tvshowtitle')))

    sources = [_normalize(s) for s in raw_all if isinstance(s, dict)]
    log('Got {0} normalized sources from CocoScrapers for {1}'.format(
        len(sources), meta.get('title') or meta.get('tvshowtitle')))

    # Add Torrentio's results in parallel. Torrentio is the dominant
    # cached-debrid source provider in the ecosystem and accounts for
    # the bulk of "good source coverage" in builds like Diggz Xenon.
    # Single HTTP call, server-side cache check, returns RD/AD-cached
    # results pre-resolved.
    try:
        if progress_cb:
            try:
                progress_cb(92, 'Querying Torrentio...')
            except Exception:
                pass
        from resources.lib import torrentio
        torrentio_sources = torrentio.scrape(meta, progress_cb=progress_cb)
        if torrentio_sources:
            # Dedupe against existing sources by infohash. Many
            # CocoScrapers providers and Torrentio see the same
            # torrents — we want to keep the version with the better
            # cached marker, prefer Torrentio's (it's pre-checked
            # against the user's specific debrid token, so it's more
            # reliable than CocoScrapers' self-reported cache state).
            existing_hashes = {(s.get('hash') or '').lower(): i
                               for i, s in enumerate(sources)
                               if s.get('hash')}
            merged = list(sources)
            replaced = 0
            added = 0
            for ts in torrentio_sources:
                h = (ts.get('hash') or '').lower()
                if h and h in existing_hashes:
                    # Replace if Torrentio reports cached and original
                    # didn't, keep otherwise
                    idx = existing_hashes[h]
                    if ts.get('cached') and not merged[idx].get('cached'):
                        merged[idx] = ts
                        replaced += 1
                else:
                    merged.append(ts)
                    added += 1
            log('Torrentio merged: +{0} new, {1} cached upgrades'.format(
                added, replaced))
            sources = merged
    except Exception as e:
        log_warning('Torrentio scrape raised (continuing): {0}'.format(e))

    log('Total {0} sources for {1}'.format(
        len(sources), meta.get('title') or meta.get('tvshowtitle')))
    return sources
