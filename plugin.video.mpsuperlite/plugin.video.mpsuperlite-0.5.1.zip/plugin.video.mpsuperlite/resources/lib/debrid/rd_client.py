# -*- coding: utf-8 -*-
"""
Real Debrid API client.

Since Real Debrid removed the public /torrents/instantAvailability endpoint
in late 2024, the only way to determine if a torrent is RD-cached is to
add the magnet, see if it instantly transitions to status='downloaded'
(meaning RD already has it on their servers), and pull the link if so.

If the torrent goes into 'downloading', 'queued', or 'magnet_conversion'
state, it's NOT cached and we delete it from the user's account so we
don't pollute their torrent history.

API reference: https://api.real-debrid.com/

  POST /torrents/addMagnet         -> {id, uri}
  GET  /torrents/info/{id}         -> {status, files: [...], links: [...], ...}
  POST /torrents/selectFiles/{id}  body: files=1,2,3 (or 'all')
  POST /unrestrict/link            body: link=URL  -> {download: 'https://...'}
  DELETE /torrents/delete/{id}

Status values that mean "cached": 'downloaded'
Status values that mean "not cached, abort": 'downloading', 'queued',
  'magnet_conversion', 'compressing', 'uploading', 'waiting_files_selection'
  (wait briefly then check again — it's a race)
Status values that mean "give up": 'magnet_error', 'error', 'virus', 'dead'
"""
import time
import json

import requests

from resources.lib.common import log, log_warning, log_error
from resources.lib.auth import rd as rd_auth


API_BASE = 'https://api.real-debrid.com/rest/1.0'

# How long to wait for status to settle after addMagnet before deciding cached/uncached.
# RD typically resolves cached torrents in <2s; uncached ones go straight to 'downloading'.
SETTLE_TIMEOUT = 5
SETTLE_POLL_INTERVAL = 0.7

# Common video file extensions for selectFiles
VIDEO_EXTS = ('.mp4', '.mkv', '.avi', '.m4v', '.mov', '.wmv', '.flv', '.ts', '.webm')


def _headers():
    token = rd_auth.get_valid_access_token()
    if not token:
        return None
    return {'Authorization': 'Bearer ' + token}


def _api(method, path, **kwargs):
    """Wrapped HTTP call with auth + error logging."""
    headers = _headers()
    if not headers:
        log_error('RD: no valid access token')
        return None
    url = API_BASE + path
    kwargs.setdefault('timeout', 10)
    kwargs.setdefault('headers', {}).update(headers)
    try:
        r = requests.request(method, url, **kwargs)
        return r
    except Exception as e:
        log_error('RD {0} {1} failed: {2}'.format(method, path, e))
        return None


def add_magnet(magnet_or_hash):
    """
    Add a magnet/hash to RD. Returns the torrent ID, or None.

    Accepts either a full magnet URI or a bare info hash. We always
    convert hash to magnet here.
    """
    if not magnet_or_hash:
        return None
    if magnet_or_hash.startswith('magnet:'):
        magnet = magnet_or_hash
    else:
        # Bare hash — convert to magnet
        magnet = 'magnet:?xt=urn:btih:{0}'.format(magnet_or_hash)
    r = _api('POST', '/torrents/addMagnet', data={'magnet': magnet})
    if not r or r.status_code not in (200, 201):
        log_warning('RD addMagnet failed: status={0} body={1!r}'.format(
            r.status_code if r else None, (r.text[:200] if r else '')))
        return None
    try:
        return r.json().get('id')
    except Exception:
        return None


def torrent_info(torrent_id):
    r = _api('GET', '/torrents/info/{0}'.format(torrent_id))
    if not r or r.status_code != 200:
        return None
    try:
        return r.json()
    except Exception:
        return None


def select_files(torrent_id, file_ids):
    """file_ids: list of int file IDs, or string 'all'."""
    if file_ids == 'all':
        body = {'files': 'all'}
    else:
        body = {'files': ','.join(str(f) for f in file_ids)}
    r = _api('POST', '/torrents/selectFiles/{0}'.format(torrent_id), data=body)
    return bool(r and r.status_code in (200, 204))


def unrestrict_link(host_link):
    r = _api('POST', '/unrestrict/link', data={'link': host_link})
    if not r or r.status_code != 200:
        log_warning('RD unrestrict failed: status={0} body={1!r}'.format(
            r.status_code if r else None, (r.text[:200] if r else '')))
        return None
    try:
        return r.json().get('download')
    except Exception:
        return None


def delete_torrent(torrent_id):
    """Best-effort cleanup. Don't care about result."""
    _api('DELETE', '/torrents/delete/{0}'.format(torrent_id))


def _pick_largest_video_file(files):
    """
    files: list of dicts from /torrents/info, each with id, path, bytes.
    Returns list with one int (the chosen file id).
    """
    video_files = []
    for f in files:
        path = (f.get('path') or '').lower()
        if any(path.endswith(ext) for ext in VIDEO_EXTS):
            video_files.append(f)
    if not video_files:
        # No recognized video — just pick the biggest file
        video_files = list(files)
    if not video_files:
        return []
    largest = max(video_files, key=lambda f: f.get('bytes', 0))
    return [largest.get('id')]


def try_resolve(magnet_or_hash, progress_cb=None):
    """
    The full RD upload-and-check sequence for one source.

    Returns either:
      ('cached', stream_url)    — torrent was cached on RD, here's the URL
      ('uncached', None)        — not cached, already cleaned up
      ('failed', None)          — error of some kind, already cleaned up

    Side effect: deletes the RD torrent entry on uncached/failed paths
    so the user's account doesn't fill with junk.
    """
    if progress_cb:
        try: progress_cb('Adding to Real Debrid...')
        except Exception: pass

    torrent_id = add_magnet(magnet_or_hash)
    if not torrent_id:
        return 'failed', None

    # First info call — also tells us file list so we can selectFiles
    info = torrent_info(torrent_id)
    if not info:
        delete_torrent(torrent_id)
        return 'failed', None

    status = info.get('status', '')
    files = info.get('files', []) or []

    # Some sources return torrents that need files to be selected before
    # status settles to downloaded. Select the largest video file now.
    if status in ('waiting_files_selection',) or files:
        file_ids = _pick_largest_video_file(files)
        if file_ids:
            if progress_cb:
                try: progress_cb('Selecting files...')
                except Exception: pass
            select_files(torrent_id, file_ids)
            # Re-fetch info after select
            info = torrent_info(torrent_id) or info

    # Wait for status to settle
    if progress_cb:
        try: progress_cb('Checking cache status...')
        except Exception: pass
    deadline = time.time() + SETTLE_TIMEOUT
    while time.time() < deadline:
        status = info.get('status', '')
        if status == 'downloaded':
            break
        if status in ('error', 'magnet_error', 'virus', 'dead'):
            log_warning('RD torrent {0}: status={1}, abandoning'.format(
                torrent_id, status))
            delete_torrent(torrent_id)
            return 'failed', None
        # Statuses 'downloading', 'queued', 'compressing', 'uploading' all
        # indicate uncached — RD is downloading the torrent NOW for the
        # first time. We're not waiting for that.
        if status in ('downloading', 'queued', 'compressing', 'uploading'):
            log('RD torrent {0}: status={1}, not cached'.format(torrent_id, status))
            delete_torrent(torrent_id)
            return 'uncached', None
        # 'magnet_conversion' / 'waiting_files_selection' — keep polling
        time.sleep(SETTLE_POLL_INTERVAL)
        info = torrent_info(torrent_id) or info

    if info.get('status') != 'downloaded':
        log('RD torrent {0}: status={1} after settle timeout, giving up'.format(
            torrent_id, info.get('status')))
        delete_torrent(torrent_id)
        return 'uncached', None

    # Cached! Resolve the link.
    links = info.get('links') or []
    if not links:
        log_warning('RD torrent {0} downloaded but no links? aborting'.format(torrent_id))
        delete_torrent(torrent_id)
        return 'failed', None

    if progress_cb:
        try: progress_cb('Unrestricting link...')
        except Exception: pass
    stream_url = unrestrict_link(links[0])
    if not stream_url:
        delete_torrent(torrent_id)
        return 'failed', None

    # Don't delete on success — user may want to access it again
    return 'cached', stream_url


def is_authorized():
    return rd_auth.storage.rd_is_authorized()


def get_token():
    """
    Return the current Real Debrid access token, refreshing if needed.
    Used by torrentio.py to authenticate Torrentio's debrid cache check.
    Returns empty string if not authorized.
    """
    if not is_authorized():
        return ''
    try:
        return rd_auth.get_valid_access_token() or ''
    except Exception:
        return ''
