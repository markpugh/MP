# -*- coding: utf-8 -*-
"""
Debrid token persistence. Stores credentials in addon settings (level 4
hidden settings) so they survive across sessions but aren't visible in
the normal settings UI.
"""
from resources.lib.common import (
    get_setting, set_setting, now_ts, log,
)


# ---------- Real Debrid -----------------------------------------------------

def rd_save(client_id, client_secret, access_token, refresh_token, expires_in):
    set_setting('rd_client_id', client_id)
    set_setting('rd_client_secret', client_secret)
    set_setting('rd_access_token', access_token)
    set_setting('rd_refresh_token', refresh_token)
    set_setting('rd_expires_at', str(now_ts() + int(expires_in or 0) - 60))
    set_setting('rd_status', 'Connected')


def rd_load():
    """Returns dict (possibly with empty values if not yet authorized)."""
    return {
        'client_id': get_setting('rd_client_id', ''),
        'client_secret': get_setting('rd_client_secret', ''),
        'access_token': get_setting('rd_access_token', ''),
        'refresh_token': get_setting('rd_refresh_token', ''),
        'expires_at': int(get_setting('rd_expires_at', '0') or 0),
    }


def rd_clear():
    for k in ('rd_client_id', 'rd_client_secret', 'rd_access_token',
              'rd_refresh_token', 'rd_expires_at'):
        set_setting(k, '')
    set_setting('rd_status', 'Not connected')
    log('RD credentials cleared.')


def rd_is_authorized():
    return bool(rd_load().get('access_token'))


# ---------- AllDebrid -------------------------------------------------------

def ad_save(apikey):
    set_setting('ad_apikey', apikey)
    set_setting('ad_status', 'Connected')


def ad_load():
    return {'apikey': get_setting('ad_apikey', '')}


def ad_clear():
    set_setting('ad_apikey', '')
    set_setting('ad_status', 'Not connected')
    log('AD credentials cleared.')


def ad_is_authorized():
    return bool(ad_load().get('apikey'))
