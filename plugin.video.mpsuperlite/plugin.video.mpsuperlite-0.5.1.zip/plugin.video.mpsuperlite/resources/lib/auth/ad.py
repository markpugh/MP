# -*- coding: utf-8 -*-
"""
AllDebrid PIN flow.

Reference: https://docs.alldebrid.com/

  GET https://api.alldebrid.com/v4/pin/get?agent=mpsuperlite
    -> {status: 'success', data: {pin, check, hash, user_url, base_url, expires_in}}
  Show QR for user_url (which is base_url + pin already).
  Poll GET .../v4/pin/check?agent=mpsuperlite&check=HASH&pin=PIN
    -> {data: {activated: false, ...}}  -> pending
    -> {data: {activated: true, apikey: '...', expires_in: ...}}  -> done
"""
import requests

import xbmcgui

from resources.lib.common import log, log_error, ADDON_NAME
from resources.lib.auth import storage
from resources.lib.auth.dialog import show_qr_auth


PIN_GET_URL = 'https://api.alldebrid.com/v4/pin/get'
PIN_CHECK_URL = 'https://api.alldebrid.com/v4/pin/check'
AGENT = 'mpsuperlite'
USER_URL = 'https://api.alldebrid.com/v4/user'


def start_authorization():
    log('AD authorization starting')
    try:
        r = requests.get(PIN_GET_URL, params={'agent': AGENT}, timeout=10)
        r.raise_for_status()
        body = r.json()
    except Exception as e:
        log_error('AD pin/get failed: {0}'.format(e))
        xbmcgui.Dialog().notification(ADDON_NAME, 'AD pin request failed.',
                                      xbmcgui.NOTIFICATION_ERROR, 4000)
        return

    if body.get('status') != 'success':
        log_error('AD pin/get unexpected: {0}'.format(body))
        return

    d = body.get('data') or {}
    pin = d.get('pin') or ''
    check_hash = d.get('check') or ''
    user_url = d.get('user_url') or 'https://alldebrid.com/pin/'
    base_url = d.get('base_url') or 'https://alldebrid.com/pin/'
    expires_in = int(d.get('expires_in') or 600)

    def poll():
        try:
            rr = requests.get(PIN_CHECK_URL, params={
                'agent': AGENT, 'check': check_hash, 'pin': pin,
            }, timeout=10)
        except Exception as e:
            log_error('AD pin/check error: {0}'.format(e))
            return 'pending'

        try:
            body = rr.json()
        except Exception:
            return 'pending'

        data = body.get('data') or {}
        if data.get('activated'):
            apikey = data.get('apikey')
            if apikey:
                storage.ad_save(apikey)
                # Try to fetch username
                try:
                    u = requests.get(USER_URL, params={'agent': AGENT, 'apikey': apikey},
                                     timeout=8).json()
                    uname = (u.get('data') or {}).get('user', {}).get('username') or 'Connected'
                    from resources.lib.common import set_setting
                    set_setting('ad_status', 'Connected as ' + uname)
                except Exception:
                    pass
                return 'ok'
        return 'pending'

    success, err = show_qr_auth(
        title='Authorize AllDebrid',
        url=base_url,
        code=pin,
        qr_data=user_url,
        poll_fn=poll,
        expires_in=expires_in,
        poll_interval=5,
    )
    if success:
        xbmcgui.Dialog().notification(ADDON_NAME, 'AllDebrid authorized!',
                                      xbmcgui.NOTIFICATION_INFO, 3000)
    elif err:
        xbmcgui.Dialog().notification(ADDON_NAME, 'AD: ' + err,
                                      xbmcgui.NOTIFICATION_WARNING, 4000)


def clear_authorization():
    storage.ad_clear()
    xbmcgui.Dialog().notification(ADDON_NAME, 'AllDebrid disconnected.',
                                  xbmcgui.NOTIFICATION_INFO, 2500)
