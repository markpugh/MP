# -*- coding: utf-8 -*-
"""
Real Debrid OAuth2 device-code flow.

Reference: https://api.real-debrid.com/#device

  1. POST /oauth/v2/device/code?client_id=X245A4XAIBGVM&new_credentials=yes
        -> {device_code, user_code, verification_url, expires_in, interval, direct_verification_url}
  2. Show QR for direct_verification_url (which embeds the code already).
  3. Poll /oauth/v2/device/credentials?client_id=...&code=DEVICE_CODE every `interval` seconds.
        While pending: 400 with {error: 'error_pending'}.
        On success: {client_id: 'user-specific', client_secret: '...'}
  4. POST /oauth/v2/token with grant_type='http://oauth.net/grant_type/device/1.0',
     code=device_code, client_id=user_client_id, client_secret=user_client_secret.
        -> {access_token, refresh_token, expires_in, token_type='Bearer'}
  5. Save all of those.

Refresh: POST /oauth/v2/token with grant_type='http://oauth.net/grant_type/device/1.0'
and the user-specific client_id/secret + refresh_token.
"""
import requests

import xbmcgui

from resources.lib.common import (
    log, log_error, now_ts, ADDON_NAME, set_setting,
)
from resources.lib.auth import storage
from resources.lib.auth.dialog import show_qr_auth


# Public OpenSource client id used for device-code flow. RD intentionally
# publishes this so anyone can do device-flow without registering an app.
RD_OPENSOURCE_CLIENT_ID = 'X245A4XAIBGVM'

DEVICE_CODE_URL = 'https://api.real-debrid.com/oauth/v2/device/code'
CREDENTIALS_URL = 'https://api.real-debrid.com/oauth/v2/device/credentials'
TOKEN_URL = 'https://api.real-debrid.com/oauth/v2/token'
USER_URL = 'https://api.real-debrid.com/rest/1.0/user'


# Module-level state that survives between poll calls (the dialog's poll_fn
# closes over these via the start_authorization function below).
class _AuthSession(object):
    def __init__(self):
        self.device_code = None
        self.user_code = None
        self.user_client_id = None
        self.user_client_secret = None
        self.user_received = False    # got client_id/secret from credentials endpoint?


def start_authorization():
    """Entry point called from default.py?action=auth_rd."""
    log('RD authorization starting')
    try:
        r = requests.get(DEVICE_CODE_URL, params={
            'client_id': RD_OPENSOURCE_CLIENT_ID,
            'new_credentials': 'yes',
        }, timeout=10)
        r.raise_for_status()
        d = r.json()
    except Exception as e:
        log_error('RD device/code request failed: {0}'.format(e))
        xbmcgui.Dialog().notification(ADDON_NAME, 'RD device-code request failed.',
                                      xbmcgui.NOTIFICATION_ERROR, 4000)
        return

    device_code = d.get('device_code')
    user_code = d.get('user_code') or ''
    verification_url = d.get('verification_url') or 'https://real-debrid.com/device'
    direct_url = d.get('direct_verification_url') or '{0}?pin={1}'.format(verification_url, user_code)
    interval = int(d.get('interval') or 5)
    expires_in = int(d.get('expires_in') or 600)

    if not device_code:
        xbmcgui.Dialog().notification(ADDON_NAME, 'RD response missing device_code.',
                                      xbmcgui.NOTIFICATION_ERROR, 4000)
        return

    session = _AuthSession()
    session.device_code = device_code
    session.user_code = user_code

    def poll():
        # Stage 1: poll credentials endpoint until RD returns user-specific
        # client_id/secret (meaning user has authorized).
        if not session.user_received:
            try:
                rr = requests.get(CREDENTIALS_URL, params={
                    'client_id': RD_OPENSOURCE_CLIENT_ID,
                    'code': device_code,
                }, timeout=10)
            except Exception as e:
                log_error('RD credentials poll error: {0}'.format(e))
                return 'pending'   # network blip, keep trying

            if rr.status_code == 200:
                try:
                    body = rr.json()
                except Exception:
                    return 'pending'
                cid = body.get('client_id')
                csec = body.get('client_secret')
                if cid and csec:
                    session.user_client_id = cid
                    session.user_client_secret = csec
                    session.user_received = True
                else:
                    return 'pending'
            else:
                # 400 with error_pending is the normal "not yet" response
                return 'pending'

        # Stage 2: exchange device_code for tokens (one shot)
        try:
            tr = requests.post(TOKEN_URL, data={
                'client_id': session.user_client_id,
                'client_secret': session.user_client_secret,
                'code': session.device_code,
                'grant_type': 'http://oauth.net/grant_type/device/1.0',
            }, timeout=10)
        except Exception as e:
            log_error('RD token exchange network error: {0}'.format(e))
            return 'authorized_but_pending'

        if tr.status_code != 200:
            log_error('RD token exchange status {0}: {1}'.format(tr.status_code, tr.text[:200]))
            return 'authorized_but_pending'

        try:
            tok = tr.json()
        except Exception:
            return 'authorized_but_pending'

        access = tok.get('access_token')
        refresh = tok.get('refresh_token')
        expires = tok.get('expires_in')
        if not access:
            return 'authorized_but_pending'

        storage.rd_save(session.user_client_id, session.user_client_secret,
                        access, refresh, expires)
        # Try to fetch the username for a nicer Status label
        try:
            u = requests.get(USER_URL, headers={'Authorization': 'Bearer ' + access}, timeout=8).json()
            uname = u.get('username') or 'Connected'
            set_setting('rd_status', 'Connected as ' + uname)
        except Exception:
            pass
        return 'ok'

    success, err = show_qr_auth(
        title='Authorize Real Debrid',
        url=verification_url,
        code=user_code,
        qr_data=direct_url,
        poll_fn=poll,
        expires_in=expires_in,
        poll_interval=interval,
    )
    if success:
        xbmcgui.Dialog().notification(ADDON_NAME, 'Real Debrid authorized!',
                                      xbmcgui.NOTIFICATION_INFO, 3000)
    elif err:
        xbmcgui.Dialog().notification(ADDON_NAME, 'RD: ' + err,
                                      xbmcgui.NOTIFICATION_WARNING, 4000)


def clear_authorization():
    storage.rd_clear()
    xbmcgui.Dialog().notification(ADDON_NAME, 'Real Debrid disconnected.',
                                  xbmcgui.NOTIFICATION_INFO, 2500)


def get_valid_access_token():
    """
    Returns a current access token, refreshing if expired. Called from
    scrape/resolve code paths that need RD auth. Returns '' on failure.
    """
    creds = storage.rd_load()
    if not creds.get('access_token'):
        return ''
    if creds.get('expires_at', 0) > now_ts() + 30:
        return creds['access_token']
    # Refresh
    try:
        r = requests.post(TOKEN_URL, data={
            'client_id': creds['client_id'],
            'client_secret': creds['client_secret'],
            'code': creds['refresh_token'],
            'grant_type': 'http://oauth.net/grant_type/device/1.0',
        }, timeout=10)
        r.raise_for_status()
        tok = r.json()
        storage.rd_save(creds['client_id'], creds['client_secret'],
                        tok.get('access_token'), tok.get('refresh_token'),
                        tok.get('expires_in'))
        return tok.get('access_token') or ''
    except Exception as e:
        log_error('RD token refresh failed: {0}'.format(e))
        return ''
