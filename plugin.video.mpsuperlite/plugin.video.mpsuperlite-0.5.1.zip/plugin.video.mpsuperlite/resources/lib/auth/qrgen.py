# -*- coding: utf-8 -*-
"""
Generate a QR-code PNG file from a URL. Uses the vendored qrcode library
with the pure-Python (pypng) image factory — no PIL dependency.
"""
import os
import sys

# Ensure the vendor dir is on sys.path so qrcode's relative imports work.
_THIS = os.path.dirname(os.path.abspath(__file__))
_VENDOR = os.path.normpath(os.path.join(_THIS, '..', 'vendor'))
if _VENDOR not in sys.path:
    sys.path.insert(0, _VENDOR)


def make_qr_png(data, out_path, box_size=12, border=4):
    """
    Render a QR code for `data` as a PNG file at `out_path`.
    box_size = pixel size of each module; border = quiet zone in modules.
    Returns out_path on success, None on failure.
    """
    try:
        import qrcode
        from qrcode.image.pure import PyPNGImage
    except Exception as e:
        try:
            import xbmc
            xbmc.log('[mpsuperlite] qrcode import failed: {0}'.format(e), 3)
        except Exception:
            pass
        return None

    try:
        qr = qrcode.QRCode(
            version=None,
            error_correction=qrcode.constants.ERROR_CORRECT_M,
            box_size=box_size,
            border=border,
        )
        qr.add_data(data)
        qr.make(fit=True)
        img = qr.make_image(image_factory=PyPNGImage)
        with open(out_path, 'wb') as f:
            img.save(f)
        return out_path
    except Exception as e:
        try:
            import xbmc
            xbmc.log('[mpsuperlite] make_qr_png failed: {0}'.format(e), 3)
        except Exception:
            pass
        return None
