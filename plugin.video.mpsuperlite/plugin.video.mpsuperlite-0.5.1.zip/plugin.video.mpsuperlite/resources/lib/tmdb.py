# -*- coding: utf-8 -*-
"""
TMDB metadata lookup. CocoScrapers needs the IMDB id and full title/year
to do a useful scrape, so we hit TMDB first to enrich the bare tmdb_id we
get from SuperSearch (or any caller).
"""
import json

import requests

from resources.lib.common import (
    get_setting, log, log_error, profile_dir, now_ts,
)
import os

TMDB_BASE = 'https://api.themoviedb.org/3'
CACHE_TTL = 6 * 60 * 60  # 6h — metadata changes rarely; cache aggressively


def _cache_path(key):
    safe = ''.join(c if c.isalnum() else '_' for c in key)
    return os.path.join(profile_dir(), 'tmdb_cache', safe + '.json')


def _cache_get(key):
    p = _cache_path(key)
    try:
        if not os.path.isfile(p):
            return None
        with open(p, 'r', encoding='utf-8') as f:
            blob = json.load(f)
        if now_ts() - blob.get('t', 0) > CACHE_TTL:
            return None
        return blob.get('v')
    except Exception:
        return None


def _cache_set(key, value):
    p = _cache_path(key)
    try:
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, 'w', encoding='utf-8') as f:
            json.dump({'t': now_ts(), 'v': value}, f)
    except Exception as e:
        log_error('tmdb cache write failed: {0}'.format(e))


def _get(path, params=None):
    api_key = get_setting('tmdb_api_key', '').strip()
    if not api_key:
        log_error('TMDB API key missing')
        return None
    p = dict(params or {})
    p['api_key'] = api_key
    p.setdefault('language', get_setting('tmdb_language', 'en-US'))
    cache_key = 'v1_{0}_{1}'.format(path, '_'.join('{0}={1}'.format(k, p[k]) for k in sorted(p) if k != 'api_key'))
    cached = _cache_get(cache_key)
    if cached is not None:
        return cached
    try:
        r = requests.get('{0}/{1}'.format(TMDB_BASE, path), params=p, timeout=8)
        r.raise_for_status()
        data = r.json()
        _cache_set(cache_key, data)
        return data
    except Exception as e:
        log_error('TMDB GET {0} failed: {1}'.format(path, e))
        return None


def get_movie(tmdb_id):
    """
    Returns a normalized dict ready for CocoScrapers:
      {title, originaltitle, year, imdb, tmdb, premiered, plot, runtime, mediatype}
    Returns None on failure.
    """
    data = _get('movie/{0}'.format(tmdb_id), params={'append_to_response': 'external_ids'})
    if not data:
        return None
    title = data.get('title') or data.get('original_title') or ''
    rd = data.get('release_date') or ''
    year = int(rd[:4]) if rd[:4].isdigit() else 0
    out = {
        'title': title,
        'originaltitle': data.get('original_title') or title,
        'year': year,
        'imdb': (data.get('external_ids') or {}).get('imdb_id') or data.get('imdb_id') or '',
        'tmdb': str(tmdb_id),
        'premiered': rd,
        'plot': data.get('overview') or '',
        'runtime': data.get('runtime') or 0,
        'mediatype': 'movie',
        'poster': data.get('poster_path') or '',
        'fanart': data.get('backdrop_path') or '',
    }
    return out


def get_tvshow(tmdb_id):
    data = _get('tv/{0}'.format(tmdb_id), params={'append_to_response': 'external_ids'})
    if not data:
        return None
    name = data.get('name') or data.get('original_name') or ''
    fa = data.get('first_air_date') or ''
    year = int(fa[:4]) if fa[:4].isdigit() else 0
    out = {
        'tvshowtitle': name,
        'originaltitle': data.get('original_name') or name,
        'year': year,
        'imdb': (data.get('external_ids') or {}).get('imdb_id') or '',
        'tvdb': str((data.get('external_ids') or {}).get('tvdb_id') or ''),
        'tmdb': str(tmdb_id),
        'premiered': fa,
        'plot': data.get('overview') or '',
        'mediatype': 'tvshow',
        'poster': data.get('poster_path') or '',
        'fanart': data.get('backdrop_path') or '',
    }
    return out


def get_episode(tmdb_id, season, episode):
    """
    Combines tvshow metadata with the specific episode's data — what
    CocoScrapers needs to scrape a single episode.
    """
    show = get_tvshow(tmdb_id)
    if not show:
        return None
    ep = _get('tv/{0}/season/{1}/episode/{2}'.format(tmdb_id, season, episode))
    if not ep:
        return None
    air = ep.get('air_date') or ''
    out = dict(show)
    out.update({
        'title': ep.get('name') or 'Episode {0}'.format(episode),
        'season': int(season),
        'episode': int(episode),
        'premiered': air,
        'episode_plot': ep.get('overview') or '',
        'mediatype': 'episode',
    })
    return out


def find_by_imdb(imdb_id, tmdb_type='tv'):
    """
    Resolve an IMDB id to a TMDB id via TMDB's /find endpoint.

    Returns the TMDB id of the show (for tv) or movie (for movie),
    or None if not found. Used when TMDb Helper passes us an IMDB id
    (more reliable than tmdb id from Trakt sources, where the tmdb id
    is sometimes the episode's, not the show's).
    """
    if not imdb_id:
        return None
    data = _get('find/{0}'.format(imdb_id),
                params={'external_source': 'imdb_id'})
    if not data:
        return None
    if tmdb_type == 'tv':
        results = data.get('tv_results') or []
    else:
        results = data.get('movie_results') or []
    if not results:
        log_error('IMDB lookup found no {0} for {1}'.format(tmdb_type, imdb_id))
        return None
    return results[0].get('id')
