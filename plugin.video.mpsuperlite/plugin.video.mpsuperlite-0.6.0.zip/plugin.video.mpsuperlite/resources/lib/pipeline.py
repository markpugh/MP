# -*- coding: utf-8 -*-
"""
Shared resolve pipeline: meta -> scrape -> rank -> debrid-resolve -> url.

Extracted so both the interactive play path (default.py:_play) and the
background Up Next pre-resolver use the EXACT same source-selection logic.
The only difference is UI: _play passes progress callbacks that drive
on-screen dialogs; the background pre-resolver passes none (silent).

Returns the resolve_first_cached result dict {url, source, service} or
None. Never raises — background callers can't surface exceptions to a UI.
"""
from resources.lib.common import log, log_error, get_bool


def resolve_stream(meta, progress_cb=None, interactive=False):
    """
    meta: dict from tmdb.get_movie() / tmdb.get_episode().
    progress_cb: optional callable(pct, msg) for scrape, callable(msg) for
                 debrid — matches the existing _play callbacks. Pass None
                 for silent background use.
    interactive: if True and auto_play is off, caller handles source
                 picking; the background path always forces auto (top
                 candidates) since there's no user to pick.

    Returns {url, source, service} or None.
    """
    try:
        from resources.lib import scraper, sources
        from resources.lib.debrid import resolver as debrid_resolver
        from resources.lib.debrid import rd_client, ad_client
    except Exception as e:
        log_error('resolve_stream import failed: {0}'.format(e))
        return None

    if not (rd_client.is_authorized() or ad_client.is_authorized()):
        log('resolve_stream: no debrid authorized')
        return None

    # Scrape
    def scrape_cb(pct, msg=''):
        if progress_cb:
            try:
                progress_cb(pct, msg)
            except Exception:
                pass

    try:
        raw_sources = scraper.scrape(meta, progress_cb=scrape_cb if progress_cb else None)
    except Exception as e:
        log_error('resolve_stream scrape failed: {0}'.format(e))
        return None
    if not raw_sources:
        log('resolve_stream: no sources')
        return None

    # Rank
    ranked = sources.filter_and_rank(raw_sources)
    if not ranked:
        log('resolve_stream: nothing survived ranking')
        return None

    # Debrid resolve. Background path always uses the ranked list (auto);
    # interactive picking stays in _play where the dialog lives.
    try:
        result = debrid_resolver.resolve_first_cached(
            ranked, progress_cb=None, meta=meta)
    except Exception as e:
        log_error('resolve_stream debrid failed: {0}'.format(e))
        return None

    if not result:
        log('resolve_stream: no cached source')
        return None
    return result
