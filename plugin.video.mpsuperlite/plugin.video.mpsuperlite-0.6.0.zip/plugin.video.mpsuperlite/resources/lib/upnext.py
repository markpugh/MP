# -*- coding: utf-8 -*-
"""
Up Next support for MP SuperLite.

Two responsibilities:
  1. next_episode(): given the currently-playing show + S/E, work out the
     next episode (rolling over a season boundary), returning enriched
     TMDB meta or None when there's no next episode.
  2. A pre-resolution STASH: while episode N plays, the service resolves
     episode N+1's stream in the background and stashes {token: url+meta}
     in a Home-window property. The play route reads it for instant
     playback; a miss simply falls back to a normal live resolve.

The stash lives in a window property (not disk) so it's shared across the
service thread and the play-plugin invocation without file locking, and so
it evaporates on Kodi restart (a stale debrid URL should never outlive a
session).
"""
import json

import xbmc
import xbmcgui

from resources.lib import tmdb
from resources.lib.common import log, now_ts

# Home window — properties here are global and cross-thread/-invocation.
_WIN = xbmcgui.Window(10000)
_STASH_PROP = 'mpsuperlite.upnext.stash'

# A pre-resolved debrid URL is good for hours, but we only need it to
# survive one episode's runtime. Cap the stash freshness so we never hand
# Kodi a link that's been sitting around since a previous session.
_STASH_TTL = 4 * 60 * 60  # 4h


def token_for(tmdb_id, season, episode):
    return '{0}_{1}_{2}'.format(tmdb_id, int(season), int(episode))


def next_episode(tmdb_id, season, episode):
    """
    Return enriched episode meta for the episode after (season, episode),
    or None if there is no next episode.

    Strategy: try (season, episode+1) first. If TMDB has no such episode
    (we've hit the end of the season), roll to (season+1, 1). If that
    doesn't exist either, the show is over — return None.
    """
    season = int(season)
    episode = int(episode)

    # Same season, next episode.
    nxt = tmdb.get_episode(tmdb_id, season, episode + 1)
    if nxt:
        return nxt

    # Season boundary — try the next season's premiere.
    nxt = tmdb.get_episode(tmdb_id, season + 1, 1)
    if nxt:
        log('Up Next: rolled over to S{0:02d}E01'.format(season + 1))
        return nxt

    log('Up Next: no next episode after S{0:02d}E{1:02d}'.format(
        season, episode))
    return None


def stash_put(tmdb_id, season, episode, url):
    """Stash a pre-resolved stream URL for the next episode."""
    if not url:
        return
    blob = {
        'token': token_for(tmdb_id, season, episode),
        'url': url,
        't': now_ts(),
    }
    try:
        _WIN.setProperty(_STASH_PROP, json.dumps(blob))
        log('Up Next: stashed pre-resolved URL for {0}'.format(blob['token']))
    except Exception as e:
        log('Up Next: stash_put failed: {0}'.format(e))


def stash_take(tmdb_id, season, episode):
    """
    Pop the stashed URL for this episode if present and fresh. Returns the
    URL or None. Single-use: the property is cleared on read so a stale
    URL can't be replayed for a later, different episode.
    """
    want = token_for(tmdb_id, season, episode)
    try:
        raw = _WIN.getProperty(_STASH_PROP)
        if not raw:
            return None
        blob = json.loads(raw)
    except Exception:
        return None
    # Clear regardless of match — the stash holds exactly one pending
    # next-episode at a time; a mismatch means it's stale.
    try:
        _WIN.clearProperty(_STASH_PROP)
    except Exception:
        pass
    if blob.get('token') != want:
        return None
    if now_ts() - blob.get('t', 0) > _STASH_TTL:
        log('Up Next: stash for {0} expired'.format(want))
        return None
    log('Up Next: stash HIT for {0} — instant playback'.format(want))
    return blob.get('url')


def build_play_url(tmdb_id, next_meta):
    """The plugin:// URL Up Next queues to play the next episode. Routes
    through the normal play action (so watch-state/scrobble are identical
    to a manual play); upnext=1 makes _play check the stash first."""
    return ('plugin://plugin.video.mpsuperlite/?action=play&tmdb_type=tv'
            '&tmdb_id={0}&season={1}&episode={2}&upnext=1').format(
        tmdb_id, int(next_meta['season']), int(next_meta['episode']))


_TMDB_IMG = 'https://image.tmdb.org/t/p/'


def _art(meta):
    poster = meta.get('poster') or ''
    fanart = meta.get('fanart') or ''
    art = {}
    if poster:
        art['thumb'] = _TMDB_IMG + 'w500' + poster
        art['poster'] = art['thumb']
    if fanart:
        art['fanart'] = _TMDB_IMG + 'w1280' + fanart
    return art


def _episode_payload(meta, episodeid=-1):
    """Shape an episode dict the way Up Next expects it for the card."""
    return {
        'episodeid': episodeid,
        'tvshowid': meta.get('tmdb') or -1,
        'title': meta.get('title') or '',
        'art': _art(meta),
        'season': int(meta.get('season') or 0),
        'episode': int(meta.get('episode') or 0),
        'showtitle': meta.get('tvshowtitle') or '',
        'plot': meta.get('episode_plot') or meta.get('plot') or '',
        'playcount': 0,
        'rating': None,
        'firstaired': meta.get('premiered') or '',
        'runtime': int(meta.get('runtime') or 0) * 60 if meta.get('runtime') else 0,
    }


def send_signal(tmdb_id, current_meta, next_meta):
    """
    Fire the upnext_data signal so the branded card appears near the end of
    the current episode. play_url routes the next episode back through our
    own play action. Returns True if the signal was sent.

    Uses AddonSignals (script.module.addon.signals). Up Next receives this
    via Kodi's onNotification and reads play_url to queue the next item.
    """
    try:
        import AddonSignals  # noqa: N813 (module name is fixed)
    except Exception as e:
        log('Up Next: AddonSignals unavailable, cannot send card: {0}'.format(e))
        return False

    payload = {
        'current_episode': _episode_payload(current_meta),
        'next_episode': _episode_payload(next_meta),
        'play_url': build_play_url(tmdb_id, next_meta),
    }
    try:
        AddonSignals.sendSignal('upnext_data', payload,
                                source_id='plugin.video.mpsuperlite')
        log('Up Next: sent card for next S{0:02d}E{1:02d}'.format(
            int(next_meta['season']), int(next_meta['episode'])))
        return True
    except Exception as e:
        log('Up Next: sendSignal failed: {0}'.format(e))
        return False
