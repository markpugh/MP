# -*- coding: utf-8 -*-
"""
MP SuperLite — Up Next service.

A persistent Kodi service that delivers the branded "Up Next" card and
seamless next-episode autoplay for episodes played through SuperLite.

Why a service (not the play route): instant next-episode playback requires
pre-resolving episode N+1's stream WHILE episode N is still playing. The
play route exits the moment it calls setResolvedUrl (Kodi takes over and
the script dies), so background work can't live there. A service persists
for the whole Kodi session and can run that background resolve.

Flow per episode:
  1. _play() publishes the now-playing context (tmdb_id/season/episode)
     to a Home-window property right before it resolves.
  2. onAVStarted fires. We read that context. If it's an episode, we:
       a. look up the next episode (rolling over season boundaries),
       b. immediately fire the Up Next card (so it shows near the end
          regardless of whether pre-resolution has finished),
       c. kick off a background thread that resolves the next episode's
          stream and stashes the URL for instant playback.
  3. When the card's countdown ends, Up Next queues our play_url, which
     routes back through _play with upnext=1 — that checks the stash and
     plays instantly on a hit, or does a normal live resolve on a miss.

Everything Up Next-related is best-effort: any failure degrades to "no
card" or "card with a short resolve delay", never to broken playback.
"""
import json
import threading

import xbmc
import xbmcgui

from resources.lib.common import log, log_error, get_bool
from resources.lib import upnext

_WIN = xbmcgui.Window(10000)
_NOWPLAYING_PROP = 'mpsuperlite.nowplaying'


def read_nowplaying():
    try:
        raw = _WIN.getProperty(_NOWPLAYING_PROP)
        if not raw:
            return None
        return json.loads(raw)
    except Exception:
        return None


def publish_nowplaying(tmdb_id, season, episode):
    """Called by _play just before resolving a TV episode, so the service
    knows what's about to start without parsing the resolved stream URL
    (which carries no TMDB context)."""
    try:
        _WIN.setProperty(_NOWPLAYING_PROP, json.dumps({
            'tmdb_id': str(tmdb_id),
            'season': int(season),
            'episode': int(episode),
        }))
    except Exception as e:
        log('publish_nowplaying failed: {0}'.format(e))


def clear_nowplaying():
    try:
        _WIN.clearProperty(_NOWPLAYING_PROP)
    except Exception:
        pass


class SuperLitePlayer(xbmc.Player):
    """Watches for playback start and triggers the Up Next handoff."""

    def __init__(self):
        super(SuperLitePlayer, self).__init__()
        self._last_token = None

    def onAVStarted(self):  # noqa: N802 (Kodi callback name)
        try:
            self._handle_start()
        except Exception as e:
            log_error('Up Next onAVStarted error: {0}'.format(e))

    def _handle_start(self):
        if not get_bool('upnext_enabled', True):
            return

        ctx = read_nowplaying()
        if not ctx:
            # Not a SuperLite episode (or a movie) — nothing to do. We do
            # NOT clear here: a movie playing doesn't invalidate a pending
            # episode context, but in practice _play overwrites/clears it.
            return

        tmdb_id = ctx.get('tmdb_id')
        season = ctx.get('season')
        episode = ctx.get('episode')
        if not tmdb_id or season is None or episode is None:
            return

        token = upnext.token_for(tmdb_id, season, episode)
        if token == self._last_token:
            # Already handled this exact episode (onAVStarted can fire more
            # than once for one playback).
            return
        self._last_token = token

        # Consume the context so a later movie playback doesn't re-trigger.
        clear_nowplaying()

        log('Up Next: episode start detected, token={0}'.format(token))

        # Look up current + next episode meta.
        from resources.lib import tmdb as tmdb_mod
        current_meta = tmdb_mod.get_episode(tmdb_id, season, episode)
        if not current_meta:
            log('Up Next: current episode meta lookup failed; skipping')
            return

        next_meta = upnext.next_episode(tmdb_id, season, episode)
        if not next_meta:
            return  # series finale or lookup miss — no card

        # 1. Fire the card immediately so it shows near the end regardless
        #    of whether pre-resolution finishes in time.
        upnext.send_signal(tmdb_id, current_meta, next_meta)

        # 2. Pre-resolve the next episode in the background for instant play.
        t = threading.Thread(
            target=self._preresolve,
            args=(tmdb_id, next_meta),
            name='mpsl-upnext-preresolve',
        )
        t.daemon = True
        t.start()

    def _preresolve(self, tmdb_id, next_meta):
        """Background: resolve next episode's stream and stash the URL.
        A miss is fine — the play_url path falls back to a live resolve."""
        try:
            from resources.lib import pipeline
            log('Up Next: pre-resolving next S{0:02d}E{1:02d}...'.format(
                int(next_meta['season']), int(next_meta['episode'])))
            result = pipeline.resolve_stream(next_meta, progress_cb=None)
            if result and result.get('url'):
                upnext.stash_put(
                    tmdb_id, next_meta['season'], next_meta['episode'],
                    result['url'])
            else:
                log('Up Next: pre-resolve found no cached source; '
                    'next-episode play will resolve live')
        except Exception as e:
            log_error('Up Next pre-resolve crashed: {0}'.format(e))


def main():
    log('Up Next service starting')
    monitor = xbmc.Monitor()
    player = SuperLitePlayer()  # noqa: F841 — kept alive by the loop below
    while not monitor.abortRequested():
        if monitor.waitForAbort(2):
            break
    log('Up Next service stopped')


if __name__ == '__main__':
    main()
