# -*- coding: utf-8 -*-
"""
Debrid resolution orchestrator.

Given a list of ranked sources, walks them top-down asking each
configured debrid service "is this cached? if so give me the playable
URL". Returns the first cached hit. If a source isn't cached it gets
deleted from the user's debrid account before moving to the next.

This is the post-2024 pattern that replaces the dead RD
/instantAvailability batch endpoint.
"""
import time

from resources.lib.common import log, log_warning, get_int, get_setting
from resources.lib.debrid import rd_client, ad_client


def _get_hash(source):
    """Pull a hash or magnet from a source dict."""
    h = source.get('hash')
    url = source.get('url') or ''
    if h:
        return h
    if url.startswith('magnet:'):
        return url
    return None


def _service_order():
    """
    Return the list of services to try in priority order.
    Settings: debrid_priority is a string label from settings.xml.
    """
    pref = get_setting('debrid_priority') or 'Real Debrid first'
    services = []
    if pref == 'AllDebrid first':
        if ad_client.is_authorized():
            services.append(('AllDebrid', ad_client))
        if rd_client.is_authorized():
            services.append(('Real Debrid', rd_client))
    else:
        if rd_client.is_authorized():
            services.append(('Real Debrid', rd_client))
        if ad_client.is_authorized():
            services.append(('AllDebrid', ad_client))
    return services


def resolve_first_cached(sources, progress_cb=None, max_attempts=None):
    """
    sources: list of normalized source dicts (already ranked, best first).
    progress_cb: callable(message: str) — UI feedback for the long retry loop.
    max_attempts: cap how many sources to try before giving up.

    Returns dict {url, source} on success, or None on full failure.
    """
    if not sources:
        return None

    services = _service_order()
    if not services:
        log_warning('No debrid services authorized — cannot resolve any source')
        return None

    if max_attempts is None:
        max_attempts = get_int('max_attempts', 10)
    max_attempts = max(1, min(max_attempts, 25))

    candidates = sources[:max_attempts]
    log('Debrid resolve: trying up to {0} sources across {1} service(s)'.format(
        len(candidates), len(services)))

    attempts = 0
    for src in candidates:
        attempts += 1
        h = _get_hash(src)
        if not h:
            log('Source {0}: no hash/magnet, skipping'.format(src.get('provider')))
            continue

        for svc_name, svc in services:
            label = src.get('release_title') or src.get('provider') or '?'
            label_short = label[:50]
            if progress_cb:
                try:
                    progress_cb('[{0}/{1}] {2} via {3}: {4}'.format(
                        attempts, len(candidates), src.get('quality') or '?',
                        svc_name, label_short))
                except Exception:
                    pass

            log('Attempt {0}/{1}: {2} via {3} ({4})'.format(
                attempts, len(candidates), src.get('quality'),
                svc_name, label_short))

            def inner_progress(msg):
                if progress_cb:
                    try:
                        progress_cb('[{0}/{1}] {2}: {3}'.format(
                            attempts, len(candidates), svc_name, msg))
                    except Exception:
                        pass

            try:
                outcome, url = svc.try_resolve(h, progress_cb=inner_progress)
            except Exception as e:
                log_warning('{0} try_resolve raised: {1}'.format(svc_name, e))
                continue

            if outcome == 'cached' and url:
                log('  -> CACHED on {0}: {1}'.format(svc_name, url[:80]))
                return {'url': url, 'source': src, 'service': svc_name}
            elif outcome == 'uncached':
                log('  -> not cached on {0}'.format(svc_name))
                # fall through and try next service for this same source
                continue
            else:
                log('  -> failed on {0}'.format(svc_name))
                continue

    log_warning('No cached source found after {0} attempts'.format(attempts))
    return None
