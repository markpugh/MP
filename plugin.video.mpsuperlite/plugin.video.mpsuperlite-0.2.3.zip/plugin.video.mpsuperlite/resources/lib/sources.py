# -*- coding: utf-8 -*-
"""
Source ranking. Takes the normalized list from scraper.scrape() and orders
it according to user preferences (quality cap, cached-only, codec preference).
"""
from resources.lib.common import get_int, get_bool, log


_QUALITY_RANK = {'4K': 4, '1080p': 3, '720p': 2, 'SD': 1}

# settings 'quality_max' enum: 0=4K, 1=1080p, 2=720p, 3=any
_QUALITY_CAP = {0: 4, 1: 3, 2: 2, 3: 99}


def _quality_score(s):
    return _QUALITY_RANK.get(s.get('quality') or 'SD', 1)


def filter_and_rank(sources):
    """
    Returns a new list, filtered by user prefs and sorted from best to worst.
    Best == cached on a debrid > higher quality > preferred codec > larger
    file size (proxy for bitrate).
    """
    if not sources:
        return []

    cached_only = get_bool('cached_only', True)
    cap_idx = get_int('quality_max', 1)
    cap = _QUALITY_CAP.get(cap_idx, 99)
    prefer_hevc = get_bool('prefer_hevc', True)

    # Filter step
    filtered = []
    for s in sources:
        if cached_only and not s.get('cached'):
            continue
        if _quality_score(s) > cap:
            continue
        filtered.append(s)

    if not filtered and cached_only:
        # Fallback: if we filtered everything out by requiring cached,
        # show uncached sources too so the user has something to pick from.
        log('No cached sources within quality cap; falling back to uncached.')
        filtered = [s for s in sources if _quality_score(s) <= cap]

    # Sort step — multi-key, descending
    def sort_key(s):
        codec_pref = 1 if (prefer_hevc and s.get('codec') == 'h265') else 0
        return (
            1 if s.get('cached') else 0,           # cached first
            _quality_score(s),                     # higher quality first
            codec_pref,                            # preferred codec first
            float(s.get('size_gb') or 0),          # bigger first (proxy for bitrate)
        )

    filtered.sort(key=sort_key, reverse=True)
    return filtered


def picker_label(s):
    """Human-readable line for the source-picker dialog."""
    bits = []
    bits.append(s.get('quality') or 'SD')
    if s.get('cached'):
        bits.append('cached')
    if s.get('codec') == 'h265':
        bits.append('HEVC')
    if s.get('hdr'):
        bits.append('HDR')
    sg = s.get('size_gb') or 0
    if sg > 0:
        bits.append('{0:.1f}GB'.format(sg))
    bits.append(s.get('provider') or '?')
    return ' \u2022 '.join(bits) + '   ' + (s.get('release_title') or '')[:80]
