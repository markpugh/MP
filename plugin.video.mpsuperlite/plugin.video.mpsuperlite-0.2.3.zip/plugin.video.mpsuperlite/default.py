# -*- coding: utf-8 -*-
"""
MP SuperLite — entry point.

Routes:
  ?action=play&tmdb_type=movie&tmdb_id=X
  ?action=play&tmdb_type=tv&tmdb_id=X&season=S&episode=E
  ?action=auth_rd            -> open Real Debrid QR auth dialog
  ?action=auth_rd_clear      -> wipe stored RD tokens
  ?action=auth_ad            -> open AllDebrid QR auth dialog
  ?action=auth_ad_clear      -> wipe stored AD tokens
  (no params)                -> directory listing with auth shortcuts
"""
import sys
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

ADDON = xbmcaddon.Addon('plugin.video.mpsuperlite')
ADDON_PATH = ADDON.getAddonInfo('path')
sys.path.insert(0, ADDON_PATH)


def _parse_args():
    if len(sys.argv) < 3:
        return {}
    qs = sys.argv[2]
    if qs.startswith('?'):
        qs = qs[1:]
    return urllib.parse.parse_qs(qs, keep_blank_values=True)


def _arg(args, key, default=''):
    v = args.get(key)
    if not v:
        return default
    return v[0] if isinstance(v, list) else v


def _handle():
    if len(sys.argv) < 2:
        return -1
    try:
        return int(sys.argv[1])
    except (ValueError, TypeError):
        return -1


def _play(args):
    """Orchestrate the play pipeline: TMDB -> scrape -> rank -> resolve -> play."""
    from resources.lib import tmdb, scraper, sources, resolver, player
    from resources.lib.common import log, log_error, get_bool, ADDON_NAME

    tmdb_type = _arg(args, 'tmdb_type', 'movie')
    tmdb_id = _arg(args, 'tmdb_id')
    if not tmdb_id:
        xbmcgui.Dialog().ok(ADDON_NAME, 'No tmdb_id provided.')
        return

    # Step 1: TMDB metadata
    if tmdb_type == 'tv':
        season = _arg(args, 'season')
        episode = _arg(args, 'episode')
        if not season or not episode:
            xbmcgui.Dialog().ok(ADDON_NAME,
                                'TV playback requires season and episode.')
            return
        meta = tmdb.get_episode(tmdb_id, season, episode)
    else:
        meta = tmdb.get_movie(tmdb_id)

    if not meta:
        xbmcgui.Dialog().notification(
            ADDON_NAME, 'TMDB lookup failed.',
            xbmcgui.NOTIFICATION_ERROR, 3000)
        return

    if not meta.get('imdb'):
        log_error('No IMDB id in TMDB response — scraping will likely fail.')

    # Step 2: scrape with progress dialog
    progress = xbmcgui.DialogProgressBG()
    try:
        progress.create(ADDON_NAME, 'Searching sources...')
        def cb(pct, msg=''):
            try:
                progress.update(int(pct), ADDON_NAME, msg or '')
            except Exception:
                pass
        raw_sources = scraper.scrape(meta, progress_cb=cb)
    finally:
        try:
            progress.close()
        except Exception:
            pass

    if not raw_sources:
        xbmcgui.Dialog().notification(
            ADDON_NAME, 'No sources found.',
            xbmcgui.NOTIFICATION_INFO, 3000)
        return

    # Step 3: rank
    ranked = sources.filter_and_rank(raw_sources)
    if not ranked:
        xbmcgui.Dialog().notification(
            ADDON_NAME, 'No sources after filtering.',
            xbmcgui.NOTIFICATION_INFO, 3000)
        return

    # Step 4: pick (auto-play top, or show picker)
    if get_bool('auto_play', True):
        pick = ranked[0]
        log('Auto-playing top source: {0}'.format(sources.picker_label(pick)))
    else:
        labels = [sources.picker_label(s) for s in ranked[:50]]
        idx = xbmcgui.Dialog().select('Pick a source', labels)
        if idx < 0:
            return
        pick = ranked[idx]

    # Step 5: resolve to playable URL
    progress = xbmcgui.DialogProgressBG()
    try:
        progress.create(ADDON_NAME, 'Resolving stream...')
        stream_url = resolver.resolve(pick)
    finally:
        try:
            progress.close()
        except Exception:
            pass

    if not stream_url:
        # Try the next source if the top one failed to resolve
        log('Top source failed to resolve; trying next.')
        for fallback in ranked[1:5]:
            stream_url = resolver.resolve(fallback)
            if stream_url:
                pick = fallback
                break

    if not stream_url:
        xbmcgui.Dialog().notification(
            ADDON_NAME, 'Could not resolve a playable URL.',
            xbmcgui.NOTIFICATION_ERROR, 3000)
        return

    # Step 6: play
    player.play(meta, stream_url)


def _root_dir(handle):
    """Show a small menu when the addon is opened directly."""
    from resources.lib.common import ADDON_NAME, get_setting
    items = []

    rd_status = get_setting('rd_status', 'Not connected')
    items.append((
        'plugin://plugin.video.mpsuperlite/?action=auth_rd',
        xbmcgui.ListItem(label='[B]Real Debrid:[/B] ' + rd_status),
        False,
    ))
    ad_status = get_setting('ad_status', 'Not connected')
    items.append((
        'plugin://plugin.video.mpsuperlite/?action=auth_ad',
        xbmcgui.ListItem(label='[B]AllDebrid:[/B] ' + ad_status),
        False,
    ))
    items.append((
        'plugin://plugin.video.mpsuperlite/?action=settings',
        xbmcgui.ListItem(label='Settings'),
        False,
    ))
    xbmcplugin.addDirectoryItems(handle, items, len(items))
    xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)


def main():
    args = _parse_args()
    action = _arg(args, 'action')
    handle = _handle()

    if action == 'play':
        _play(args)
        # play happens async via Player(); resolve the directory call
        if handle >= 0:
            try:
                xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)
            except Exception:
                pass
        return

    if action == 'auth_rd':
        from resources.lib.auth import rd
        rd.start_authorization()
        return

    if action == 'auth_rd_clear':
        from resources.lib.auth import rd
        rd.clear_authorization()
        return

    if action == 'auth_ad':
        from resources.lib.auth import ad
        ad.start_authorization()
        return

    if action == 'auth_ad_clear':
        from resources.lib.auth import ad
        ad.clear_authorization()
        return

    if action == 'settings':
        ADDON.openSettings()
        if handle >= 0:
            try:
                xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)
            except Exception:
                pass
        return

    # Default: show small directory listing
    if handle >= 0:
        _root_dir(handle)


if __name__ == '__main__':
    main()
