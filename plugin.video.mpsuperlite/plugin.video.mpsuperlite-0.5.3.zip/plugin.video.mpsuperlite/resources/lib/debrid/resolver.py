# -*- coding: utf-8 -*-
"""
Debrid resolution orchestrator.

Given a list of ranked sources, walks them top-down asking each
configured debrid service "is this cached? if so give me the playable
URL". Returns the first cached hit. If a source isn't cached it gets
deleted from the user's debrid account before moving to the next.

This is the post-2024 pattern that replaces the dead RD
/instantAvailability batch endpoint.
"""
import time

from resources.lib.common import log, log_warning, get_int, get_setting
from resources.lib.debrid import rd_client, ad_client


# How long to wait for a HEAD request when validating a pre-resolved URL.
# Short — if the URL doesn't respond in 4s it's effectively dead for streaming
# purposes and we should fall through to the next source rather than make
# the user wait.
_LIVENESS_TIMEOUT = 4.0


def _url_is_live(url):
    """
    Validate that a pre-resolved debrid URL is actually serving video.

    Why this is more than a status check: RD serves its DMCA takedown
    message as HTTP 200 OK with an HTML body, not a 404 or 410. So
    "URL returns 200" does NOT mean "URL is playable" — we have to
    look at what the URL is *serving*. Specifically:

      - Content-Type must indicate video (video/*, application/octet-
        stream, or application/x-mpegURL for HLS). NOT text/html.
      - Content-Length must be substantial (>1 MB). A DMCA HTML page
        is a few KB. Real video files are at minimum hundreds of MB.

    Either failure → URL is dead for our purposes, skip it.

    Cost: bounded by _LIVENESS_TIMEOUT (4s). Typical RD response time
    for a HEAD is 100-300ms.
    """
    if not url:
        return False
    try:
        from urllib.request import Request, urlopen
        req = Request(url, method='HEAD', headers={
            'User-Agent': 'plugin.video.mpsuperlite/0.5.x',
            # Match what a real video player sends so RD doesn't 403 us
            'Accept': '*/*',
            'Range': 'bytes=0-0',
        })
        with urlopen(req, timeout=_LIVENESS_TIMEOUT) as resp:
            code = resp.getcode()
            if not (200 <= code < 400):
                log('Liveness: status {0} for {1}'.format(code, url[:80]))
                return False

            # Content-Type check. RD's DMCA page comes back as text/html;
            # a real video stream is video/* or application/octet-stream.
            content_type = (resp.headers.get('Content-Type') or '').lower()
            if content_type:
                if content_type.startswith('text/') or 'html' in content_type:
                    log('Liveness: non-video Content-Type {0!r} (likely DMCA) for {1}'.format(
                        content_type, url[:80]))
                    return False

            # Content-Length check. DMCA HTML is a few KB; real video is
            # hundreds of MB minimum. If Content-Length is present and
            # tiny, this isn't video. (Some debrid servers don't send
            # Content-Length on HEAD — only enforce when present.)
            cl_header = resp.headers.get('Content-Length')
            if cl_header:
                try:
                    cl = int(cl_header)
                    # 1 MB threshold — well below any real video file,
                    # well above any HTML error page
                    if cl < 1_000_000:
                        log('Liveness: Content-Length {0} too small (likely DMCA page) '
                            'for {1}'.format(cl, url[:80]))
                        return False
                except (ValueError, TypeError):
                    pass

            return True
    except Exception as e:
        # urllib HTTPError (404 etc), URLError, timeout, socket errors —
        # all dead for our purposes
        log('Liveness: request failed for {0}: {1}'.format(url[:80], e))
        return False


def _get_hash(source):
    """Pull a hash or magnet from a source dict."""
    h = source.get('hash')
    url = source.get('url') or ''
    if h:
        return h
    if url.startswith('magnet:'):
        return url
    return None


def _service_order():
    """
    Return the list of services to try in priority order.
    Settings: debrid_priority is a string label from settings.xml.
    """
    pref = get_setting('debrid_priority') or 'Real Debrid first'
    services = []
    if pref == 'AllDebrid first':
        if ad_client.is_authorized():
            services.append(('AllDebrid', ad_client))
        if rd_client.is_authorized():
            services.append(('Real Debrid', rd_client))
    else:
        if rd_client.is_authorized():
            services.append(('Real Debrid', rd_client))
        if ad_client.is_authorized():
            services.append(('AllDebrid', ad_client))
    return services


def resolve_first_cached(sources, progress_cb=None, max_attempts=None):
    """
    sources: list of normalized source dicts (already ranked, best first).
    progress_cb: callable(message: str) — UI feedback for the long retry loop.
    max_attempts: cap how many sources to try before giving up.

    Returns dict {url, source} on success, or None on full failure.
    """
    if not sources:
        return None

    services = _service_order()
    if not services:
        log_warning('No debrid services authorized — cannot resolve any source')
        return None

    # FAST PATH: Torrentio (and other server-side debrid scrapers) already
    # do the cache check on their end, returning a fully-resolved playable
    # debrid URL. We validate each URL with a HEAD request before returning
    # it — RD periodically purges DMCA'd files from its cache, and
    # Torrentio's "cached" flag can be stale by minutes-to-hours.
    # Without the HEAD check, the user gets RD's loud orange error message
    # mid-playback. With it, we silently skip the dead URL and try the
    # next ranked source.
    pre_resolved = []
    for src in sources:
        if not src.get('cached'):
            continue
        url = src.get('url') or ''
        if not url.startswith(('http://', 'https://')):
            continue
        if url.startswith('magnet:'):
            continue
        pre_resolved.append(src)

    if pre_resolved:
        log('Found {0} pre-resolved candidate(s), validating...'.format(
            len(pre_resolved)))
        for src in pre_resolved[:5]:  # cap validation attempts to keep play snappy
            url = src.get('url') or ''
            if _url_is_live(url):
                debrid_label = src.get('debrid') or 'pre-resolved'
                log('Validated pre-resolved cached source from {0} ({1}): {2}'.format(
                    src.get('provider'), debrid_label, url[:80]))
                if progress_cb:
                    try:
                        progress_cb('Using pre-resolved {0} stream'.format(
                            src.get('quality') or 'cached'))
                    except Exception:
                        pass
                return {'url': url, 'source': src, 'service': debrid_label}
            else:
                log('Pre-resolved URL failed liveness check (likely DMCA or '
                    'expired), trying next: {0}'.format(url[:80]))

        log('All pre-resolved candidates failed validation; falling through '
            'to live cache-check path')

    if max_attempts is None:
        max_attempts = get_int('max_attempts', 10)
    max_attempts = max(1, min(max_attempts, 25))

    candidates = sources[:max_attempts]
    log('Debrid resolve: trying up to {0} sources across {1} service(s)'.format(
        len(candidates), len(services)))

    attempts = 0
    for src in candidates:
        attempts += 1
        h = _get_hash(src)
        if not h:
            log('Source {0}: no hash/magnet, skipping'.format(src.get('provider')))
            continue

        for svc_name, svc in services:
            label = src.get('release_title') or src.get('provider') or '?'
            label_short = label[:50]
            if progress_cb:
                try:
                    progress_cb('[{0}/{1}] {2} via {3}: {4}'.format(
                        attempts, len(candidates), src.get('quality') or '?',
                        svc_name, label_short))
                except Exception:
                    pass

            log('Attempt {0}/{1}: {2} via {3} ({4})'.format(
                attempts, len(candidates), src.get('quality'),
                svc_name, label_short))

            def inner_progress(msg):
                if progress_cb:
                    try:
                        progress_cb('[{0}/{1}] {2}: {3}'.format(
                            attempts, len(candidates), svc_name, msg))
                    except Exception:
                        pass

            try:
                outcome, url = svc.try_resolve(h, progress_cb=inner_progress)
            except Exception as e:
                log_warning('{0} try_resolve raised: {1}'.format(svc_name, e))
                continue

            if outcome == 'cached' and url:
                log('  -> CACHED on {0}: {1}'.format(svc_name, url[:80]))
                return {'url': url, 'source': src, 'service': svc_name}
            elif outcome == 'uncached':
                log('  -> not cached on {0}'.format(svc_name))
                # fall through and try next service for this same source
                continue
            else:
                log('  -> failed on {0}'.format(svc_name))
                continue

    log_warning('No cached source found after {0} attempts'.format(attempts))
    return None
