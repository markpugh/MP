# -*- coding: utf-8 -*-
"""
Torrentio integration.

Torrentio (https://torrentio.strem.fun) is the dominant cached-debrid
source provider in the Stremio/Kodi ecosystem. It indexes ~30+ torrent
trackers and pre-checks RD/AD cache status server-side, returning
ready-to-stream URLs for whatever's already in your debrid provider's
shared cache.

This module hits Torrentio's stream JSON endpoint and converts the
results into the same source-dict shape scraper.py emits, so they merge
cleanly with CocoScrapers' results upstream.

API shape (no signup required — your debrid token IS the auth):
  GET https://torrentio.strem.fun/{config}/stream/{type}/{imdb}.json
  where:
    {config} is a slash-joined option list, e.g.
      providers=...|qualityfilter=...|debridoptions=...|realdebrid=TOKEN
    {type} is "movie" or "series"
    {imdb} for movies is "ttXXXXXXX"
    for episodes is "ttXXXXXXX:S:E"

Response is JSON: {"streams": [{"name": "RD+ Torrentio | 1080p", ...}, ...]}
where each stream has either a direct URL (cached on debrid) or an
infoHash + sources (uncached). We forward both — the upstream debrid
gate in sources.py drops anything that can't resolve through debrid.

Privacy model: the user's RD/AD token gets sent to torrentio.strem.fun
on every query. This is the standard accepted trust model for the
ecosystem (every Stremio user with debrid does this; every Kodi build
using Torrentio does this) but worth knowing.
"""
import json
import re

from resources.lib.common import (
    log, log_warning, log_error, get_setting, get_bool,
)
from resources.lib.debrid import rd_client, ad_client


TORRENTIO_BASE = 'https://torrentio.strem.fun'
TORRENTIO_TIMEOUT = 12  # seconds; torrentio is usually fast (1-3s) but be patient

# Default provider list. Matches the Stremio addon's "all" toggle. We
# include all major indexers — torrentio's server-side filtering and
# debrid cache check makes the wide net cheap.
DEFAULT_PROVIDERS = ','.join([
    'yts', 'eztv', 'rarbg', '1337x', 'thepiratebay', 'kickasstorrents',
    'torrentgalaxy', 'magnetdl', 'horriblesubs', 'nyaasi', 'tokyotosho',
    'anidex', 'rutor', 'rutracker', 'comando', 'bludv', 'torrent9',
    'ilcorsaronero', 'mejortorrent', 'wolfmax4k', 'cinecalidad',
    'besttorrents',
])


def _http_get_json(url, timeout=TORRENTIO_TIMEOUT):
    """Plain GET returning parsed JSON, or None on failure."""
    try:
        # Use stdlib urllib — no extra dependency, ships with Python 3
        from urllib.request import Request, urlopen
        req = Request(url, headers={
            'User-Agent': 'plugin.video.mpsuperlite/0.5.0',
            'Accept': 'application/json',
        })
        with urlopen(req, timeout=timeout) as resp:
            data = resp.read()
        return json.loads(data.decode('utf-8'))
    except Exception as e:
        log_warning('Torrentio HTTP failed: {0}'.format(e))
        return None


def _build_config(debrid_service, debrid_token):
    """
    Build the slash-joined config string Torrentio expects in the URL path.
    Includes provider list, quality filter, sort order, and debrid auth.

    debrid_service: 'realdebrid' | 'alldebrid' | 'premiumize' | None
    debrid_token: the user's API token for that service
    """
    parts = [
        'providers=' + DEFAULT_PROVIDERS,
        # Drop low-quality stuff at server side — saves bandwidth and
        # avoids us having to filter cam/screener spam locally.
        'qualityfilter=cam,scr,unknown',
        # Sort by quality descending, then by size descending (=better encode)
        'sort=qualitysize',
        # Don't include uncached results — we only want clickable hits.
        # Removing this would let Torrentio also return uncached torrents
        # that the user could then download-and-watch through RD's
        # delayed-cache mode, but our flow doesn't support that.
        'debridoptions=nodownloadlinks,nocatalog',
    ]
    if debrid_service and debrid_token:
        parts.append('{0}={1}'.format(debrid_service, debrid_token))
    return '|'.join(parts)


def _get_active_debrid():
    """
    Pick the user's primary debrid service for the Torrentio query.
    Torrentio supports multiple debrid configs in one URL but it's
    cleaner (and faster) to use one. We follow the user's existing
    debrid_priority preference.

    Returns (service_name, token) or (None, None).
    """
    pref = get_setting('debrid_priority') or 'Real Debrid first'

    if pref == 'AllDebrid first':
        if ad_client.is_authorized():
            try:
                return 'alldebrid', ad_client.get_token()
            except Exception:
                pass
        if rd_client.is_authorized():
            try:
                return 'realdebrid', rd_client.get_token()
            except Exception:
                pass
    else:
        if rd_client.is_authorized():
            try:
                return 'realdebrid', rd_client.get_token()
            except Exception:
                pass
        if ad_client.is_authorized():
            try:
                return 'alldebrid', ad_client.get_token()
            except Exception:
                pass
    return None, None


# Regex helpers for parsing Torrentio's stream descriptions.
# Sample stream.title / stream.name from Torrentio:
#   name = "[RD+] Torrentio\n4K"
#   title = "The.Boys.S01E01.2160p.WEB-DL.x265.HDR.HEVC-RARBG\n👤 142 💾 8.2 GB ⚙️ ThePirateBay"
RE_SIZE = re.compile(r'(\d+(?:\.\d+)?)\s*(GB|MB|TB)', re.IGNORECASE)
RE_QUALITY = re.compile(
    r'\b(2160p|4K|1080p|720p|480p|360p|HDR|DV|REMUX|BluRay|WEB-?DL|WEBRip|BDRip)\b',
    re.IGNORECASE)
RE_INDEXER = re.compile(r'⚙️\s*([A-Za-z0-9]+)')
RE_RD_TAG = re.compile(r'\[RD\+\]|RD\+', re.IGNORECASE)
RE_AD_TAG = re.compile(r'\[AD\+\]|AD\+', re.IGNORECASE)
RE_PM_TAG = re.compile(r'\[PM\+\]|PM\+', re.IGNORECASE)


def _parse_quality(text):
    """Map Torrentio's quality tokens to our internal labels."""
    if not text:
        return 'SD'
    m = RE_QUALITY.search(text)
    if not m:
        return 'SD'
    q = m.group(1).upper().replace('-', '')
    if q in ('2160P', '4K'):
        return '4K'
    if q == '1080P':
        return '1080p'
    if q == '720P':
        return '720p'
    return 'SD'


def _parse_size(text):
    """Pull a size-in-GB float from a Torrentio title string. 0 if unknown."""
    if not text:
        return 0
    m = RE_SIZE.search(text)
    if not m:
        return 0
    val = float(m.group(1))
    unit = m.group(2).upper()
    if unit == 'TB':
        return val * 1024
    if unit == 'MB':
        return val / 1024
    return val  # GB


def _detect_codec(text):
    if not text:
        return 'h264'
    t = text.lower()
    if 'x265' in t or 'h265' in t or 'hevc' in t:
        return 'h265'
    return 'h264'


def _detect_debrid_marker(name, title):
    """
    Inspect the stream's name/title for the [RD+] / [AD+] / [PM+]
    pre-cached marker that Torrentio adds when it confirmed the
    stream is cached on the user's debrid account.
    """
    blob = (name or '') + ' ' + (title or '')
    if RE_RD_TAG.search(blob):
        return 'real_debrid'
    if RE_AD_TAG.search(blob):
        return 'all_debrid'
    if RE_PM_TAG.search(blob):
        return 'premiumize'
    return None


def _convert_stream(stream, debrid_service):
    """
    Convert a single Torrentio stream object to our normalized source
    dict (matches scraper._normalize output).
    """
    name = stream.get('name') or ''
    title = stream.get('title') or ''
    info_hash = (stream.get('infoHash') or '').lower()
    file_idx = stream.get('fileIdx')
    direct_url = stream.get('url') or ''  # Torrentio uses .url for cached debrid

    # If Torrentio gave us a direct URL, the stream is debrid-cached
    # and ready to play. Otherwise it's a torrent we'd have to add
    # ourselves — we skip those because our debrid-only policy means
    # they'd just get dropped downstream anyway.
    if not direct_url and not info_hash:
        return None

    debrid_marker = _detect_debrid_marker(name, title)
    cached = bool(direct_url) or debrid_marker is not None

    # Build a magnet URL from the info hash if no direct URL — this
    # gives the upstream resolve_first_cached path something to query
    # against debrid. Cocoscrapers does the same thing.
    url = direct_url
    if not url and info_hash:
        url = 'magnet:?xt=urn:btih:{0}'.format(info_hash)

    # Provider name: extract the real indexer from the title (e.g.
    # "ThePirateBay" or "1337x") rather than just "torrentio". Helps
    # with the picker dialog and dedup logic.
    indexer_match = RE_INDEXER.search(title)
    indexer = indexer_match.group(1) if indexer_match else None
    provider = 'torrentio:{0}'.format(indexer) if indexer else 'torrentio'

    # Release title: first line of stream.title (the actual filename).
    release_title = title.split('\n', 1)[0].strip() if title else ''

    return {
        'provider': provider,
        'quality': _parse_quality(release_title or name),
        'size_gb': _parse_size(title),
        'debrid': debrid_marker,
        'cached': cached,
        'hash': info_hash,
        'url': url,
        'language': 'en',  # torrentio doesn't tell us; assume en
        'codec': _detect_codec(release_title),
        'hdr': bool(re.search(r'\bHDR\b|\bDV\b', release_title, re.IGNORECASE)),
        'release_title': release_title,
        '_raw': stream,
        '_torrentio_fileidx': file_idx,
    }


def scrape(meta, progress_cb=None):
    """
    Query Torrentio for sources matching the given media meta.
    Returns a list of normalized source dicts (same shape as
    scraper.scrape() returns), or [] on any failure.

    meta: same dict scraper.scrape() takes — must contain imdb, type,
    and (for episodes) season/episode.
    """
    imdb = meta.get('imdb') or ''
    if not imdb or not imdb.startswith('tt'):
        log_warning('Torrentio: no IMDb ID in meta — skipping (id={0!r})'.format(imdb))
        return []

    debrid_service, debrid_token = _get_active_debrid()
    if not debrid_token:
        log_warning('Torrentio: no debrid token — skipping (require_debrid is hardcoded)')
        return []

    # Build the URL. For episodes, append :S:E to the IMDb ID.
    media_type = (meta.get('mediatype') or meta.get('type') or 'movie').lower()
    if media_type in ('tvshow', 'episode', 'tv'):
        season = meta.get('season')
        episode = meta.get('episode')
        if season is None or episode is None:
            log_warning('Torrentio: episode requested but missing season/episode')
            return []
        type_segment = 'series'
        id_segment = '{0}:{1}:{2}'.format(imdb, int(season), int(episode))
    else:
        type_segment = 'movie'
        id_segment = imdb

    config = _build_config(debrid_service, debrid_token)
    url = '{0}/{1}/stream/{2}/{3}.json'.format(
        TORRENTIO_BASE, config, type_segment, id_segment)

    # Don't log the full URL — it contains the debrid token. Log a
    # redacted version for diagnostics.
    safe_url = url.replace(debrid_token, '***REDACTED***')
    log('Torrentio: querying {0}'.format(safe_url))

    if progress_cb:
        try:
            progress_cb(95, 'Querying Torrentio...')
        except Exception:
            pass

    data = _http_get_json(url)
    if not data:
        log_warning('Torrentio: no response or invalid JSON')
        return []

    streams = data.get('streams') or []
    log('Torrentio: got {0} raw streams'.format(len(streams)))

    out = []
    for s in streams:
        try:
            normalized = _convert_stream(s, debrid_service)
            if normalized:
                out.append(normalized)
        except Exception as e:
            log_warning('Torrentio: failed to convert stream: {0}'.format(e))
            continue

    log('Torrentio: {0} usable sources after conversion'.format(len(out)))
    return out
