# -*- coding: utf-8 -*-
"""
Trakt API client for the MP Trakt Helper.

Thin wrapper around the Trakt v2 API. Handles the authenticated request
layer (api key + bearer token + automatic token refresh) and the handful
of endpoints the build actually needs:

  - watched progress for a show  -> what you've seen / what's next
  - add episodes to history      -> mark watched
  - scrobble start/pause/stop    -> real-time "watching now" + auto-watched

Everything is best-effort: a missing token, a network blip, or a non-2xx
response returns a falsy/empty result and logs, never raises into the
player/service path.

Credentials: the user registers a Trakt application (trakt.tv/oauth/
applications, redirect uri urn:ietf:wg:oauth:2.0:oob) and pastes its
client id + secret into settings (or the web config). The device-code
flow in trakt/auth.py turns those into access/refresh tokens.
"""
import json

import requests

from resources.lib.common import log, log_error, now_ts
from resources.lib.auth import storage

API = 'https://api.trakt.tv'
_TIMEOUT = 12

# Cache tmdb-show-id -> trakt id for the session so we don't hit /search
# on every episode. Lives only in-process (fine; it's a pure id map).
_ID_CACHE = {}


def _headers(with_auth=True):
    creds = storage.trakt_load()
    h = {
        'Content-Type': 'application/json',
        'trakt-api-version': '2',
        'trakt-api-key': creds.get('client_id') or '',
    }
    if with_auth:
        tok = get_valid_access_token()
        if tok:
            h['Authorization'] = 'Bearer ' + tok
    return h


def is_configured():
    """True when the user has supplied an app client id + secret."""
    creds = storage.trakt_load()
    return bool(creds.get('client_id') and creds.get('client_secret'))


def is_authorized():
    return storage.trakt_is_authorized()


# ---------------------------------------------------------------------------
# Token lifecycle
# ---------------------------------------------------------------------------

def get_valid_access_token():
    """Return a live access token, refreshing if it's expired. '' on failure."""
    creds = storage.trakt_load()
    if not creds.get('access_token'):
        return ''
    if creds.get('expires_at', 0) > now_ts() + 60:
        return creds['access_token']
    # Expired — refresh.
    if not (creds.get('refresh_token') and creds.get('client_id')
            and creds.get('client_secret')):
        return ''
    try:
        r = requests.post(API + '/oauth/token', json={
            'refresh_token': creds['refresh_token'],
            'client_id': creds['client_id'],
            'client_secret': creds['client_secret'],
            'redirect_uri': 'urn:ietf:wg:oauth:2.0:oob',
            'grant_type': 'refresh_token',
        }, headers={'Content-Type': 'application/json'}, timeout=_TIMEOUT)
        if r.status_code != 200:
            log_error('Trakt token refresh status {0}'.format(r.status_code))
            return ''
        tok = r.json()
        storage.trakt_save(tok.get('access_token'), tok.get('refresh_token'),
                           tok.get('expires_in'))
        return tok.get('access_token') or ''
    except Exception as e:
        log_error('Trakt token refresh failed: {0}'.format(e))
        return ''


# ---------------------------------------------------------------------------
# Low-level request helpers
# ---------------------------------------------------------------------------

def _get(path, params=None, with_auth=True):
    try:
        r = requests.get(API + path, params=params or {},
                         headers=_headers(with_auth), timeout=_TIMEOUT)
        if r.status_code == 200:
            return r.json()
        log('Trakt GET {0} -> {1}'.format(path, r.status_code))
    except Exception as e:
        log_error('Trakt GET {0} failed: {1}'.format(path, e))
    return None


def _post(path, body):
    try:
        r = requests.post(API + path, data=json.dumps(body or {}),
                          headers=_headers(True), timeout=_TIMEOUT)
        if r.status_code in (200, 201, 204):
            try:
                return r.json()
            except Exception:
                return {}
        log('Trakt POST {0} -> {1}'.format(path, r.status_code))
    except Exception as e:
        log_error('Trakt POST {0} failed: {1}'.format(path, e))
    return None


# ---------------------------------------------------------------------------
# Show id resolution (tmdb/imdb -> trakt)
# ---------------------------------------------------------------------------

def show_trakt_id(tmdb_id=None, imdb_id=None):
    """Resolve a show to an id usable in /shows/{id}.

    Trakt resolves imdb ids directly in the path, so when we have the
    SHOW's imdb id we just use it. Otherwise look the show up by tmdb id
    via /search and cache the numeric trakt id.
    """
    if imdb_id and str(imdb_id).startswith('tt'):
        return str(imdb_id)
    if not tmdb_id:
        return None
    key = str(tmdb_id)
    if key in _ID_CACHE:
        return _ID_CACHE[key]
    data = _get('/search/tmdb/{0}'.format(tmdb_id), {'type': 'show'},
                with_auth=False)
    tid = None
    if data:
        try:
            tid = data[0]['show']['ids']['trakt']
        except (KeyError, IndexError, TypeError):
            tid = None
    if tid:
        _ID_CACHE[key] = tid
    return tid


# ---------------------------------------------------------------------------
# Watched progress / next-episode awareness
# ---------------------------------------------------------------------------

def show_progress(tmdb_id=None, imdb_id=None):
    """GET watched progress for a show.

    Returns the Trakt progress dict (with 'next_episode', 'last_episode',
    'aired', 'completed', 'seasons'), or None.
    """
    sid = show_trakt_id(tmdb_id, imdb_id)
    if not sid:
        return None
    return _get('/shows/{0}/progress/watched'.format(sid),
                {'specials': 'false', 'count_specials': 'false'})


def next_unwatched(tmdb_id=None, imdb_id=None):
    """Return (season, number) of the next unwatched episode per Trakt, or None."""
    prog = show_progress(tmdb_id, imdb_id)
    if not prog:
        return None
    nxt = prog.get('next_episode')
    if not nxt:
        return None
    try:
        return int(nxt['season']), int(nxt['number'])
    except (KeyError, TypeError, ValueError):
        return None


def is_episode_watched(tmdb_id, season, episode, imdb_id=None):
    """True if Trakt has this specific episode marked watched. Best-effort."""
    prog = show_progress(tmdb_id, imdb_id)
    if not prog:
        return False
    try:
        for s in prog.get('seasons') or []:
            if int(s.get('number')) != int(season):
                continue
            for e in s.get('episodes') or []:
                if int(e.get('number')) == int(episode):
                    return bool(e.get('completed'))
    except (TypeError, ValueError):
        pass
    return False


# ---------------------------------------------------------------------------
# Marking watched / scrobbling
# ---------------------------------------------------------------------------

def _ids(tmdb_id, imdb_id):
    ids = {}
    if imdb_id and str(imdb_id).startswith('tt'):
        ids['imdb'] = str(imdb_id)
    if tmdb_id:
        try:
            ids['tmdb'] = int(tmdb_id)
        except (TypeError, ValueError):
            pass
    return ids


def _scrobble_ref(ctx):
    """Build the Trakt scrobble/sync object from a now-playing context dict.

    ctx keys: type ('movie'|'tv'), tmdb_id, imdb_id, season, episode.
    For episodes the ids are the SHOW's; for movies the movie's. Returns
    None when we lack enough to identify the item.
    """
    ids = _ids(ctx.get('tmdb_id'), ctx.get('imdb_id'))
    if not ids:
        return None
    if ctx.get('type') == 'tv':
        try:
            season = int(ctx.get('season'))
            episode = int(ctx.get('episode'))
        except (TypeError, ValueError):
            return None
        return {'show': {'ids': ids},
                'episode': {'season': season, 'number': episode}}
    return {'movie': {'ids': ids}}


def scrobble(action, ctx, progress):
    """Scrobble start/pause/stop for a movie OR episode. Best-effort.

    action in ('start','pause','stop'). Trakt auto-marks the item watched
    when a 'stop' arrives with progress >= 80%, so this is also our primary
    'mark watched' path. Returns True on success.
    """
    if not is_authorized() or action not in ('start', 'pause', 'stop'):
        return False
    ref = _scrobble_ref(ctx or {})
    if not ref:
        return False
    body = dict(ref, progress=max(0.0, min(100.0, float(progress or 0))))
    res = _post('/scrobble/' + action, body)
    if res is not None:
        log('Trakt scrobble {0} @ {1:.0f}% ({2})'.format(
            action, float(progress or 0), ctx.get('type')))
        return True
    return False


def mark_watched(ctx):
    """Explicitly add a movie/episode to history (POST /sync/history).

    Fallback for cases where a scrobble 'stop' didn't land (e.g. Kodi
    killed the player before we could send it). Idempotent-ish: Trakt
    records a watch; we only call this when playback clearly completed.
    """
    if not is_authorized():
        return False
    ref = _scrobble_ref(ctx or {})
    if not ref:
        return False
    if ctx.get('type') == 'tv':
        body = {'shows': [dict(ref['show'], seasons=[{
            'number': ref['episode']['season'],
            'episodes': [{'number': ref['episode']['number']}],
        }])]}
    else:
        body = {'movies': [ref['movie']]}
    res = _post('/sync/history', body)
    if res is not None:
        log('Trakt: marked watched via history ({0})'.format(ctx.get('type')))
        return True
    return False
