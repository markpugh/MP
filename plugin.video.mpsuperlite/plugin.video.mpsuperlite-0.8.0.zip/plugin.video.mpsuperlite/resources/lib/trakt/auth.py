# -*- coding: utf-8 -*-
"""
Trakt OAuth2 device-code flow for the MP Trakt Helper.

Reference: https://trakt.docs.apiary.io/#reference/authentication-devices

  1. POST /oauth/device/code {client_id}
        -> {device_code, user_code, verification_url, expires_in, interval}
  2. Show a QR for verification_url (https://trakt.tv/activate) and the
     user_code. The user opens it on a phone and enters the code.
  3. Poll POST /oauth/device/token {code, client_id, client_secret} every
     `interval` seconds:
        400 -> still pending
        200 -> {access_token, refresh_token, expires_in}
        404/409/410/418/429 -> expired / used / denied / slow down
  4. Save tokens.

Unlike Real Debrid, Trakt requires a REGISTERED application's client id +
secret (there's no public open-source client). The user supplies those via
settings / the web config before starting auth.
"""
import requests

import xbmcgui

from resources.lib.common import log, log_error, ADDON_NAME, set_setting
from resources.lib.auth import storage
from resources.lib.auth.dialog import show_qr_auth

API = 'https://api.trakt.tv'


def start_authorization():
    """Entry point called from default.py?action=auth_trakt."""
    creds = storage.trakt_load()
    client_id = creds.get('client_id')
    client_secret = creds.get('client_secret')
    if not (client_id and client_secret):
        xbmcgui.Dialog().ok(
            ADDON_NAME,
            'Trakt is not set up yet.\n\n'
            'Create a Trakt app at trakt.tv/oauth/applications '
            '(redirect uri: urn:ietf:wg:oauth:2.0:oob), then paste its '
            'Client ID and Client Secret into MP SuperLite settings or the '
            'MP web config, and try again.')
        return

    log('Trakt authorization starting')
    try:
        r = requests.post(API + '/oauth/device/code', json={
            'client_id': client_id,
        }, headers={'Content-Type': 'application/json'}, timeout=12)
        r.raise_for_status()
        d = r.json()
    except Exception as e:
        log_error('Trakt device/code request failed: {0}'.format(e))
        xbmcgui.Dialog().notification(ADDON_NAME, 'Trakt device-code request failed.',
                                      xbmcgui.NOTIFICATION_ERROR, 4000)
        return

    device_code = d.get('device_code')
    user_code = d.get('user_code') or ''
    verification_url = d.get('verification_url') or 'https://trakt.tv/activate'
    interval = int(d.get('interval') or 5)
    expires_in = int(d.get('expires_in') or 600)
    if not device_code:
        xbmcgui.Dialog().notification(ADDON_NAME, 'Trakt response missing device_code.',
                                      xbmcgui.NOTIFICATION_ERROR, 4000)
        return

    def poll():
        try:
            tr = requests.post(API + '/oauth/device/token', json={
                'code': device_code,
                'client_id': client_id,
                'client_secret': client_secret,
            }, headers={'Content-Type': 'application/json'}, timeout=12)
        except Exception as e:
            log_error('Trakt token poll network error: {0}'.format(e))
            return 'pending'

        if tr.status_code == 200:
            try:
                tok = tr.json()
            except Exception:
                return 'pending'
            if tok.get('access_token'):
                storage.trakt_save(tok.get('access_token'),
                                   tok.get('refresh_token'),
                                   tok.get('expires_in'))
                set_setting('trakt_status', 'Connected')
                return 'ok'
            return 'pending'
        if tr.status_code == 400:
            return 'pending'        # authorization_pending
        if tr.status_code == 429:
            return 'pending'        # slow down — the dialog paces polls anyway
        # 404 expired, 409 already used, 410 expired, 418 denied
        log_error('Trakt token poll status {0}'.format(tr.status_code))
        return 'error'

    success, err = show_qr_auth(
        title='Connect Trakt',
        url=verification_url,
        code=user_code,
        qr_data=verification_url,
        poll_fn=poll,
        expires_in=expires_in,
        poll_interval=interval,
    )
    if success:
        xbmcgui.Dialog().notification(ADDON_NAME, 'Trakt connected!',
                                      xbmcgui.NOTIFICATION_INFO, 3000)
    elif err:
        xbmcgui.Dialog().notification(ADDON_NAME, 'Trakt: ' + err,
                                      xbmcgui.NOTIFICATION_WARNING, 4000)


def clear_authorization():
    storage.trakt_clear()
    xbmcgui.Dialog().notification(ADDON_NAME, 'Trakt disconnected.',
                                  xbmcgui.NOTIFICATION_INFO, 2500)
