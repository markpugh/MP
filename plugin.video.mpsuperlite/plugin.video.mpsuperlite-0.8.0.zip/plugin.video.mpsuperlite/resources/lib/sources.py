# -*- coding: utf-8 -*-
"""
Source ranking. Takes the normalized list from scraper.scrape() and orders
it according to user preferences (quality cap, cached-only, codec preference).
"""
import re

from resources.lib.common import get_setting, get_bool, log


_QUALITY_RANK = {'4K': 4, '1080p': 3, '720p': 2, 'SD': 1}

# 3D / side-by-side / over-under release tags. These rips carry two
# squashed images and look broken on a normal 2D TV. Matched as whole
# tokens against the release title so we don't false-positive on, e.g.,
# a title that merely contains "3d".
_THREE_D_RE = re.compile(
    r'(?:^|[^a-z0-9])('
    r'3d|sbs|hsbs|h-sbs|fsbs|f-sbs|half-?sbs|full-?sbs|'
    r'ou|hou|h-ou|half-?ou|over-?under|anaglyph'
    r')(?:[^a-z0-9]|$)', re.IGNORECASE)


def is_3d(s):
    """True if the source looks like a 3D / SBS / over-under release."""
    title = s.get('release_title') or ''
    return bool(_THREE_D_RE.search(title))


# Foreign-language / dubbed-audio release tags. These rips replace the
# original (English) audio track with a single dubbed language — most
# often Ukrainian or Russian in debrid torrent results — so they play
# in a language the user can't follow. Matched as whole tokens against
# the release title (same boundary trick as _THREE_D_RE) so we don't
# false-positive on words that merely contain these letters.
#
# Deliberately EXCLUDES "multi" and "dual" tags: a MULTi / DUAL-AUDIO
# release carries several tracks (normally including English), so the
# user can just switch audio in the player — no need to drop it.
_FOREIGN_AUDIO_RE = re.compile(
    r'(?:^|[^a-z0-9])('
    r'ukrainian|ukr|'
    r'russian|rus|'
    r'italian|ita|'
    r'german|deu|ger|'
    r'french|truefrench|vostfr|vff|'
    r'spanish|castellano|latino|espanol|'
    r'hindi|tamil|telugu|punjabi|'
    r'korean|japanese|chinese|mandarin|cantonese|'
    r'polish|pldub|lektor|dublado|dublat|dublaj|'
    r'turkish|thai|vietnamese|indonesian|arabic|farsi|persian'
    r')(?:[^a-z0-9]|$)', re.IGNORECASE)


# Release-metadata anchor: the year, resolution or SxxExx that separates
# a release's TITLE from its technical tags. Language/dub tags always sit
# in the tag section AFTER this anchor, whereas a language word in the
# actual title (e.g. "The French Dispatch", "Russian Doll", "Thai Cave
# Rescue") sits before it. We only scan after the anchor so those real
# titles are never mistaken for dubs.
_ANCHOR_RE = re.compile(
    r'(?:^|[^a-z0-9])('
    r'(?:19|20)\d{2}|'                       # year
    r'(?:480|540|576|720|1080|1440|2160)p|4k|'  # resolution
    r's\d{1,2}e\d{1,3}'                       # SxxExx
    r')(?:[^a-z0-9]|$)', re.IGNORECASE)


# Markers that an English audio track is present alongside whatever dub a
# release advertises. If any of these appear in the tag region we KEEP the
# source even when a foreign tag is also there — the user can just switch
# to English in the player (now one tap via the OSD Audio button):
#   eng/english   - explicit English track
#   multi         - multiple audio tracks (normally includes English)
#   dual          - dual audio (original + one dub)
# NB: the German "DL" (Dual Language) tag also implies English, but we
# deliberately don't match a bare "dl" here because it collides with the
# ubiquitous "WEB-DL" source tag — that collision would disable the whole
# foreign filter for web releases. German DL rips are tagged GER anyway,
# and the keep-if-all fallback + audio switch cover that edge.
_ENGLISH_AUDIO_RE = re.compile(
    r'(?:^|[^a-z0-9])('
    r'eng|english|multi|dual'
    r')(?:[^a-z0-9]|$)', re.IGNORECASE)


def is_foreign_audio(s):
    """True if the release is a single non-English dub with NO English track.

    Only the technical-tag portion of the title (after the year /
    resolution / SxxExx anchor) is scanned, so a language word that is
    genuinely part of a film's name does not trip the filter. Titles
    with no recognisable anchor are treated as English (not flagged),
    since we can't tell a tag from a title word without one.

    A release that advertises a foreign dub but ALSO carries an English
    track (ENG / MULTi / DUAL / DL) is NOT flagged — it's watchable in
    English by switching the audio stream, so we keep it.
    """
    title = s.get('release_title') or ''
    m = _ANCHOR_RE.search(title)
    if not m:
        return False
    tags = title[m.end():]
    if not _FOREIGN_AUDIO_RE.search(tags):
        return False
    # Foreign tag present — but keep it if an English track is advertised too.
    if _ENGLISH_AUDIO_RE.search(tags):
        return False
    return True

# Map setting STRING values -> internal numeric cap.
# These values come from settings.xml's <option> labels — must match exactly.
_QUALITY_CAP_BY_LABEL = {
    '4K (2160p)': 4,
    '1080p': 3,
    '720p': 2,
    'Any': 99,
}

_SIZE_CAP_BY_LABEL = {
    'Unlimited': 0,
    '20 GB': 20.0,
    '15 GB': 15.0,
    '12 GB': 12.0,
    '8 GB': 8.0,
    '4 GB': 4.0,
}


def _quality_score(s):
    return _QUALITY_RANK.get(s.get('quality') or 'SD', 1)


def _has_debrid_path(source):
    """
    True if this source can plausibly resolve through a debrid service.
    A source qualifies if:
      - it has a hash or magnet URL (debrid services can check cache for it)
      - OR it's already marked as debrid-resolved by the scraper

    Direct hoster URLs (Streamtape, Doodstream, Vidoza, etc.) do NOT
    qualify even though they're HTTPS — they bypass the debrid trust
    boundary that the build is built around.
    """
    if source.get('debrid'):
        return True
    if source.get('cached'):
        # Scrapers sometimes mark cached=True for debrid hits without
        # populating the debrid field. Trust the cached flag as a
        # secondary signal.
        return True
    h = source.get('hash')
    if h and len(h) >= 32:
        # Looks like an info-hash. Debrid services can check this.
        return True
    url = (source.get('url') or '').lower()
    if url.startswith('magnet:'):
        return True
    # Anything else — direct hoster, embedded player, file URL — is not
    # going through debrid by definition.
    return False


def filter_and_rank(sources):
    """
    Returns a new list, filtered by user prefs and sorted from best to worst.
    Best == cached on a debrid > higher quality > preferred codec > preferred size.

    Size handling: we filter OUT sources above the cap, then within the
    remaining set we prefer the LARGEST (proxy for highest bitrate inside
    the same quality tier — a 1080p at 8GB is almost always a better
    encode than a 1080p at 1.4GB).

    Note (v0.5.3): the hardcoded debrid gate from v0.5.0 was reverted
    after it broke playback for sources that previously worked. The
    gate's intent was correct (drop non-debrid sources up front) but
    the field-detection heuristic mis-classified legitimate cocoscrapers
    sources as non-debrid in some cases. Defense-in-depth has been
    moved back to where it was emergent in 0.4.x: resolve_first_cached
    is the single chokepoint and only ever returns URLs that came from
    debrid try_resolve calls. The build remains debrid-only by behavior;
    we just don't try to enforce it twice.
    """
    if not sources:
        return []

    cached_only = get_bool('cached_only', False)
    quality_label = get_setting('quality_max') or '1080p'
    cap = _QUALITY_CAP_BY_LABEL.get(quality_label, 3)
    prefer_hevc = get_bool('prefer_hevc', True)
    size_label = get_setting('max_size') or 'Unlimited'
    size_cap = _SIZE_CAP_BY_LABEL.get(size_label, 0)  # 0 = unlimited

    # Filter step
    filtered = []
    dropped_oversize = 0
    for s in sources:
        if cached_only and not s.get('cached'):
            continue
        if _quality_score(s) > cap:
            continue
        # Size cap: drop anything bigger than cap. If size unknown (0), keep it.
        sg = s.get('size_gb') or 0
        if size_cap > 0 and sg > size_cap:
            dropped_oversize += 1
            continue
        filtered.append(s)

    if dropped_oversize:
        log('Dropped {0} sources over {1}GB cap'.format(dropped_oversize, size_cap))

    if not filtered and cached_only:
        log('No cached sources within filters; falling back to uncached.')
        filtered = []
        for s in sources:
            if _quality_score(s) > cap:
                continue
            sg = s.get('size_gb') or 0
            if size_cap > 0 and sg > size_cap:
                continue
            filtered.append(s)

    # Drop 3D / SBS / over-under rips — they look squashed/broken on a
    # normal 2D TV. Applied to whatever survived the quality/size/cached
    # filters above. If EVERY remaining source is 3D, keep them rather
    # than leave the user with nothing (they can still press Menu during
    # playback to cycle, or turn this setting off).
    if get_bool('skip_3d', True):
        non_3d = [s for s in filtered if not is_3d(s)]
        dropped_3d = len(filtered) - len(non_3d)
        if non_3d:
            if dropped_3d:
                log('Dropped {0} 3D/SBS sources'.format(dropped_3d))
            filtered = non_3d
        elif filtered:
            log('All remaining sources are 3D/SBS — keeping them as the only option')

    # Drop foreign-language / dubbed-audio rips (Ukrainian, Russian, etc.)
    # for the same reason as 3D: they're unwatchable for an English
    # speaker. Same keep-if-all fallback so we never leave the user with
    # zero sources. Controlled by the prefer_english setting (default on).
    if get_bool('prefer_english', True):
        english = [s for s in filtered if not is_foreign_audio(s)]
        dropped_foreign = len(filtered) - len(english)
        if english:
            if dropped_foreign:
                log('Dropped {0} foreign-dub sources'.format(dropped_foreign))
            filtered = english
        elif filtered:
            log('All remaining sources are foreign-dubbed — keeping them as the only option')

    # Sort step — multi-key, descending
    def sort_key(s):
        codec_pref = 1 if (prefer_hevc and s.get('codec') == 'h265') else 0
        return (
            0 if is_foreign_audio(s) else 1,       # English/original first
            1 if s.get('cached') else 0,           # cached first
            _quality_score(s),                     # higher quality first
            codec_pref,                            # preferred codec first
            float(s.get('size_gb') or 0),          # bigger first within quality tier
        )

    filtered.sort(key=sort_key, reverse=True)
    return filtered


def picker_label(s):
    """Human-readable line for the source-picker dialog."""
    bits = []
    bits.append(s.get('quality') or 'SD')
    if is_3d(s):
        bits.append('[COLOR red]3D/SBS[/COLOR]')
    if is_foreign_audio(s):
        bits.append('[COLOR red]DUB[/COLOR]')
    if s.get('cached'):
        bits.append('cached')
    if s.get('codec') == 'h265':
        bits.append('HEVC')
    if s.get('hdr'):
        bits.append('HDR')
    sg = s.get('size_gb') or 0
    if sg > 0:
        bits.append('{0:.1f}GB'.format(sg))
    bits.append(s.get('provider') or '?')
    return ' \u2022 '.join(bits) + '   ' + (s.get('release_title') or '')[:80]
