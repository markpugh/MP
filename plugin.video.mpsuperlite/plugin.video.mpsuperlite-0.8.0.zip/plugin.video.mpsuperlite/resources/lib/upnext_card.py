# -*- coding: utf-8 -*-
"""
MP Up Next card — a modeless WindowXMLDialog shown over the playing video
in the last stretch of an episode. It displays the next episode and a
countdown; the service (service.py) drives the countdown and decides when
to play next. This class only renders content and exposes the user's
choice via two flags.

Why modeless (show(), not doModal()): the current episode must keep
playing underneath while the card counts down. doModal would block the
service loop and steal focus/stop playback semantics.
"""
import xbmcgui

from resources.lib.common import log, ADDON_PATH

# Control ids (must match DialogMPUpNext.xml)
C_HEADER = 100
C_IMAGE = 110
C_SHOW = 120
C_TITLE = 130
C_PLOT = 140
C_COUNTDOWN = 150
C_PLAY = 6001
C_CANCEL = 6002

_TMDB_IMG = 'https://image.tmdb.org/t/p/'

ACTION_PREVIOUS_MENU = 10
ACTION_NAV_BACK = 92
ACTION_STOP = 13


def _still_url(meta):
    """Best landscape image for the card: episode still -> fanart -> poster."""
    still = meta.get('still') or meta.get('thumb')
    if still:
        return _TMDB_IMG + 'w780' + still if still.startswith('/') else still
    fan = meta.get('fanart')
    if fan:
        return _TMDB_IMG + 'w780' + fan if fan.startswith('/') else fan
    pos = meta.get('poster')
    if pos:
        return _TMDB_IMG + 'w500' + pos if pos.startswith('/') else pos
    return ''


class UpNextCard(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super(UpNextCard, self).__init__(*args)
        self._meta = kwargs.get('next_meta') or {}
        self.watch_now = False
        self.cancelled = False

    def onInit(self):  # noqa: N802 (Kodi callback)
        m = self._meta
        try:
            self.getControl(C_SHOW).setLabel(m.get('tvshowtitle') or '')
        except Exception:
            pass
        try:
            s = int(m.get('season') or 0)
            e = int(m.get('episode') or 0)
            title = m.get('title') or ''
            self.getControl(C_TITLE).setLabel(
                'S{0:02d}E{1:02d}  {2}'.format(s, e, title))
        except Exception:
            pass
        try:
            self.getControl(C_PLOT).setText(
                m.get('episode_plot') or m.get('plot') or '')
        except Exception:
            pass
        url = _still_url(m)
        if url:
            try:
                self.getControl(C_IMAGE).setImage(url)
            except Exception:
                pass

    def set_countdown(self, seconds):
        try:
            seconds = max(0, int(seconds))
            word = 'second' if seconds == 1 else 'seconds'
            self.getControl(C_COUNTDOWN).setLabel(
                'Playing next in {0} {1}'.format(seconds, word))
        except Exception:
            pass

    def onAction(self, action):  # noqa: N802
        aid = action.getId()
        if aid in (ACTION_PREVIOUS_MENU, ACTION_NAV_BACK, ACTION_STOP):
            self.cancelled = True
            self.close()

    def onClick(self, control_id):  # noqa: N802
        if control_id == C_PLAY:
            self.watch_now = True
            self.close()
        elif control_id == C_CANCEL:
            self.cancelled = True
            self.close()


def build_card(next_meta):
    """Create (but don't show) the card dialog."""
    return UpNextCard('DialogMPUpNext.xml', ADDON_PATH, 'default', '1080i',
                      next_meta=next_meta)
