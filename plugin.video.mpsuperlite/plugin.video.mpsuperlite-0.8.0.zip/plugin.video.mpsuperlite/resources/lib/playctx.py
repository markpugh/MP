# -*- coding: utf-8 -*-
"""
Play context — remembers the ranked source list for the thing currently
playing, so "next source" (Menu during playback) can try the next-best
one without re-scraping.

Stored as JSON on the Home window (id 10000), which survives across the
separate Python invocations Kodi spins up for each plugin action but is
cleared when Kodi restarts. We keep the meta, the full ranked list, and
the signatures of the sources we've already played for this item.
"""
import json

import xbmcgui

_WIN = 10000
_PROP = 'MPSuperLite.PlayCtx'


def _sig(source):
    """A stable-enough signature for a source (to mark it as tried)."""
    source = source or {}
    return (source.get('url') or source.get('hash')
            or source.get('release_title') or '')[:300]


def save(meta, ranked, played_source):
    """Store the ranked list for `meta`, with `played_source` marked tried."""
    data = {
        'meta': meta or {},
        'ranked': ranked or [],
        'played': [_sig(played_source)] if played_source else [],
    }
    _write(data)


def load():
    try:
        raw = xbmcgui.Window(_WIN).getProperty(_PROP)
        return json.loads(raw) if raw else None
    except Exception:
        return None


def remaining(data):
    """Ranked sources not yet played for this item."""
    played = set(data.get('played') or [])
    return [s for s in (data.get('ranked') or []) if _sig(s) not in played]


def mark_played(data, source):
    sig = _sig(source)
    played = data.setdefault('played', [])
    if sig and sig not in played:
        played.append(sig)
    _write(data)


def clear():
    try:
        xbmcgui.Window(_WIN).clearProperty(_PROP)
    except Exception:
        pass


def _write(data):
    try:
        xbmcgui.Window(_WIN).setProperty(_PROP, json.dumps(data))
    except Exception:
        pass
