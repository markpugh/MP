# -*- coding: utf-8 -*-
"""
"Next source" — invoked by pressing Menu during playback (via the keymap
MP Build installs). Picks the next cached source from the list we played
from, stops the current stream, and starts the new one.

Useful when the auto-picked release turns out to be unwatchable — a
side-by-side 3D rip, a wrong-audio encode, a dead cached link, etc.
"""
import xbmc
import xbmcgui

from resources.lib.common import ADDON_NAME, log
from resources.lib import playctx, player, sources
from resources.lib.debrid import resolver as debrid_resolver


def _notify(msg, icon=xbmcgui.NOTIFICATION_INFO, ms=3500):
    try:
        xbmcgui.Dialog().notification(ADDON_NAME, msg, icon, ms)
    except Exception:
        pass


def play_next():
    data = playctx.load()
    if not data:
        _notify('Start something first, then press Menu to change source.')
        return

    rem = playctx.remaining(data)
    if not rem:
        _notify('No more sources to try for this title.',
                xbmcgui.NOTIFICATION_WARNING)
        return

    meta = data.get('meta') or {}
    log('next_source: {0} candidate(s) left to try'.format(len(rem)))

    progress = xbmcgui.DialogProgressBG()
    result = None
    try:
        progress.create(ADDON_NAME, 'Finding next source...')

        def cb(msg):
            try:
                progress.update(50, ADDON_NAME, msg or '')
            except Exception:
                pass

        result = debrid_resolver.resolve_first_cached(rem, progress_cb=cb,
                                                      meta=meta)
    finally:
        try:
            progress.close()
        except Exception:
            pass

    if not result:
        _notify('No other cached source is available right now.',
                xbmcgui.NOTIFICATION_WARNING, 4000)
        return

    src = result.get('source') or {}
    playctx.mark_played(data, src)

    # Stop the current stream before starting the replacement.
    try:
        if xbmc.Player().isPlaying():
            xbmc.Player().stop()
            xbmc.sleep(700)
    except Exception:
        pass

    tag = ' '.join(x for x in [
        src.get('quality') or '',
        '3D/SBS' if sources.is_3d(src) else '',
        (src.get('release_title') or '')[:50],
    ] if x).strip()
    player.play(meta, result['url'])
    _notify('Next source: ' + tag)
