# -*- coding: utf-8 -*-
"""
MP SuperLite — playback service: MP Trakt Helper + Up Next card.

Two jobs, both driven by one persistent xbmc.Player monitor so there's a
single source of truth for "what's playing":

  1. MP Trakt Helper (scrobbling). Every movie or episode played through
     SuperLite is scrobbled to Trakt directly — start on playback, pause/
     resume on those events, stop (with real progress) when it ends. Trakt
     auto-marks watched at >=80%. This does NOT rely on TMDb Helper, so
     content that never touches TMDb Helper (e.g. SuperSearch movies) is
     still recorded. The now-playing context is published by _play() right
     before it resolves, because the resolved stream URL carries no TMDB
     context of its own.

  2. Up Next card (episodes only). In the last stretch of an episode we
     show our own MP-themed card counting down to the next episode, and
     auto-play it (unless cancelled). The next episode's stream is
     pre-resolved in the background for instant playback.

Everything here is best-effort: a Trakt/network/card failure degrades to
"not recorded" or "no card", never to broken playback.
"""
import json
import threading

import xbmc
import xbmcgui

from resources.lib.common import log, log_error, get_bool, get_int

_WIN = xbmcgui.Window(10000)
_NOWPLAYING_PROP = 'mpsuperlite.nowplaying'


def read_nowplaying():
    try:
        raw = _WIN.getProperty(_NOWPLAYING_PROP)
        if not raw:
            return None
        return json.loads(raw)
    except Exception:
        return None


def publish_nowplaying(tmdb_type, tmdb_id, imdb_id='', season=None,
                       episode=None):
    """Called by _play just before resolving, for movies AND episodes, so
    the service knows exactly what's about to start (the stream URL itself
    has no TMDB/Trakt context)."""
    try:
        ctx = {
            'type': 'tv' if tmdb_type == 'tv' else 'movie',
            'tmdb_id': str(tmdb_id) if tmdb_id else '',
            'imdb_id': imdb_id or '',
        }
        if ctx['type'] == 'tv':
            ctx['season'] = int(season)
            ctx['episode'] = int(episode)
        _WIN.setProperty(_NOWPLAYING_PROP, json.dumps(ctx))
    except Exception as e:
        log('publish_nowplaying failed: {0}'.format(e))


def clear_nowplaying():
    try:
        _WIN.clearProperty(_NOWPLAYING_PROP)
    except Exception:
        pass


class SuperLitePlayer(xbmc.Player):
    """Watches playback to scrobble to Trakt and drive the Up Next card."""

    def __init__(self):
        super(SuperLitePlayer, self).__init__()
        self._ctx = None             # current now-playing context
        self._last_progress = 0.0    # last known progress %, kept fresh by _track
        self._track_thread = None
        self._stop_track = threading.Event()
        self._finalized = False

    # ---- Kodi player callbacks --------------------------------------------

    def onAVStarted(self):  # noqa: N802
        try:
            self._handle_start()
        except Exception as e:
            log_error('onAVStarted error: {0}'.format(e))

    def onPlayBackPaused(self):  # noqa: N802
        self._scrobble('pause')

    def onPlayBackResumed(self):  # noqa: N802
        self._scrobble('start')

    def onPlayBackStopped(self):  # noqa: N802
        self._finalize()

    def onPlayBackEnded(self):  # noqa: N802
        self._finalize()

    def onPlayBackError(self):  # noqa: N802
        self._finalize()

    # ---- start ------------------------------------------------------------

    def _handle_start(self):
        ctx = read_nowplaying()
        if not ctx:
            # Not a SuperLite playback — stop tracking anything previous.
            self._teardown()
            return

        # New item: consume the context so a later non-SuperLite playback
        # doesn't re-trigger against stale data.
        clear_nowplaying()
        self._teardown()
        self._ctx = ctx
        self._finalized = False
        self._last_progress = self._progress()

        # 1. Scrobble start (MP Trakt Helper) — for movies AND episodes.
        self._scrobble('start')

        # 2. Up Next card tracking (episodes only).
        self._stop_track.clear()
        next_meta = None
        if ctx['type'] == 'tv' and get_bool('upnext_enabled', True):
            next_meta = self._lookup_next(ctx)
            if next_meta:
                self._preresolve_async(ctx, next_meta)
        # Always run the tracker: it keeps _last_progress fresh (needed for
        # an accurate stop scrobble) even when there's no card to show.
        self._track_thread = threading.Thread(
            target=self._track, args=(dict(ctx), next_meta),
            name='mpsl-track')
        self._track_thread.daemon = True
        self._track_thread.start()

    # ---- scrobble helpers -------------------------------------------------

    def _progress(self):
        try:
            total = self.getTotalTime()
            cur = self.getTime()
            if total and total > 0:
                return max(0.0, min(100.0, cur / total * 100.0))
        except Exception:
            pass
        return self._last_progress

    def _scrobble(self, action):
        if not self._ctx or not get_bool('trakt_scrobble', True):
            return
        try:
            from resources.lib.trakt import client as trakt
            if not trakt.is_authorized():
                return
            trakt.scrobble(action, self._ctx, self._progress())
        except Exception as e:
            log('scrobble {0} failed: {1}'.format(action, e))

    def _finalize(self):
        if not self._ctx or self._finalized:
            return
        self._finalized = True
        ctx = self._ctx
        progress = self._last_progress or self._progress()
        self._stop_track.set()
        try:
            from resources.lib.trakt import client as trakt
            if get_bool('trakt_scrobble', True) and trakt.is_authorized():
                ok = trakt.scrobble('stop', ctx, progress)
                # Belt-and-braces: if the stop call failed but the item was
                # effectively finished, mark it watched via history so Trakt
                # never misses a completed play.
                if not ok and progress >= 80.0:
                    trakt.mark_watched(ctx)
        except Exception as e:
            log('finalize scrobble failed: {0}'.format(e))
        self._ctx = None

    def _teardown(self):
        """Stop any running tracker thread + clear transient state."""
        self._stop_track.set()
        t = self._track_thread
        if t and t.is_alive() and t is not threading.current_thread():
            t.join(timeout=1.0)
        self._track_thread = None

    # ---- next-episode lookup + pre-resolve --------------------------------

    def _lookup_next(self, ctx):
        try:
            from resources.lib import upnext
            return upnext.next_episode(ctx['tmdb_id'], ctx['season'],
                                       ctx['episode'])
        except Exception as e:
            log('next-episode lookup failed: {0}'.format(e))
            return None

    def _preresolve_async(self, ctx, next_meta):
        def worker():
            try:
                from resources.lib import pipeline, upnext
                result = pipeline.resolve_stream(next_meta, progress_cb=None)
                if result and result.get('url'):
                    upnext.stash_put(ctx['tmdb_id'], next_meta['season'],
                                     next_meta['episode'], result['url'])
            except Exception as e:
                log('pre-resolve crashed: {0}'.format(e))
        th = threading.Thread(target=worker, name='mpsl-preresolve')
        th.daemon = True
        th.start()

    # ---- tracking loop (progress + card) ----------------------------------

    def _track(self, ctx, next_meta):
        from resources.lib import upnext_card
        monitor = xbmc.Monitor()
        card = None
        card_cancelled = False
        card_seconds = get_int('upnext_seconds', 30) or 30

        while not monitor.abortRequested() and not self._stop_track.is_set():
            if not self.isPlaying():
                break
            try:
                total = self.getTotalTime()
                cur = self.getTime()
            except Exception:
                break
            if total and total > 0:
                self._last_progress = max(0.0, min(100.0, cur / total * 100.0))
                remaining = total - cur

                if (next_meta and card is None and not card_cancelled
                        and 0 < remaining <= card_seconds):
                    try:
                        card = upnext_card.build_card(next_meta)
                        card.show()
                        log('Up Next card shown ({0:.0f}s left)'.format(remaining))
                    except Exception as e:
                        log('card show failed: {0}'.format(e))
                        card = None
                        next_meta = None  # don't retry

                if card is not None:
                    if card.watch_now:
                        self._close_card(card)
                        self._play_next(ctx, next_meta)
                        return
                    if card.cancelled:
                        self._close_card(card)
                        card = None
                        card_cancelled = True
                    else:
                        card.set_countdown(remaining)
                        if remaining <= 1:
                            self._close_card(card)
                            self._play_next(ctx, next_meta)
                            return
            if monitor.waitForAbort(0.5):
                break

        # Playback ended / loop exited. If the card was up and the user
        # didn't cancel, roll into the next episode.
        if card is not None and not card_cancelled and next_meta:
            self._close_card(card)
            self._play_next(ctx, next_meta)
        else:
            self._close_card(card)

    def _close_card(self, card):
        if card is None:
            return
        try:
            card.close()
        except Exception:
            pass

    def _play_next(self, ctx, next_meta):
        try:
            from resources.lib import upnext
            url = upnext.build_play_url(ctx['tmdb_id'], next_meta)
            log('Up Next: launching next episode')
            xbmc.executebuiltin('PlayMedia({0})'.format(url))
        except Exception as e:
            log_error('play_next failed: {0}'.format(e))


def main():
    log('MP playback service (Trakt Helper + Up Next) starting')
    monitor = xbmc.Monitor()
    player = SuperLitePlayer()  # noqa: F841 — kept alive by the loop
    while not monitor.abortRequested():
        if monitor.waitForAbort(2):
            break
    try:
        player._teardown()
    except Exception:
        pass
    log('MP playback service stopped')


if __name__ == '__main__':
    main()
