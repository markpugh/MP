# -*- coding: utf-8 -*-
"""
MP SuperLite — entry point.

Routes:
  ?action=play&tmdb_type=movie&tmdb_id=X
  ?action=play&tmdb_type=tv&tmdb_id=X&season=S&episode=E
  ?action=auth_rd            -> open Real Debrid QR auth dialog
  ?action=auth_rd_clear      -> wipe stored RD tokens
  ?action=auth_ad            -> open AllDebrid QR auth dialog
  ?action=auth_ad_clear      -> wipe stored AD tokens
  (no params)                -> directory listing with auth shortcuts
"""
import sys
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

ADDON = xbmcaddon.Addon('plugin.video.mpsuperlite')
ADDON_PATH = ADDON.getAddonInfo('path')
sys.path.insert(0, ADDON_PATH)


def _parse_args():
    if len(sys.argv) < 3:
        return {}
    qs = sys.argv[2]
    if qs.startswith('?'):
        qs = qs[1:]
    return urllib.parse.parse_qs(qs, keep_blank_values=True)


def _arg(args, key, default=''):
    v = args.get(key)
    if not v:
        return default
    return v[0] if isinstance(v, list) else v


def _handle():
    if len(sys.argv) < 2:
        return -1
    try:
        return int(sys.argv[1])
    except (ValueError, TypeError):
        return -1


def _ensure_keymap():
    """
    Remove any previously-installed MP SuperLite keymap. "Next source" is
    now reached from a Next Source button in the player OSD (provided by the
    MP skin), so we no longer hijack the Menu/Context-menu button — earlier
    builds (<=0.7.1) installed a keymap that did. Cleans that up on play.
    """
    import os
    import xbmcvfs
    try:
        dst = os.path.join(
            xbmcvfs.translatePath('special://profile/keymaps/'),
            'mpsuperlite.xml')
        if os.path.isfile(dst):
            os.remove(dst)
            xbmc.executebuiltin('Action(reloadkeymaps)')
    except Exception as e:
        try:
            from resources.lib.common import log
            log('keymap cleanup failed: {0}'.format(e))
        except Exception:
            pass


def _play(args):
    """Orchestrate the play pipeline: TMDB -> scrape -> rank -> debrid resolve -> play."""
    from resources.lib import tmdb, scraper, sources, player
    from resources.lib.debrid import resolver as debrid_resolver
    from resources.lib.debrid import rd_client, ad_client
    from resources.lib.common import log, log_error, get_bool, ADDON_NAME

    # Make sure the "Menu = next source" keymap is in place.
    _ensure_keymap()

    tmdb_type = _arg(args, 'tmdb_type', 'movie')
    tmdb_id = _arg(args, 'tmdb_id')
    imdb_id = _arg(args, 'imdb_id')

    # Sanity: TMDb Helper sometimes passes the EPISODE's tmdb id when
    # we wanted the SHOW's. Easiest unambiguous bridge is IMDB id —
    # the player JSON now passes imdb_id (which TMDb Helper resolves
    # to the show's IMDB id, not the episode's). When imdb_id is
    # present, prefer it: look up the show's tmdb id via TMDB's /find
    # endpoint, then proceed.
    if not tmdb_id and not imdb_id:
        xbmcgui.Dialog().ok(ADDON_NAME, 'No tmdb_id or imdb_id provided.')
        return

    if imdb_id and (not tmdb_id or _arg(args, 'force_imdb') == '1'):
        from resources.lib import tmdb as _tmdb_mod
        resolved = _tmdb_mod.find_by_imdb(imdb_id, tmdb_type=tmdb_type)
        if resolved:
            tmdb_id = str(resolved)
        elif not tmdb_id:
            xbmcgui.Dialog().notification(
                ADDON_NAME, 'IMDB->TMDB lookup failed.',
                xbmcgui.NOTIFICATION_ERROR, 3000)
            return

    # Step 1: TMDB metadata
    if tmdb_type == 'tv':
        season = _arg(args, 'season')
        episode = _arg(args, 'episode')
        if not season or not episode:
            xbmcgui.Dialog().ok(ADDON_NAME,
                                'TV playback requires season and episode.')
            return
        meta = tmdb.get_episode(tmdb_id, season, episode)
    else:
        meta = tmdb.get_movie(tmdb_id)

    if not meta:
        xbmcgui.Dialog().notification(
            ADDON_NAME, 'TMDB lookup failed.',
            xbmcgui.NOTIFICATION_ERROR, 3000)
        return

    if not meta.get('imdb'):
        log_error('No IMDB id in TMDB response — scraping will likely fail.')

    # Publish now-playing context so the playback service can scrobble this
    # to Trakt and (for episodes) drive the Up Next card on playback start —
    # the resolved stream URL carries no TMDB/Trakt context of its own. We
    # publish for movies too, so Trakt records everything we watch, not just
    # episodes. For TV we deliberately pass no imdb id: meta.imdb is the
    # EPISODE's imdb, but Trakt scrobbles episodes by the SHOW's ids, so we
    # rely on the show's tmdb id (the tmdb_id variable here).
    # NOTE: service.py lives at the ADDON ROOT (it's the xbmc.service entry),
    # not under resources/lib — so it's imported as a top-level module. The
    # old "from resources.lib import service" raised ImportError that this
    # try/except swallowed, so the context was never published and neither
    # the Up Next card nor Trakt scrobbling ever fired. Log failures now.
    try:
        import service as _svc
        if tmdb_type == 'tv':
            _svc.publish_nowplaying('tv', tmdb_id, '', season, episode)
        else:
            _svc.publish_nowplaying('movie', tmdb_id, meta.get('imdb') or '')
        log('Published now-playing context for the service ({0})'.format(tmdb_type))
    except Exception as e:
        log_error('publish_nowplaying failed: {0}'.format(e))

    # Up Next fast path: if this play was launched by the Up Next card
    # (upnext=1) and the service pre-resolved this exact episode, play the
    # stashed URL instantly — skip scrape + debrid entirely. A miss falls
    # straight through to the normal live-resolve path below.
    if tmdb_type == 'tv' and _arg(args, 'upnext') == '1':
        try:
            from resources.lib import upnext as _un
            stashed = _un.stash_take(tmdb_id, season, episode)
        except Exception:
            stashed = None
        if stashed:
            from resources.lib import player
            log('Up Next: playing pre-resolved stash for S{0}E{1}'.format(
                season, episode))
            handle = _handle()
            if handle >= 0:
                return player.play_resolved(meta, stashed, handle)
            return player.play(meta, stashed)

    # Check we have at least one debrid configured before scraping
    have_rd = rd_client.is_authorized()
    have_ad = ad_client.is_authorized()
    if not (have_rd or have_ad):
        choice = xbmcgui.Dialog().yesno(
            ADDON_NAME,
            'No debrid service is authorized. Real Debrid or AllDebrid '
            'is required for playback. Open settings now to authorize?',
            yeslabel='Open Settings', nolabel='Cancel')
        if choice:
            ADDON.openSettings()
        return

    # Step 2: scrape with progress dialog
    progress = xbmcgui.DialogProgressBG()
    try:
        progress.create(ADDON_NAME, 'Searching sources...')
        def cb(pct, msg=''):
            try:
                progress.update(int(pct), ADDON_NAME, msg or '')
            except Exception:
                pass
        raw_sources = scraper.scrape(meta, progress_cb=cb)
    finally:
        try:
            progress.close()
        except Exception:
            pass

    if not raw_sources:
        xbmcgui.Dialog().notification(
            ADDON_NAME, 'No sources found.',
            xbmcgui.NOTIFICATION_INFO, 3000)
        return

    # Step 3: rank (file-size cap, quality cap, codec preference)
    ranked = sources.filter_and_rank(raw_sources)
    if not ranked:
        xbmcgui.Dialog().notification(
            ADDON_NAME, 'No sources match your filters.',
            xbmcgui.NOTIFICATION_INFO, 3000)
        return

    log('Ranked {0} candidates after filters'.format(len(ranked)))

    # Step 4: pick mode (auto-play top vs. picker). The caller can force
    # the manual picker with pick=1 (e.g. the "Select Source" context
    # menu item) regardless of the auto_play setting.
    force_pick = _arg(args, 'pick') == '1'
    if get_bool('auto_play', True) and not force_pick:
        candidates = ranked
        log('Auto-play enabled — will try top candidates against debrid')
    else:
        labels = [sources.picker_label(s) for s in ranked[:50]]
        idx = xbmcgui.Dialog().select('Pick a source', labels)
        if idx < 0:
            return
        candidates = [ranked[idx]]

    # Step 5: debrid retry loop with progress dialog
    progress = xbmcgui.DialogProgressBG()
    try:
        progress.create(ADDON_NAME, 'Resolving via debrid...')
        def debrid_cb(msg):
            try:
                progress.update(50, ADDON_NAME, msg)
            except Exception:
                pass
        result = debrid_resolver.resolve_first_cached(
            candidates, progress_cb=debrid_cb, meta=meta)
    finally:
        try:
            progress.close()
        except Exception:
            pass

    if not result:
        xbmcgui.Dialog().notification(
            ADDON_NAME, 'No cached sources available.',
            xbmcgui.NOTIFICATION_WARNING, 4000)
        return

    # Remember the ranked list so "next source" (Menu during playback) can
    # try the next-best option without re-scraping.
    try:
        from resources.lib import playctx
        playctx.save(meta, ranked, result['source'])
    except Exception:
        pass

    log('Playing: {0} via {1}'.format(
        result['source'].get('release_title', '?')[:60], result['service']))

    # Step 6: play
    # Prefer setResolvedUrl when invoked via plugin handle. This lets
    # Kodi take over the playback pipeline including watch state, resume
    # points, and Trakt scrobbling via TMDb Helper's hooks. Falls back
    # to xbmc.Player().play() only when there's no handle (rare —
    # invoked directly from a non-plugin path).
    handle = _handle()
    if handle >= 0:
        ok = player.play_resolved(meta, result['url'], handle)
        return ok
    else:
        ok = player.play(meta, result['url'])
        # No plugin handle to resolve, so caller doesn't need to know
        # whether endOfDirectory should fire — there's no directory.
        return True


def _root_dir(handle):
    """Show a small menu when the addon is opened directly."""
    from resources.lib.common import ADDON_NAME, get_setting
    items = []

    rd_status = get_setting('rd_status', 'Not connected')
    items.append((
        'plugin://plugin.video.mpsuperlite/?action=auth_rd',
        xbmcgui.ListItem(label='[B]Real Debrid:[/B] ' + rd_status),
        False,
    ))
    ad_status = get_setting('ad_status', 'Not connected')
    items.append((
        'plugin://plugin.video.mpsuperlite/?action=auth_ad',
        xbmcgui.ListItem(label='[B]AllDebrid:[/B] ' + ad_status),
        False,
    ))
    items.append((
        'plugin://plugin.video.mpsuperlite/?action=settings',
        xbmcgui.ListItem(label='Settings'),
        False,
    ))
    xbmcplugin.addDirectoryItems(handle, items, len(items))
    xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)


def main():
    args = _parse_args()
    action = _arg(args, 'action')
    handle = _handle()

    if action == 'play':
        # _play() returns True if it called setResolvedUrl successfully.
        # In that case Kodi already has the playback URL — DON'T call
        # endOfDirectory after, since endOfDirectory(succeeded=False)
        # invalidates the resolved URL and silently kills playback.
        # Only fall through to endOfDirectory(False) if _play bailed
        # without resolving (scrape failed, no debrid hit, etc.) so
        # Kodi gets a clean "no result" signal instead of hanging.
        resolved_ok = _play(args)
        if handle >= 0 and not resolved_ok:
            try:
                xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)
            except Exception:
                pass
        return

    if action == 'auth_rd':
        from resources.lib.auth import rd
        rd.start_authorization()
        return

    if action == 'auth_rd_clear':
        from resources.lib.auth import rd
        rd.clear_authorization()
        return

    if action == 'auth_ad':
        from resources.lib.auth import ad
        ad.start_authorization()
        return

    if action == 'auth_ad_clear':
        from resources.lib.auth import ad
        ad.clear_authorization()
        return

    if action == 'auth_trakt':
        from resources.lib.trakt import auth as trakt_auth
        trakt_auth.start_authorization()
        return

    if action == 'auth_trakt_clear':
        from resources.lib.trakt import auth as trakt_auth
        trakt_auth.clear_authorization()
        return

    if action == 'next_source':
        # Fired by the Menu key during playback (via the installed keymap).
        from resources.lib import nextsource
        nextsource.play_next()
        return

    if action == 'settings':
        ADDON.openSettings()
        if handle >= 0:
            try:
                xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)
            except Exception:
                pass
        return

    # Default: show small directory listing
    if handle >= 0:
        _root_dir(handle)


if __name__ == '__main__':
    main()
