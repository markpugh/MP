# -*- coding: utf-8 -*-
"""
Launch the results listing.

state.to_discover_url() now produces a URL that points back at our own
plugin with action=results. Container.Update navigates Kodi into that
listing, where results.py will render the items.
"""
import xbmc


def launch_results(plugin_url):
    xbmc.executebuiltin('Container.Update({0})'.format(plugin_url))
    # After Container.Update, force focus to the first item. Without this,
    # Arctic Horizon (and apparently some default views) can land the
    # cursor at the bottom of the list instead of the top — likely because
    # the modal dialog's last-focused control influences the new container.
    # 200ms is enough for the directory to populate.
    xbmc.sleep(200)
    xbmc.executebuiltin('Action(FirstPage)')
