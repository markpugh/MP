# -*- coding: utf-8 -*-
"""
Render TMDB Discover results as a Kodi directory listing.

Why this exists: TMDB Helper's discover route doesn't support most of the
filter params we offer (with_keywords, with_watch_providers, watch_region,
date ranges, etc.). So we hit TMDB's Discover endpoint directly, then hand
each result's onClick off to TMDB Helper's per-item info/play route, which
IS well-supported.
"""
import urllib.parse

import xbmc
import xbmcgui
import xbmcplugin

from resources.lib.tmdb import TMDB

# TMDB Discover params we forward (must start with one of these prefixes
# or be in the explicit allowlist).
ALLOWED_PREFIXES = ('with_', 'without_', 'vote_', 'primary_release_',
                    'release_', 'first_air_', 'air_')
ALLOWED_KEYS = {'sort_by', 'watch_region', 'include_adult',
                'with_original_language'}
# Title search query — handled separately from Discover params but should
# survive pagination so "Next page" with a title still title-searches.
PASSTHROUGH_KEYS = {'title_query', 'tmdb_type', 'action'}

# TMDB image base + size
POSTER_BASE = 'https://image.tmdb.org/t/p/w500'
FANART_BASE = 'https://image.tmdb.org/t/p/w1280'

# TMDB Discover hard-caps page at 500
TMDB_MAX_PAGE = 500


def _filter_params(qs):
    """Pick out only the TMDB Discover params from the parsed query string."""
    out = {}
    for k, v in qs.items():
        if not v:
            continue
        if k in ALLOWED_KEYS or any(k.startswith(p) for p in ALLOWED_PREFIXES):
            out[k] = v[0] if isinstance(v, list) else v
    return out


def _build_page_url(query_args, page):
    """Rebuild the plugin URL with a different page param, preserving filters."""
    new_args = {}
    for k, v in query_args.items():
        if k == 'page':
            continue
        new_args[k] = v[0] if isinstance(v, list) else v
    new_args['action'] = 'results'
    new_args['page'] = str(page)
    return 'plugin://plugin.video.mpsupersearch/?' + urllib.parse.urlencode(new_args)


def _matches_filters(item, discover_params, tmdb_type):
    """
    Apply Discover-style filters to a single TMDB search result, in-memory.
    Used for the title-search path where TMDB's /search/movie endpoint
    doesn't accept genre/network/etc. filters — we run them client-side.

    item: a TMDB search result dict
    discover_params: the Discover-style filters from state.to_discover_url()
    tmdb_type: 'movie' or 'tv'

    Returns True if the item passes ALL applied filters.
    """
    # Genre filter (with_genres is comma-separated, AND semantics)
    wg = discover_params.get('with_genres')
    if wg:
        item_genres = set(str(g) for g in (item.get('genre_ids') or []))
        wanted = set(g.strip() for g in wg.split(',') if g.strip())
        if wanted and not wanted.issubset(item_genres):
            return False

    # Year range (date.gte / date.lte)
    date_field = 'primary_release_date' if tmdb_type == 'movie' else 'first_air_date'
    item_date = (item.get('release_date') or item.get('first_air_date') or '')
    item_year = item_date[:4] if len(item_date) >= 4 and item_date[:4].isdigit() else None
    gte = discover_params.get('{0}.gte'.format(date_field))
    lte = discover_params.get('{0}.lte'.format(date_field))
    if gte and item_year and item_year < gte[:4]:
        return False
    if lte and item_year and item_year > lte[:4]:
        return False

    # Rating threshold
    vote_min = discover_params.get('vote_average.gte')
    if vote_min:
        try:
            if float(item.get('vote_average') or 0) < float(vote_min):
                return False
        except (ValueError, TypeError):
            pass

    # Language
    lang = discover_params.get('with_original_language')
    if lang:
        wanted_langs = set(l.strip() for l in lang.split('|') if l.strip())
        if wanted_langs and item.get('original_language') not in wanted_langs:
            return False

    # Note: with_keywords and with_watch_providers can't be filtered
    # client-side from a search result alone (would need a per-item
    # detail call which is too expensive). Those filters are silently
    # ignored on the title-search path. Users who need keyword/network
    # precision should use filter-only Discover (no title).

    return True


def render(handle, query_args):
    """
    handle: int from sys.argv[1]
    query_args: dict from urllib.parse.parse_qs(sys.argv[2][1:])
    """
    tmdb_type = (query_args.get('tmdb_type') or ['movie'])[0]
    if tmdb_type not in ('movie', 'tv'):
        tmdb_type = 'movie'

    # Pagination: which page of results does the user want?
    try:
        page = int((query_args.get('page') or ['1'])[0])
    except (ValueError, TypeError):
        page = 1
    if page < 1:
        page = 1
    if page > TMDB_MAX_PAGE:
        page = TMDB_MAX_PAGE

    # Title search: if title_query is present, switch to TMDB /search/<type>
    # and apply remaining filters client-side. Otherwise use Discover.
    title_query = (query_args.get('title_query') or [''])[0].strip()

    discover_params = _filter_params(query_args)

    tmdb = TMDB()

    if title_query:
        xbmc.log('[mpsupersearch] Title search: "{0}" type={1} page={2}'.format(
            title_query, tmdb_type, page), xbmc.LOGINFO)
        data = tmdb.search_titles(title_query, tmdb_type=tmdb_type, page=page)

        if data and discover_params:
            # Client-side filter the results
            original = data.get('results') or []
            filtered = [r for r in original
                        if _matches_filters(r, discover_params, tmdb_type)]
            xbmc.log('[mpsupersearch] Title search: filtered {0}/{1} '
                     'after applying client-side filters'.format(
                         len(filtered), len(original)), xbmc.LOGINFO)
            data['results'] = filtered
            # NOTE: total_pages/total_results from TMDB still reflect
            # the unfiltered count. We don't try to "fix" them — the
            # next-page button will still work, and per-page filtering
            # gives the user a sensible browsing experience.
    else:
        xbmc.log('[mpsupersearch] Discover: tmdb_type={0} page={1} params={2}'.format(
            tmdb_type, page, discover_params), xbmc.LOGINFO)
        data = tmdb.discover(tmdb_type, discover_params, page=page)

    if not data or not data.get('results'):
        xbmcgui.Dialog().notification(
            'SuperSearch',
            'No results returned from TMDB.',
            xbmcgui.NOTIFICATION_INFO, 3000)
        xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)
        return

    total_pages = min(int(data.get('total_pages') or 1), TMDB_MAX_PAGE)
    total_results = int(data.get('total_results') or 0)

    # Breadcrumb: "Page 1 of 47  •  938 results"
    try:
        xbmcplugin.setPluginCategory(
            handle,
            'Page {0} of {1}  \u2022  {2} results'.format(
                page, total_pages, total_results)
        )
    except Exception:
        pass

    items = []
    for r in data['results']:
        title = r.get('title') or r.get('name') or 'Untitled'
        tmdb_id = r.get('id')
        if not tmdb_id:
            continue

        date = r.get('release_date') or r.get('first_air_date') or ''
        year = None
        if date and len(date) >= 4 and date[:4].isdigit():
            year = int(date[:4])

        poster = (POSTER_BASE + r['poster_path']) if r.get('poster_path') else ''
        fanart = (FANART_BASE + r['backdrop_path']) if r.get('backdrop_path') else ''

        # Hand off to MP SuperLite (our own player addon). For movies we
        # invoke its play route directly; SuperLite's pipeline handles
        # scraping, ranking, debrid resolution, and Player.play. For TV
        # shows we still use TMDB Helper's seasons browser to pick an
        # episode (until SuperLite v0.2 grows its own seasons UI), at
        # which point each individual episode link points at SuperLite.
        if tmdb_type == 'movie':
            target_url = (
                'plugin://plugin.video.mpsuperlite/?'
                'action=play&tmdb_type=movie&tmdb_id={0}'.format(tmdb_id)
            )
            is_folder = False
        else:
            target_url = (
                'plugin://plugin.video.themoviedb.helper/?'
                'info=seasons&tmdb_type=tv&tmdb_id={0}'.format(tmdb_id)
            )
            is_folder = True

        li = xbmcgui.ListItem(label=title)
        if poster:
            li.setArt({'thumb': poster, 'poster': poster, 'icon': poster,
                       'fanart': fanart or poster})

        # Set video info (works on Kodi 19/20/21)
        info = {
            'title': title,
            'plot': r.get('overview') or '',
            'mediatype': 'movie' if tmdb_type == 'movie' else 'tvshow',
        }
        if year:
            info['year'] = year
        if r.get('vote_average'):
            info['rating'] = float(r['vote_average'])
        if r.get('vote_count'):
            info['votes'] = str(r['vote_count'])
        try:
            li.setInfo('video', info)
        except Exception:
            pass

        items.append((target_url, li, is_folder))

    # Append "Next page" entry if there's more to show
    if page < total_pages:
        next_url = _build_page_url(query_args, page + 1)
        next_li = xbmcgui.ListItem(
            label='[B][COLOR FF0078D4]\u2192 Next page[/COLOR][/B]   '
                  '({0} of {1})'.format(page + 1, total_pages)
        )
        try:
            next_li.setInfo('video', {
                'title': 'Next page',
                'plot': 'Show page {0} of {1} ({2} total results).'.format(
                    page + 1, total_pages, total_results),
            })
        except Exception:
            pass
        items.append((next_url, next_li, True))  # folder

    xbmcplugin.setContent(handle, 'movies' if tmdb_type == 'movie' else 'tvshows')
    xbmcplugin.addDirectoryItems(handle, items, len(items))
    xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)


def parse_query_string(qs):
    """Parse a Kodi plugin query string (starts with '?') into a dict."""
    if qs and qs.startswith('?'):
        qs = qs[1:]
    return urllib.parse.parse_qs(qs, keep_blank_values=True)
