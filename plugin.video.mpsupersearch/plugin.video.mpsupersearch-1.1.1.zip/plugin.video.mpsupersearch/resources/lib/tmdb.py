# -*- coding: utf-8 -*-
"""
TMDB API wrapper. Returns option lists for each filter kind.
Caches expensive endpoints (genres, providers, languages) for 24h on disk.
"""
import json
import os
import time
import urllib.parse

import xbmc
import xbmcaddon
import xbmcvfs

try:
    import requests
except ImportError:
    raise

ADDON = xbmcaddon.Addon()
TMDB_BASE = 'https://api.themoviedb.org/3'
TMDB_LOGO = 'https://image.tmdb.org/t/p/w154'
CACHE_TTL = 24 * 60 * 60  # 24h


def _translate_path(p):
    # xbmcvfs.translatePath in Kodi 19+, xbmc.translatePath in older
    if hasattr(xbmcvfs, 'translatePath'):
        return xbmcvfs.translatePath(p)
    return xbmc.translatePath(p)


class TMDB:
    def __init__(self):
        self.api_key = ADDON.getSetting('tmdb_api_key').strip()
        self.region = (ADDON.getSetting('watch_region') or 'US').strip().upper()
        self.lang = (ADDON.getSetting('language') or 'en-US').strip()
        self._cache_dir = _translate_path(
            'special://profile/addon_data/{0}/cache/'.format(ADDON.getAddonInfo('id'))
        )
        if not os.path.isdir(self._cache_dir):
            os.makedirs(self._cache_dir, exist_ok=True)

    # --- cache ------------------------------------------------------------

    def _cache_path(self, key):
        safe = ''.join(c if c.isalnum() else '_' for c in key)
        return os.path.join(self._cache_dir, safe + '.json')

    def _cache_get(self, key):
        path = self._cache_path(key)
        if not os.path.exists(path):
            return None
        try:
            with open(path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            if time.time() - data.get('_ts', 0) > CACHE_TTL:
                return None
            return data.get('payload')
        except Exception:
            return None

    def _cache_set(self, key, payload):
        path = self._cache_path(key)
        try:
            with open(path, 'w', encoding='utf-8') as f:
                json.dump({'_ts': time.time(), 'payload': payload}, f)
        except Exception as e:
            xbmc.log('[mpsupersearch] cache write failed: {0}'.format(e), xbmc.LOGWARNING)

    # --- HTTP -------------------------------------------------------------

    def _get(self, endpoint, params=None):
        if not self.api_key:
            xbmc.log('[mpsupersearch] TMDB call aborted: no API key set', xbmc.LOGERROR)
            return None
        params = dict(params or {})
        params['api_key'] = self.api_key
        params.setdefault('language', self.lang)
        url = '{0}/{1}?{2}'.format(TMDB_BASE, endpoint, urllib.parse.urlencode(params))
        sanitized = url.replace(self.api_key, '***')
        xbmc.log('[mpsupersearch] GET {0}'.format(sanitized), xbmc.LOGINFO)
        try:
            r = requests.get(url, timeout=10)
            xbmc.log('[mpsupersearch] HTTP {0}'.format(r.status_code), xbmc.LOGINFO)
            r.raise_for_status()
            return r.json()
        except Exception as e:
            xbmc.log('[mpsupersearch] TMDB GET {0} failed: {1}'.format(endpoint, e),
                     xbmc.LOGERROR)
            return None

    # --- public -----------------------------------------------------------

    def get_options(self, kind, tmdb_type):
        """
        Return list of dicts: {id, label, logo (optional)}.
        For 'keyword', returns [] — caller invokes search_keywords() instead.
        """
        cache_key = '{0}_{1}_{2}_{3}_v2'.format(kind, tmdb_type, self.lang, self.region)
        cached = self._cache_get(cache_key)
        if cached is not None:
            return cached

        result = []

        if kind == 'genre':
            data = self._get('genre/{0}/list'.format(tmdb_type))
            if data:
                result = [{'id': g['id'], 'label': g['name']}
                          for g in data.get('genres', [])]
            # TMDB's TV genre taxonomy is missing Horror, Thriller, etc.
            # They exist only as keywords. Inject them as synthetic entries
            # — the 'kw:' prefix tells state.py to route them to with_keywords.
            if tmdb_type == 'tv':
                missing_for_tv = [
                    'horror',
                    'thriller',
                    'supernatural',
                    'slasher',
                    'psychological thriller',
                ]
                for query in missing_for_tv:
                    kw_results = self.search_keywords(query)
                    if not kw_results:
                        continue
                    # Prefer an exact label match — TMDB's keyword search
                    # returns niche variants ("horror anthology", "slasher
                    # film genre") in unpredictable order, so the first
                    # hit isn't reliably the canonical broad tag.
                    exact = next(
                        (k for k in kw_results
                         if k['label'].strip().lower() == query.strip().lower()),
                        None,
                    )
                    kw = exact or kw_results[0]
                    result.append({
                        'id': 'kw:{0}'.format(kw['id']),
                        'label': kw['label'].title(),
                    })

        elif kind == 'network':
            # Use watch providers — covers Netflix, Apple TV+, Hulu, Max, Disney+, etc.
            # with logos. (Pure 'network' on TMDB is broadcast networks only.)
            data = self._get('watch/providers/{0}'.format(tmdb_type),
                             {'watch_region': self.region})
            if data:
                providers = sorted(
                    data.get('results', []),
                    key=lambda p: p.get('display_priority', 9999)
                )
                for p in providers[:80]:
                    logo = p.get('logo_path')
                    result.append({
                        'id': p['provider_id'],
                        'label': p['provider_name'],
                        'logo': '{0}{1}'.format(TMDB_LOGO, logo) if logo else None,
                    })

        elif kind == 'year':
            current_year = int(time.strftime('%Y'))
            years = list(range(current_year, 1949, -1))
            result = [{'id': y, 'label': str(y)} for y in years]

        elif kind == 'decade':
            current_year = int(time.strftime('%Y'))
            decade_start = (current_year // 10) * 10
            decades = list(range(decade_start, 1949, -10))
            result = [{'id': d, 'label': '{0}s'.format(d)} for d in decades]

        elif kind == 'rating':
            ratings = [
                ('8', '8.0+ Excellent'),
                ('7', '7.0+ Great'),
                ('6', '6.0+ Good'),
                ('5', '5.0+ Average'),
                ('4', '4.0+ Watchable'),
            ]
            result = [{'id': r[0], 'label': r[1]} for r in ratings]

        elif kind == 'sort':
            if tmdb_type == 'movie':
                sorts = [
                    ('popularity.desc',           'Most Popular'),
                    ('vote_average.desc',         'Highest Rated'),
                    ('primary_release_date.desc', 'Newest First'),
                    ('primary_release_date.asc',  'Oldest First'),
                    ('revenue.desc',              'Top Grossing'),
                ]
            else:
                sorts = [
                    ('popularity.desc',     'Most Popular'),
                    ('vote_average.desc',   'Highest Rated'),
                    ('first_air_date.desc', 'Newest First'),
                    ('first_air_date.asc',  'Oldest First'),
                ]
            result = [{'id': s[0], 'label': s[1]} for s in sorts]

        elif kind == 'language':
            data = self._get('configuration/languages')
            if data:
                priority = ['en', 'es', 'fr', 'de', 'it', 'ja', 'ko', 'zh', 'hi', 'pt', 'ru']
                priority_set = set(priority)
                ordered = sorted(
                    data,
                    key=lambda l: (
                        priority.index(l['iso_639_1']) if l['iso_639_1'] in priority_set else 999,
                        l.get('english_name', '') or l.get('iso_639_1', '')
                    )
                )
                for l in ordered:
                    if not l.get('english_name'):
                        continue
                    result.append({
                        'id': l['iso_639_1'],
                        'label': l['english_name'],
                    })

        elif kind == 'region':
            data = self._get('watch/providers/regions')
            if data:
                regions = sorted(
                    data.get('results', []),
                    key=lambda r: r.get('english_name', '')
                )
                for r in regions:
                    result.append({
                        'id': r['iso_3166_1'],
                        'label': r.get('english_name', r['iso_3166_1']),
                    })

        elif kind == 'keyword':
            # Special — handled via search_keywords() at click time.
            return []

        if result:
            self._cache_set(cache_key, result)
        return result

    def search_keywords(self, query):
        if not query:
            return []
        data = self._get('search/keyword', {'query': query})
        if not data:
            return []
        return [{'id': k['id'], 'label': k['name']}
                for k in data.get('results', [])[:30]]

    def search_titles(self, query, tmdb_type='movie', page=1):
        """
        TMDB title search via /search/movie or /search/tv. Returns the
        raw response dict (with 'results', 'total_pages', etc.) or None
        on failure. Used by results.py when the user typed a title in
        the search box rather than relying purely on Discover filters.

        Note: TMDB has a /search/multi that searches movies+tv+people
        but it returns mixed types and adds noise (people results we
        don't want). For our use we explicitly hit /search/movie or
        /search/tv based on the active tab.
        """
        if not query:
            return None
        if tmdb_type not in ('movie', 'tv'):
            tmdb_type = 'movie'
        return self._get('search/{0}'.format(tmdb_type), {
            'query': query,
            'page': str(page),
            'include_adult': 'false',
        })

    def discover(self, tmdb_type, params, page=1):
        """
        Hit TMDB's Discover endpoint directly. Returns the parsed response or None.
        params: dict of TMDB Discover query params (with_genres, with_keywords, etc.)
        """
        q = dict(params or {})
        q['page'] = str(page)
        return self._get('discover/{0}'.format(tmdb_type), q)
