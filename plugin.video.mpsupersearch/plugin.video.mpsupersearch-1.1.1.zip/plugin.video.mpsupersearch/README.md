# MP SuperSearch

A custom multi-filter search interface for Kodi. Stack up to 4 filters
(genre, network/streaming service, year, decade, rating, sort, language,
watch region, keyword), see your active selections as removable badges,
and hand the assembled query off to TMDB Helper for playback through
Fen Light, Umbrella, POV, or whichever player you have configured.

## Requirements

- Kodi 20 (Nexus) or 21 (Omega)
- TMDB Helper (`plugin.video.themoviedb.helper`) installed and configured with players (Fen, etc.)
- Free TMDB API key from <https://www.themoviedb.org/settings/api>
- `script.module.requests` (auto-installed as a dependency)

## Install

1. Drop `plugin.video.mpsupersearch-1.0.0.zip` into your repo (or install
   from zip locally for testing).
2. In Kodi: Add-ons → Install from zip file → pick the zip.
3. Open MP SuperSearch once; it will prompt for your TMDB API key and
   open Settings. Paste your key, set Watch Region (e.g. `US`), close.
4. Optional: under Settings → Enabled Filters, toggle off any filter
   types you don't want to see in the slot picker.

## Add to Arctic Horizon 2 home screen

1. Settings → Skin → Customize home menu → add a new menu item next to
   Fen.
2. Action: `RunAddon(plugin.video.mpsupersearch)`
3. Label: `SuperSearch` (or whatever you prefer).
4. Icon: point at `special://home/addons/plugin.video.mpsupersearch/resources/media/icon.png`

## Using it

- Top: tabs for Movies / TV. Switching tabs clears values (genre IDs
  differ between movies and TV) but keeps your slot configuration.
- Left column: 4 filter slots. Click an empty slot to choose a filter
  type from the menu (genre, network, year, etc.). Click a configured
  slot to pop a context menu with options to clear, change type, or
  remove the slot.
- Right area: the icon grid for the currently active slot. Click a tile
  to toggle it. Selected items get a green badge in the corner.
- Top right: badges showing every active filter value. Click one to
  remove it.
- Hit SEARCH. The window closes and TMDB Helper opens with your
  filtered results, ready to play through your configured player.

## Filter behavior notes

- **Multiple genres**: combined with AND (a movie must match all selected
  genres). Edit `state.py` and change `,` to `|` in the `with_genres`
  line if you'd rather have OR.
- **Multiple networks**: combined with OR (Netflix OR Hulu).
- **Multiple years**: treated as a date range from the lowest selected
  to the highest. Same for decades.
- **Multiple ratings**: the highest threshold wins.
- **Sort**: only the last-selected sort is applied.
- **Keywords**: special — opens a search dialog. Type a query, get TMDB
  keyword matches, multi-select.

## Hosting in your own repo

Bump the version in `addon.xml`, zip the addon directory, drop it in
your repo's tree, regenerate `addons.xml` and `addons.xml.md5`. Kodi
will see the update on its next repo check.

## Customizing the look

Layout lives in `resources/skins/default/1080i/DialogSuperSearch.xml`.
Colors are hex with leading alpha (`AARRGGBB`). The accent color
(`FF0078D4` — Kodi blue) appears in tabs, badges, and slot focus; swap
it for whatever matches your Arctic Horizon 2 accent.

## License

MIT
