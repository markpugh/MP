# -*- coding: utf-8 -*-
"""
Search history. Stores the last N searches (their re-runnable results URL,
a human-readable label, and a representative poster) as JSON in the add-on's
profile folder. Shown via the History button as a results-style directory.
"""
import json
import os

import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon()
MAX_ITEMS = 10
_FILENAME = 'search_history.json'


def _path():
    profile = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    if not os.path.isdir(profile):
        try:
            os.makedirs(profile)
        except Exception:
            pass
    return os.path.join(profile, _FILENAME)


def load():
    try:
        with open(_path(), 'r', encoding='utf-8') as f:
            data = json.load(f)
        return data if isinstance(data, list) else []
    except Exception:
        return []


def add(url, label, poster='', tmdb_type='movie'):
    """Record a search. De-dupes by url and keeps most-recent-first, capped."""
    if not url:
        return
    items = [e for e in load() if e.get('url') != url]
    items.insert(0, {
        'url': url,
        'label': label or 'Search',
        'poster': poster or '',
        'tmdb_type': tmdb_type or 'movie',
    })
    items = items[:MAX_ITEMS]
    try:
        with open(_path(), 'w', encoding='utf-8') as f:
            json.dump(items, f)
    except Exception:
        pass


def clear():
    try:
        os.remove(_path())
    except Exception:
        pass
