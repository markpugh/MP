# -*- coding: utf-8 -*-
"""
WindowXMLDialog subclass for MP SuperSearch.

Layout (DialogSuperSearch.xml):
- Top bar: title, [Movies] [TV] tabs, badges list (active filter values)
- Left column: 4 slot buttons + Search + Clear
- Right area: options panel (icon grid for the active slot)
"""
import xbmc
import xbmcgui
import xbmcaddon

from resources.lib.state import FilterState
from resources.lib.tmdb import TMDB
from resources.lib.handoff import launch_results
from resources.lib.constants import (
    CTRL_TAB_MOVIES, CTRL_TAB_TV,
    CTRL_SLOT_BUTTONS, CTRL_OPTIONS_PANEL,
    CTRL_BADGES, CTRL_SEARCH, CTRL_CLEAR,
    CTRL_TITLE_SEARCH,
    FILTER_KINDS, FILTER_LABELS,
)

ADDON = xbmcaddon.Addon()


class SuperSearchWindow(xbmcgui.WindowXMLDialog):

    def __init__(self, *args, **kwargs):
        super().__init__()
        self.state = FilterState()
        self.tmdb = TMDB()
        self.active_slot = None

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def onInit(self):
        self._refresh_tabs()
        self._refresh_slots()
        self._refresh_options_panel()
        self._refresh_badges()
        self._refresh_title_button()
        self.setFocusId(CTRL_TAB_MOVIES)

    def onAction(self, action):
        action_id = action.getId()
        if action_id in (xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK):
            self.close()

    # ------------------------------------------------------------------
    # Click routing
    # ------------------------------------------------------------------

    def onClick(self, control_id):
        if control_id == CTRL_TAB_MOVIES:
            self._switch_type('movie')
        elif control_id == CTRL_TAB_TV:
            self._switch_type('tv')
        elif control_id == CTRL_TITLE_SEARCH:
            self._handle_title_search()
        elif control_id in CTRL_SLOT_BUTTONS:
            self._handle_slot_click(CTRL_SLOT_BUTTONS.index(control_id))
        elif control_id == CTRL_OPTIONS_PANEL:
            self._handle_option_click()
        elif control_id == CTRL_BADGES:
            self._handle_badge_click()
        elif control_id == CTRL_SEARCH:
            self._do_search()
        elif control_id == CTRL_CLEAR:
            self._clear_all()

    # ------------------------------------------------------------------
    # Handlers
    # ------------------------------------------------------------------

    def _switch_type(self, tmdb_type):
        if self.state.tmdb_type == tmdb_type:
            return
        self.state.tmdb_type = tmdb_type
        # Some filter values (e.g. genre IDs) differ between movie/tv —
        # safest to clear values but keep the slot kinds the user picked.
        for slot in self.state.slots.values():
            slot['values'] = []
        self._refresh_tabs()
        self._refresh_slots()
        self._refresh_options_panel()
        self._refresh_badges()
        self._refresh_title_button()

    def _handle_slot_click(self, slot_index):
        if not self.state.slots.get(slot_index):
            self._pick_filter_type(slot_index)
        else:
            actions = ['Show options on the right',
                       'Change filter type',
                       'Clear selections in this slot',
                       'Remove this filter slot']
            choice = xbmcgui.Dialog().select(
                'Filter slot {0}'.format(slot_index + 1), actions)
            if choice == 0:
                self.active_slot = slot_index
            elif choice == 1:
                self._pick_filter_type(slot_index)
            elif choice == 2:
                self.state.slots[slot_index]['values'] = []
            elif choice == 3:
                self.state.slots.pop(slot_index, None)
                if self.active_slot == slot_index:
                    self.active_slot = None
            else:
                return
        self._refresh_slots()
        self._refresh_options_panel()
        self._refresh_badges()

    def _pick_filter_type(self, slot_index):
        enabled = self._enabled_filter_kinds()
        used = {self.state.slots[s]['kind']
                for s in self.state.slots
                if s != slot_index}
        available = [k for k in enabled if k not in used]
        if not available:
            xbmcgui.Dialog().ok('SuperSearch',
                                'No more filter types available. '
                                'Disable some in addon settings or remove an existing slot.')
            return
        labels = [FILTER_LABELS[k] for k in available]
        idx = xbmcgui.Dialog().select('Choose filter type for slot {0}'.format(slot_index + 1),
                                      labels)
        if idx < 0:
            return
        chosen = available[idx]
        self.state.slots[slot_index] = {'kind': chosen, 'values': []}
        self.active_slot = slot_index

    def _handle_option_click(self):
        if self.active_slot is None:
            return
        slot = self.state.slots.get(self.active_slot)
        if not slot:
            return

        panel = self.getControl(CTRL_OPTIONS_PANEL)
        pos = panel.getSelectedPosition()
        if pos < 0:
            return
        item = panel.getListItem(pos)
        value_id = item.getProperty('value_id')
        value_label = item.getLabel()

        existing = next((v for v in slot['values']
                         if str(v['id']) == value_id), None)
        if existing:
            slot['values'].remove(existing)
            item.setProperty('selected', 'false')
        else:
            slot['values'].append({'id': value_id, 'label': value_label})
            item.setProperty('selected', 'true')

        self._refresh_badges()
        self._refresh_slots()

    def _handle_badge_click(self):
        badges = self.getControl(CTRL_BADGES)
        pos = badges.getSelectedPosition()
        if pos < 0:
            return
        item = badges.getListItem(pos)
        try:
            slot_index = int(item.getProperty('slot'))
        except (TypeError, ValueError):
            return
        value_id = item.getProperty('value_id')
        slot = self.state.slots.get(slot_index)
        if not slot:
            return
        slot['values'] = [v for v in slot['values']
                          if str(v['id']) != value_id]
        self._refresh_options_panel()
        self._refresh_badges()
        self._refresh_slots()

    def _do_search(self):
        if not self.state.has_filters() and not self.state.has_title():
            xbmcgui.Dialog().notification(
                'SuperSearch',
                'Type a title or pick at least one filter first.',
                xbmcgui.NOTIFICATION_INFO, 2500)
            return
        url = self.state.to_discover_url()
        self.close()
        launch_results(url)

    def _clear_all(self):
        if not self.state.has_filters() and not self.state.slots and not self.state.has_title():
            return
        if not xbmcgui.Dialog().yesno('SuperSearch', 'Clear all filters and title search?'):
            return
        self.state.clear()
        self.active_slot = None
        self._refresh_slots()
        self._refresh_options_panel()
        self._refresh_badges()
        self._refresh_title_button()

    # ------------------------------------------------------------------
    # Render helpers
    # ------------------------------------------------------------------

    def _refresh_tabs(self):
        # Window property drives the visual indicator bars in XML.
        # Note: ControlButton has no setProperty — visual state must be on the window.
        self.setProperty('active_tab', self.state.tmdb_type)

    def _refresh_slots(self):
        self.setProperty('active_slot', str(self.active_slot) if self.active_slot is not None else '')
        for i, ctrl_id in enumerate(CTRL_SLOT_BUTTONS):
            try:
                btn = self.getControl(ctrl_id)
            except Exception:
                continue
            slot = self.state.slots.get(i)
            if slot:
                kind_label = FILTER_LABELS.get(slot['kind'], slot['kind'])
                values = slot.get('values') or []
                if values:
                    # Show "Genre: Horror" for single value, "Genre: Horror, Drama"
                    # for multi (truncated to keep the slot button readable).
                    value_text = ', '.join(v.get('label', '?') for v in values)
                    if len(value_text) > 24:
                        value_text = value_text[:22] + '…'
                    btn.setLabel('[B]{0}[/B]: {1}'.format(kind_label, value_text))
                else:
                    # Slot has a kind picked but no values yet — keep prompt
                    # short so it doesn't wrap into the next row.
                    btn.setLabel('[B]{0}[/B] [I](pick →)[/I]'.format(kind_label))
            else:
                btn.setLabel('[I]+ Add filter {0}[/I]'.format(i + 1))

    def _handle_title_search(self):
        """
        Pop Kodi's keyboard for a title query. Updates state.title_query,
        refreshes the title button label, and (if the user typed something)
        leaves them on the title button so they can hit Search next.
        """
        current = self.state.title_query or ''
        kb = xbmc.Keyboard(current, 'Search by title (movies and TV shows)')
        kb.doModal()
        if not kb.isConfirmed():
            return
        text = (kb.getText() or '').strip()
        self.state.title_query = text
        self._refresh_title_button()
        # If they cleared it, also nothing else to do. If they entered
        # something, focus the Search button so they can submit fast.
        if text:
            try:
                self.setFocusId(CTRL_SEARCH)
            except Exception:
                pass

    def _refresh_title_button(self):
        """
        Render the title search button to reflect current query.
        Empty: "🔍  Search by title…"
        With value: "🔍  <query>  ✕"  (tap clears via separate path below)
        """
        try:
            btn = self.getControl(CTRL_TITLE_SEARCH)
        except Exception:
            return
        q = (self.state.title_query or '').strip()
        if q:
            display = q if len(q) <= 28 else q[:26] + '…'
            btn.setLabel('[B]🔍[/B]  {0}'.format(display))
        else:
            btn.setLabel('[I]🔍  Search by title…[/I]')

    def _refresh_options_panel(self):
        try:
            panel = self.getControl(CTRL_OPTIONS_PANEL)
        except Exception:
            return
        panel.reset()

        if self.active_slot is None:
            self.setProperty('panel_state', 'no_slot')
            return
        slot = self.state.slots.get(self.active_slot)
        if not slot:
            self.setProperty('panel_state', 'no_slot')
            return

        # Keyword filter is interactive: search dialog instead of static list.
        if slot['kind'] == 'keyword':
            self.setProperty('panel_state', 'keyword')
            self._handle_keyword_input(slot)
            return

        xbmc.log('[mpsupersearch] Fetching options for kind={0} type={1}'.format(
            slot['kind'], self.state.tmdb_type), xbmc.LOGINFO)
        options = self.tmdb.get_options(slot['kind'], self.state.tmdb_type)
        xbmc.log('[mpsupersearch] Got {0} options'.format(len(options) if options else 0),
                 xbmc.LOGINFO)

        if not options:
            self.setProperty('panel_state', 'empty')
            xbmcgui.Dialog().notification(
                'SuperSearch',
                'No options returned for {0}. Check API key / connectivity.'.format(
                    FILTER_LABELS.get(slot['kind'], slot['kind'])),
                xbmcgui.NOTIFICATION_WARNING, 3000)
            return

        self.setProperty('panel_state', 'populated')
        selected_ids = {str(v['id']) for v in slot.get('values', [])}
        items = []
        for opt in options:
            li = xbmcgui.ListItem(label=opt['label'])
            li.setProperty('value_id', str(opt['id']))
            li.setProperty('selected',
                           'true' if str(opt['id']) in selected_ids else 'false')
            if opt.get('logo'):
                li.setArt({'thumb': opt['logo'], 'icon': opt['logo']})
            items.append(li)
        panel.addItems(items)

    def _handle_keyword_input(self, slot):
        query = xbmcgui.Dialog().input('Search TMDB keywords (e.g. "haunted house")', '')
        if not query:
            return
        results = self.tmdb.search_keywords(query)
        if not results:
            xbmcgui.Dialog().ok(
                'SuperSearch',
                'No keywords matched "{0}".'.format(query))
            return
        labels = [r['label'] for r in results]
        preselect = []
        existing_ids = {str(v['id']) for v in slot.get('values', [])}
        for i, r in enumerate(results):
            if str(r['id']) in existing_ids:
                preselect.append(i)
        chosen = xbmcgui.Dialog().multiselect(
            'Select keywords to include', labels, preselect=preselect)
        if chosen is None:
            return
        # Replace the slot's keyword values with the new selection
        slot['values'] = [results[i] for i in chosen]
        self._refresh_badges()
        self._refresh_slots()

    def _refresh_badges(self):
        try:
            badges = self.getControl(CTRL_BADGES)
        except Exception:
            return
        badges.reset()

        items = []
        for slot_index in sorted(self.state.slots.keys()):
            slot = self.state.slots[slot_index]
            for v in slot.get('values', []):
                kind_label = FILTER_LABELS.get(slot['kind'], slot['kind'])
                li = xbmcgui.ListItem(
                    label='{0}: {1}'.format(kind_label, v['label']))
                li.setProperty('slot', str(slot_index))
                li.setProperty('value_id', str(v['id']))
                li.setProperty('kind', slot['kind'])
                items.append(li)
        if items:
            badges.addItems(items)

    # ------------------------------------------------------------------
    # Settings
    # ------------------------------------------------------------------

    def _enabled_filter_kinds(self):
        enabled = []
        for kind in FILTER_KINDS:
            try:
                if ADDON.getSettingBool('enable_{0}'.format(kind)):
                    enabled.append(kind)
            except Exception:
                # Older Kodi versions: fallback string comparison
                if ADDON.getSetting('enable_{0}'.format(kind)).lower() in ('true', '1'):
                    enabled.append(kind)
        return enabled or list(FILTER_KINDS)
