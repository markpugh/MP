# -*- coding: utf-8 -*-
"""
Filter state and Discover URL builder.

We build a URL pointing back at our own plugin with action=results, carrying
all the TMDB API filter params. default.py routes that back to results.py
which calls TMDB Discover directly. This is necessary because TMDB Helper's
discover route doesn't support many of the params we need (with_keywords,
with_watch_providers, etc.).

State shape:
    tmdb_type: 'movie' | 'tv'
    slots: dict[int, {'kind': str, 'values': [{'id', 'label'}]}]
"""
import urllib.parse
import xbmcaddon

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')


class FilterState:
    def __init__(self):
        self.tmdb_type = 'movie'
        self.slots = {}

    def clear(self):
        self.slots = {}

    def has_filters(self):
        return any(s.get('values') for s in self.slots.values())

    def to_discover_url(self):
        """
        Build a plugin URL pointing at ourselves with action=results.
        TMDB Discover query params travel along with it; results.py picks
        them out and calls TMDB directly.
        """
        params = {
            'action': 'results',
            'tmdb_type': self.tmdb_type,
        }
        sort_set = False
        date_field = 'primary_release_date' if self.tmdb_type == 'movie' else 'first_air_date'

        for slot in self.slots.values():
            kind = slot.get('kind')
            values = slot.get('values') or []
            if not values:
                continue

            if kind == 'genre':
                # 'kw:NNN' values route to with_keywords (synthetic genres);
                # everything else is a real genre ID.
                real_genres = []
                kw_from_genre = []
                for v in values:
                    sid = str(v['id'])
                    if sid.startswith('kw:'):
                        kw_from_genre.append(sid[3:])
                    else:
                        real_genres.append(sid)
                if real_genres:
                    # Comma = AND on TMDB. Most users want AND for "drama AND horror".
                    params['with_genres'] = ','.join(real_genres)
                if kw_from_genre:
                    existing = params.get('with_keywords', '')
                    new = '|'.join(kw_from_genre)  # OR for synthetic genres
                    params['with_keywords'] = (
                        existing + '|' + new if existing else new
                    )

            elif kind == 'network':
                # OR for streaming providers (shows on Netflix OR Hulu)
                params['with_watch_providers'] = '|'.join(str(v['id']) for v in values)
                params['watch_region'] = self._region()

            elif kind == 'year':
                ys = sorted(int(v['id']) for v in values)
                params['{0}.gte'.format(date_field)] = '{0}-01-01'.format(ys[0])
                params['{0}.lte'.format(date_field)] = '{0}-12-31'.format(ys[-1])

            elif kind == 'decade':
                ds = sorted(int(v['id']) for v in values)
                params['{0}.gte'.format(date_field)] = '{0}-01-01'.format(ds[0])
                params['{0}.lte'.format(date_field)] = '{0}-12-31'.format(ds[-1] + 9)

            elif kind == 'rating':
                threshold = max(float(v['id']) for v in values)
                params['vote_average.gte'] = str(threshold)
                params['vote_count.gte'] = '50'  # avoid sparse-vote noise

            elif kind == 'sort':
                params['sort_by'] = values[-1]['id']
                sort_set = True

            elif kind == 'language':
                params['with_original_language'] = '|'.join(str(v['id']) for v in values)

            elif kind == 'region':
                params['watch_region'] = values[-1]['id']

            elif kind == 'keyword':
                new_kws = '|'.join(str(v['id']) for v in values)
                existing = params.get('with_keywords', '')
                params['with_keywords'] = (
                    existing + '|' + new_kws if existing else new_kws
                )

        if not sort_set:
            params['sort_by'] = 'popularity.desc'

        return 'plugin://{0}/?{1}'.format(ADDON_ID, urllib.parse.urlencode(params))

    def _region(self):
        return (ADDON.getSetting('watch_region') or 'US').strip().upper()
