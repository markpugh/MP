# -*- coding: utf-8 -*-
"""
Movie Roulette.

Flow:
  1. Multiselect genre(s) from the TMDB movie genre list.
  2. Pull a popularity-biased random page of TMDB Discover movies for
     those genres (OR semantics — "any of these genres").
  3. Drop movies already watched, per Trakt. We reuse TMDB Helper's
     ALREADY-AUTHENTICATED Trakt layer (set up via the build's QR flow)
     rather than doing our own OAuth. If TMDB Helper / Trakt isn't
     available, roulette still runs — it just can't filter watched.
  4. Pick one unwatched movie at random and hand it to MP SuperLite,
     which does the scrape -> rank -> debrid -> play pipeline. If
     SuperLite finds no sources, the user just spins again.

Why popularity-biased random page: SuperLite can only play what its
scrapers can find. Uniformly random across all Discover pages surfaces
obscure titles with no seeders, so spins dead-end. Capping the random
page (MAX_RANDOM_PAGE) and flooring vote_count keeps picks varied but
well-seeded enough to usually resolve.
"""
import os
import random
import sys

import xbmc
import xbmcaddon
import xbmcgui

from resources.lib.tmdb import TMDB

ADDON = xbmcaddon.Addon()
ADDON_NAME = 'MP SuperSearch'

# MP SuperLite play route (see plugin.video.mpsuperlite/default.py).
SUPERLITE_PLAY = ('plugin://plugin.video.mpsuperlite/'
                  '?action=play&tmdb_type=movie&tmdb_id={0}')

# Discover is popularity.desc sorted; cap the random page so picks stay
# well-seeded enough that SuperLite can usually resolve them.
MAX_RANDOM_PAGE = 15
VOTE_COUNT_FLOOR = 100
# How many random pages to try before giving up (a fully-watched page
# shouldn't dead-end a spin).
MAX_PAGE_ATTEMPTS = 4


def _get_trakt_watched_checker():
    """
    Return is_watched(tmdb_id) -> bool, backed by TMDB Helper's
    authenticated Trakt sync. Returns None if Trakt/TMDB Helper isn't
    available or isn't authorized.

    This deliberately reaches into TMDB Helper internals to reuse the
    token the build's QR flow established, so it's wrapped defensively:
    ANY failure degrades to "no watched filtering" instead of breaking
    roulette. We never call anything that could pop a login dialog — we
    gate on the authenticator's pure is_authorized (bool(access_token))
    and bail before touching sync if not authorized.
    """
    try:
        th = xbmcaddon.Addon('plugin.video.themoviedb.helper')
    except Exception:
        xbmc.log('[mpsupersearch] TMDB Helper not installed; roulette will '
                 'not filter watched movies.', xbmc.LOGINFO)
        return None

    try:
        th_res = os.path.join(th.getAddonInfo('path'), 'resources')
        if th_res not in sys.path:
            sys.path.insert(0, th_res)
        from tmdbhelper.lib.api.trakt.api import TraktAPI

        trakt = TraktAPI()  # __init__ authorize() is non-forcing: no prompt
        # authenticator.is_authorized is a pure bool(access_token) read —
        # it never triggers ask_to_login(). Bail quietly if not connected.
        if not trakt.authenticator.is_authorized:
            xbmc.log('[mpsupersearch] Trakt not authorized in TMDB Helper; '
                     'roulette will not filter watched.', xbmc.LOGINFO)
            return None

        syncdata = trakt.trakt_syncdata
        if syncdata is None:
            return None

        def is_watched(tmdb_id):
            # get_movie_playcount triggers a one-time watched sync on first
            # call (cached after), then reads play count keyed by TMDB id.
            try:
                return bool(syncdata.get_movie_playcount(int(tmdb_id)))
            except Exception:
                return False

        return is_watched

    except Exception as e:
        xbmc.log('[mpsupersearch] Trakt watched-check unavailable ({0}); '
                 'roulette will not filter watched.'.format(e),
                 xbmc.LOGWARNING)
        return None


def _choose_genres(tmdb):
    """Multiselect dialog over the TMDB movie genre list. Returns the
    chosen option dicts, or None if cancelled / nothing picked."""
    options = tmdb.get_options('genre', 'movie')
    # Drop synthetic 'kw:' genre entries — those are TV-only keyword
    # stand-ins and don't belong in movie Discover with_genres.
    options = [o for o in (options or [])
               if not str(o.get('id', '')).startswith('kw:')]
    if not options:
        xbmcgui.Dialog().ok(
            ADDON_NAME,
            'Could not load genres from TMDB. Check your API key and '
            'connectivity, then try again.')
        return None

    labels = [o['label'] for o in options]
    chosen = xbmcgui.Dialog().multiselect(
        'Movie Roulette — pick genre(s)', labels)
    if not chosen:  # None (cancelled) or empty list
        return None
    return [options[i] for i in chosen]


def _discover_page(tmdb, genre_ids):
    """
    Pull one popularity-biased random page of movie Discover results for
    the given genre id string. Returns (results_list, total_pages).
    """
    params = {
        'with_genres': genre_ids,          # '|' joined = OR on TMDB
        'sort_by': 'popularity.desc',
        'vote_count.gte': str(VOTE_COUNT_FLOOR),
        'include_adult': 'false',
    }
    first = tmdb.discover('movie', params, page=1)
    if not first or not first.get('results'):
        return [], 0

    total_pages = min(int(first.get('total_pages') or 1), MAX_RANDOM_PAGE)
    if total_pages <= 1:
        return first['results'], total_pages

    page = random.randint(1, total_pages)
    if page == 1:
        return first['results'], total_pages

    data = tmdb.discover('movie', params, page=page)
    results = (data or {}).get('results') or first['results']
    return results, total_pages


def run():
    """Entry point for the roulette flow (called from the window button
    and from default.py's action=roulette route)."""
    if not ADDON.getSetting('tmdb_api_key').strip():
        xbmcgui.Dialog().ok(ADDON_NAME,
                            'Set your TMDB API key in addon settings first.')
        return

    tmdb = TMDB()

    genres = _choose_genres(tmdb)
    if not genres:
        return

    # OR across selected genres for a broad "any of these" pool.
    genre_ids = '|'.join(str(g['id']) for g in genres)

    is_watched = _get_trakt_watched_checker()

    progress = xbmcgui.DialogProgress()
    progress.create(ADDON_NAME, 'Spinning the reel...')

    candidates = []
    try:
        seen = set()
        for attempt in range(MAX_PAGE_ATTEMPTS):
            if progress.iscanceled():
                return
            results, total_pages = _discover_page(tmdb, genre_ids)
            if not results:
                break
            for r in results:
                tid = r.get('id')
                if not tid or tid in seen:
                    continue
                seen.add(tid)
                if is_watched and is_watched(tid):
                    continue
                candidates.append(r)
            # Enough to pick from, and we pulled a fresh random page —
            # stop once we have a reasonable pool.
            if len(candidates) >= 5:
                break
            # If there's only one page, no point re-rolling pages.
            if total_pages <= 1:
                break
    finally:
        progress.close()

    if not candidates:
        msg = ('No unwatched movies found for those genres. '
               'Try selecting more genres.')
        if is_watched is None:
            msg = ('No movies found for those genres. Check your TMDB '
                   'API key / connectivity.')
        xbmcgui.Dialog().notification(
            ADDON_NAME, msg, xbmcgui.NOTIFICATION_INFO, 4000)
        return

    pick = random.choice(candidates)
    title = pick.get('title') or pick.get('name') or 'Unknown'
    year = (pick.get('release_date') or '')[:4]
    label = '{0}{1}'.format(title, ' ({0})'.format(year) if year else '')

    xbmc.log('[mpsupersearch] Roulette picked: {0} tmdb_id={1} '
             '(pool of {2})'.format(label, pick.get('id'), len(candidates)),
             xbmc.LOGINFO)

    xbmcgui.Dialog().notification(
        ADDON_NAME, 'Playing: {0}'.format(label),
        xbmcgui.NOTIFICATION_INFO, 3500)

    xbmc.executebuiltin('PlayMedia({0})'.format(
        SUPERLITE_PLAY.format(pick['id'])))
