# -*- coding: utf-8 -*-
"""
Launch the results listing.

state.to_discover_url() now produces a URL that points back at our own
plugin with action=results. Container.Update navigates Kodi into that
listing, where results.py will render the items.
"""
import xbmc


def launch_results(plugin_url):
    xbmc.executebuiltin('Container.Update({0})'.format(plugin_url))
