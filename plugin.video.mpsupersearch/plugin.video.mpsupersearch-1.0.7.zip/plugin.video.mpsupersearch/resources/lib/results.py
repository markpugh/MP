# -*- coding: utf-8 -*-
"""
Render TMDB Discover results as a Kodi directory listing.

Why this exists: TMDB Helper's discover route doesn't support most of the
filter params we offer (with_keywords, with_watch_providers, watch_region,
date ranges, etc.). So we hit TMDB's Discover endpoint directly, then hand
each result's onClick off to TMDB Helper's per-item info/play route, which
IS well-supported.
"""
import urllib.parse

import xbmc
import xbmcgui
import xbmcplugin

from resources.lib.tmdb import TMDB

# TMDB Discover params we forward (must start with one of these prefixes
# or be in the explicit allowlist).
ALLOWED_PREFIXES = ('with_', 'without_', 'vote_', 'primary_release_',
                    'release_', 'first_air_', 'air_')
ALLOWED_KEYS = {'sort_by', 'watch_region', 'include_adult',
                'with_original_language'}

# TMDB image base + size
POSTER_BASE = 'https://image.tmdb.org/t/p/w500'
FANART_BASE = 'https://image.tmdb.org/t/p/w1280'

# TMDB Discover hard-caps page at 500
TMDB_MAX_PAGE = 500


def _filter_params(qs):
    """Pick out only the TMDB Discover params from the parsed query string."""
    out = {}
    for k, v in qs.items():
        if not v:
            continue
        if k in ALLOWED_KEYS or any(k.startswith(p) for p in ALLOWED_PREFIXES):
            out[k] = v[0] if isinstance(v, list) else v
    return out


def _build_page_url(query_args, page):
    """Rebuild the plugin URL with a different page param, preserving filters."""
    new_args = {}
    for k, v in query_args.items():
        if k == 'page':
            continue
        new_args[k] = v[0] if isinstance(v, list) else v
    new_args['action'] = 'results'
    new_args['page'] = str(page)
    return 'plugin://plugin.video.mpsupersearch/?' + urllib.parse.urlencode(new_args)


def render(handle, query_args):
    """
    handle: int from sys.argv[1]
    query_args: dict from urllib.parse.parse_qs(sys.argv[2][1:])
    """
    tmdb_type = (query_args.get('tmdb_type') or ['movie'])[0]
    if tmdb_type not in ('movie', 'tv'):
        tmdb_type = 'movie'

    # Pagination: which page of results does the user want?
    try:
        page = int((query_args.get('page') or ['1'])[0])
    except (ValueError, TypeError):
        page = 1
    if page < 1:
        page = 1
    if page > TMDB_MAX_PAGE:
        page = TMDB_MAX_PAGE

    discover_params = _filter_params(query_args)

    xbmc.log('[mpsupersearch] Rendering page {0}: tmdb_type={1} params={2}'.format(
        page, tmdb_type, discover_params), xbmc.LOGINFO)

    tmdb = TMDB()
    data = tmdb.discover(tmdb_type, discover_params, page=page)

    if not data or not data.get('results'):
        xbmcgui.Dialog().notification(
            'SuperSearch',
            'No results returned from TMDB.',
            xbmcgui.NOTIFICATION_INFO, 3000)
        xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)
        return

    total_pages = min(int(data.get('total_pages') or 1), TMDB_MAX_PAGE)
    total_results = int(data.get('total_results') or 0)

    # Breadcrumb: "Page 1 of 47  •  938 results"
    try:
        xbmcplugin.setPluginCategory(
            handle,
            'Page {0} of {1}  \u2022  {2} results'.format(
                page, total_pages, total_results)
        )
    except Exception:
        pass

    items = []
    for r in data['results']:
        title = r.get('title') or r.get('name') or 'Untitled'
        tmdb_id = r.get('id')
        if not tmdb_id:
            continue

        date = r.get('release_date') or r.get('first_air_date') or ''
        year = None
        if date and len(date) >= 4 and date[:4].isdigit():
            year = int(date[:4])

        poster = (POSTER_BASE + r['poster_path']) if r.get('poster_path') else ''
        fanart = (FANART_BASE + r['backdrop_path']) if r.get('backdrop_path') else ''

        # Hand off to TMDB Helper using its supported per-item URL.
        # info=details opens the show/movie page where the user picks a player.
        target_url = (
            'plugin://plugin.video.themoviedb.helper/?'
            'info=details&tmdb_type={0}&tmdb_id={1}'.format(tmdb_type, tmdb_id)
        )

        li = xbmcgui.ListItem(label=title)
        if poster:
            li.setArt({'thumb': poster, 'poster': poster, 'icon': poster,
                       'fanart': fanart or poster})

        # Set video info (works on Kodi 19/20/21)
        info = {
            'title': title,
            'plot': r.get('overview') or '',
            'mediatype': 'movie' if tmdb_type == 'movie' else 'tvshow',
        }
        if year:
            info['year'] = year
        if r.get('vote_average'):
            info['rating'] = float(r['vote_average'])
        if r.get('vote_count'):
            info['votes'] = str(r['vote_count'])
        try:
            li.setInfo('video', info)
        except Exception:
            pass

        items.append((target_url, li, True))  # True = isFolder; let TMDB Helper navigate

    # Append "Next page" entry if there's more to show
    if page < total_pages:
        next_url = _build_page_url(query_args, page + 1)
        next_li = xbmcgui.ListItem(
            label='[B][COLOR FF0078D4]\u2192 Next page[/COLOR][/B]   '
                  '({0} of {1})'.format(page + 1, total_pages)
        )
        next_li.setArt({'icon': 'DefaultFolderBack.png',
                        'thumb': 'DefaultFolderBack.png'})
        try:
            next_li.setInfo('video', {
                'title': 'Next page',
                'plot': 'Show page {0} of {1} ({2} total results).'.format(
                    page + 1, total_pages, total_results),
            })
        except Exception:
            pass
        # SpecialSort hint pins this item to the bottom regardless of sort
        try:
            next_li.setProperty('SpecialSort', 'bottom')
        except Exception:
            pass
        items.append((next_url, next_li, True))  # folder

    xbmcplugin.setContent(handle, 'movies' if tmdb_type == 'movie' else 'tvshows')
    xbmcplugin.addDirectoryItems(handle, items, len(items))
    xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)


def parse_query_string(qs):
    """Parse a Kodi plugin query string (starts with '?') into a dict."""
    if qs and qs.startswith('?'):
        qs = qs[1:]
    return urllib.parse.parse_qs(qs, keep_blank_values=True)
