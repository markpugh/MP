# -*- coding: utf-8 -*-
"""
MP SuperSearch — entry point.

Two routes:
- No params (or action=window): opens the SuperSearch filter window
- action=results: calls TMDB Discover directly and renders results as
  a Kodi directory listing, then hands off per-item clicks to TMDB Helper
"""
import sys
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui

ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
sys.path.insert(0, ADDON_PATH)


def _parse_args():
    """sys.argv[2] is the query string (starts with ?). Empty if invoked as a script."""
    if len(sys.argv) < 3:
        return {}
    qs = sys.argv[2]
    if qs.startswith('?'):
        qs = qs[1:]
    return urllib.parse.parse_qs(qs, keep_blank_values=True)


def _get_handle():
    if len(sys.argv) < 2:
        return -1
    try:
        return int(sys.argv[1])
    except (ValueError, TypeError):
        return -1


def _open_window():
    if not ADDON.getSetting('tmdb_api_key').strip():
        xbmcgui.Dialog().ok(
            'MP SuperSearch',
            'TMDB API key is not set. Open the addon settings and paste your '
            'key from themoviedb.org/settings/api.'
        )
        ADDON.openSettings()
        return

    from resources.lib.window import SuperSearchWindow
    window = SuperSearchWindow(
        'DialogSuperSearch.xml', ADDON_PATH, 'default', '1080i'
    )
    window.doModal()
    del window


def main():
    args = _parse_args()
    action = (args.get('action') or [''])[0]

    if action == 'results':
        # Render TMDB Discover results
        from resources.lib.results import render
        render(_get_handle(), args)
        return

    if action == 'history':
        # Render the last-10-searches list (re-runnable), in MP view.
        from resources.lib.results import render_history
        render_history(_get_handle())
        return

    if action == 'roulette':
        # Direct entry point so the roulette flow can be bound to a skin
        # widget, favourite, or keymap without opening the search dialog.
        handle = _get_handle()
        if handle >= 0:
            try:
                import xbmcplugin
                xbmcplugin.endOfDirectory(handle, succeeded=True,
                                          cacheToDisc=False)
            except Exception:
                pass
        if not ADDON.getSetting('tmdb_api_key').strip():
            xbmcgui.Dialog().ok(
                'MP SuperSearch',
                'TMDB API key is not set. Open the addon settings and paste '
                'your key from themoviedb.org/settings/api.')
            ADDON.openSettings()
            return
        from resources.lib import roulette
        roulette.run()
        return

    # Default route: open the search window
    handle = _get_handle()
    if handle >= 0:
        # Resolve the directory listing as an empty success. This gets the
        # plugin entry point onto Kodi's navigation stack so that pressing
        # back from a results page returns here, which re-runs default.py
        # and re-opens the search dialog with the user's prior filters
        # preserved (state lives in window properties for the session).
        try:
            import xbmcplugin
            xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)
        except Exception:
            pass

    _open_window()


if __name__ == '__main__':
    main()
