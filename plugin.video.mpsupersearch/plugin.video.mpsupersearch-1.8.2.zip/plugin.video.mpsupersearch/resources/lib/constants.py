# -*- coding: utf-8 -*-
"""
Shared constants. Control IDs MUST match DialogSuperSearch.xml.
"""

# --- Control IDs ----------------------------------------------------------

CTRL_TAB_MOVIES = 100
CTRL_TAB_TV = 101

CTRL_SLOT_BUTTONS = [200, 201, 202, 203]

CTRL_OPTIONS_PANEL = 300
CTRL_BADGES = 400

CTRL_SEARCH = 500
CTRL_CLEAR = 501

# v1.6.0: Movie Roulette. Self-contained flow (own genre multiselect),
# independent of the 4 filter slots. Pulls a popularity-biased random
# Discover page, filters out Trakt-watched movies (via TMDB Helper's
# authenticated Trakt sync), and hands a random unwatched pick to
# MP SuperLite for playback.
CTRL_ROULETTE = 700

# v1.1.0: dedicated title text search at the top of the left column.
# Replaces the misleading "keyword as title" workflow. When this has a
# value, the search will run TMDB /search/multi (real title search) and
# then client-side filter the results by any selected genre/network/etc.
# slots. When empty, falls back to filter-only Discover.
CTRL_TITLE_SEARCH = 600

# v1.8.0: Search History button next to the title search. Shows the last 10
# searches as a results-style directory (rendered in the MP view).
CTRL_HISTORY = 601

# --- Filter kinds ---------------------------------------------------------

FILTER_KINDS = [
    'genre',
    'network',
    'year',
    'decade',
    'rating',
    'sort',
    'language',
    'region',
    'keyword',
]

FILTER_LABELS = {
    'genre':    'Genre',
    'network':  'Network / Streaming',
    'year':     'Year',
    'decade':   'Decade',
    'rating':   'Min Rating',
    'sort':     'Sort By',
    'language': 'Original Language',
    'region':   'Watch Region',
    'keyword':  'Keyword',
}

MAX_SLOTS = 4
