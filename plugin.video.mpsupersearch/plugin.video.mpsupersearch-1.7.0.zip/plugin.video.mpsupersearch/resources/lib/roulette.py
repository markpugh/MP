# -*- coding: utf-8 -*-
"""
Movie Roulette.

Flow:
  1. Multiselect genre(s) from the TMDB movie genre list. The selection is
     remembered for the session so "Spin again" doesn't re-ask.
  2. Pull a popularity-biased random page of TMDB Discover movies for
     those genres (OR semantics — "any of these genres").
  3. Drop movies already watched, per Trakt. We reuse TMDB Helper's
     ALREADY-AUTHENTICATED Trakt layer (set up via the build's QR flow)
     rather than doing our own OAuth. If TMDB Helper / Trakt isn't
     available, roulette still runs — it just can't filter watched.
  4. Show the pick in a reveal card (poster, rating, plot) with Play,
     Trailer, and Spin Again. Play hands off to MP SuperLite.

Why popularity-biased random page: SuperLite can only play what its
scrapers can find. Uniformly random across all Discover pages surfaces
obscure titles with no seeders, so spins dead-end. Capping the random
page (MAX_RANDOM_PAGE) and flooring vote_count keeps picks varied but
well-seeded enough to usually resolve.

v1.7.0: replaced the blind "notification then play" handoff with the
reveal card. Previously the only way to find out what you'd landed on
was to sit through the scrape and see what started playing, with no way
to say "no, spin again" short of stopping playback.
"""
import os
import random
import sys

import xbmc
import xbmcaddon
import xbmcgui

from resources.lib.tmdb import TMDB

ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
ADDON_NAME = 'MP SuperSearch'

# MP SuperLite play route (see plugin.video.mpsuperlite/default.py).
SUPERLITE_PLAY = ('plugin://plugin.video.mpsuperlite/'
                  '?action=play&tmdb_type=movie&tmdb_id={0}')

TRAILER_SCRIPT = 'RunScript(script.mp.trailerfinder,find,{0},movie)'

POSTER_BASE = 'https://image.tmdb.org/t/p/w500'
FANART_BASE = 'https://image.tmdb.org/t/p/w1280'

# Discover is popularity.desc sorted; cap the random page so picks stay
# well-seeded enough that SuperLite can usually resolve them.
MAX_RANDOM_PAGE = 15
VOTE_COUNT_FLOOR = 100
# How many random pages to pull before giving up (a fully-watched page
# shouldn't dead-end a spin).
MAX_PAGE_ATTEMPTS = 4
# Stop pulling pages once the pool is at least this big.
TARGET_POOL = 20

# Reveal dialog control IDs — must match DialogRoulette.xml.
CTRL_PLAY = 900
CTRL_TRAILER = 901
CTRL_SPIN = 902
CTRL_CLOSE = 903
CTRL_GENRES = 904

# Session memory so "Spin again" reuses the genres without re-prompting.
_HOME = xbmcgui.Window(10000)
_GENRE_MEMO_KEY = 'mpsupersearch.roulette.genres'
_GENRE_LABEL_KEY = 'mpsupersearch.roulette.genre_labels'


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log('[mpsupersearch] roulette: {0}'.format(msg), level=level)


# ----------------------------------------------------------------------
# Trakt watched filtering
# ----------------------------------------------------------------------

def _get_trakt_watched_checker():
    """
    Return is_watched(tmdb_id) -> bool, backed by TMDB Helper's
    authenticated Trakt sync. Returns None if Trakt/TMDB Helper isn't
    available or isn't authorized.

    This deliberately reaches into TMDB Helper internals to reuse the
    token the build's QR flow established, so it's wrapped defensively:
    ANY failure degrades to "no watched filtering" instead of breaking
    roulette. We never call anything that could pop a login dialog — we
    gate on the authenticator's pure is_authorized (bool(access_token))
    and bail before touching sync if not authorized.
    """
    try:
        th = xbmcaddon.Addon('plugin.video.themoviedb.helper')
    except Exception:
        _log('TMDB Helper not installed; will not filter watched.')
        return None

    try:
        th_res = os.path.join(th.getAddonInfo('path'), 'resources')
        if th_res not in sys.path:
            sys.path.insert(0, th_res)
        from tmdbhelper.lib.api.trakt.api import TraktAPI

        trakt = TraktAPI()  # __init__ authorize() is non-forcing: no prompt
        # authenticator.is_authorized is a pure bool(access_token) read —
        # it never triggers ask_to_login(). Bail quietly if not connected.
        if not trakt.authenticator.is_authorized:
            _log('Trakt not authorized in TMDB Helper; will not filter watched.')
            return None

        syncdata = trakt.trakt_syncdata
        if syncdata is None:
            return None

        def is_watched(tmdb_id):
            # get_movie_playcount triggers a one-time watched sync on first
            # call (cached after), then reads play count keyed by TMDB id.
            try:
                return bool(syncdata.get_movie_playcount(int(tmdb_id)))
            except Exception:
                return False

        return is_watched

    except Exception as e:
        _log('Trakt watched-check unavailable ({0}); will not filter '
             'watched.'.format(e), xbmc.LOGWARNING)
        return None


# ----------------------------------------------------------------------
# Genre selection
# ----------------------------------------------------------------------

def _choose_genres(tmdb, preselect_ids=None):
    """
    Multiselect dialog over the TMDB movie genre list.
    Returns (genre_id_string, label_string) or (None, None) if cancelled.
    """
    options = tmdb.get_options('genre', 'movie')
    # Drop synthetic 'kw:' genre entries — those are TV-only keyword
    # stand-ins and don't belong in movie Discover with_genres.
    options = [o for o in (options or [])
               if not str(o.get('id', '')).startswith('kw:')]
    if not options:
        xbmcgui.Dialog().ok(
            ADDON_NAME,
            'Could not load genres from TMDB. Check your API key and '
            'connectivity, then try again.')
        return None, None

    preselect = []
    if preselect_ids:
        wanted = set(str(i) for i in preselect_ids)
        preselect = [i for i, o in enumerate(options) if str(o['id']) in wanted]

    labels = [o['label'] for o in options]
    chosen = xbmcgui.Dialog().multiselect(
        'Movie Roulette: pick genre(s)', labels, preselect=preselect)
    if not chosen:  # None (cancelled) or empty list
        return None, None

    picked = [options[i] for i in chosen]
    # OR across selected genres for a broad "any of these" pool.
    genre_ids = '|'.join(str(g['id']) for g in picked)
    genre_labels = ', '.join(g['label'] for g in picked)
    return genre_ids, genre_labels


def _remembered_genres():
    return (_HOME.getProperty(_GENRE_MEMO_KEY) or '',
            _HOME.getProperty(_GENRE_LABEL_KEY) or '')


def _remember_genres(genre_ids, genre_labels):
    _HOME.setProperty(_GENRE_MEMO_KEY, genre_ids or '')
    _HOME.setProperty(_GENRE_LABEL_KEY, genre_labels or '')


# ----------------------------------------------------------------------
# Candidate pool
# ----------------------------------------------------------------------

def _build_pool(tmdb, genre_ids, is_watched, progress=None):
    """
    Build a pool of unwatched candidate movies.

    Fetches page 1 once to learn total_pages, then pulls distinct random
    pages. The old version re-fetched page 1 on every attempt, costing
    two API calls per attempt and re-scanning the same 20 movies.
    """
    params = {
        'with_genres': genre_ids,          # '|' joined = OR on TMDB
        'sort_by': 'popularity.desc',
        'vote_count.gte': str(VOTE_COUNT_FLOOR),
        'include_adult': 'false',
    }

    first = tmdb.discover('movie', params, page=1)
    if not first or not first.get('results'):
        return []

    total_pages = min(int(first.get('total_pages') or 1), MAX_RANDOM_PAGE)

    pages = [first]
    if total_pages > 1:
        # Sample distinct pages so we don't fetch the same one twice.
        extra = random.sample(range(2, total_pages + 1),
                              min(MAX_PAGE_ATTEMPTS - 1, total_pages - 1))
        for p in extra:
            if progress and progress.iscanceled():
                break
            data = tmdb.discover('movie', params, page=p)
            if data and data.get('results'):
                pages.append(data)
            # Enough to pick from — stop early rather than burning calls.
            if sum(len(d.get('results') or []) for d in pages) >= TARGET_POOL * 2:
                break

    pool, seen = [], set()
    for data in pages:
        for r in data.get('results') or []:
            tid = r.get('id')
            if not tid or tid in seen:
                continue
            seen.add(tid)
            if is_watched and is_watched(tid):
                continue
            pool.append(r)

    _log('pool built: {0} unwatched from {1} page(s), total_pages={2}'.format(
        len(pool), len(pages), total_pages))
    return pool


# ----------------------------------------------------------------------
# Reveal dialog
# ----------------------------------------------------------------------

class RouletteWindow(xbmcgui.WindowXMLDialog):
    """
    Reveal card for a single spin. Sets window properties for the XML to
    render, and records which button the user pressed in self.result:
      'play' | 'trailer' | 'spin' | None (closed/cancelled)
    """

    # Populated by _show_reveal after construction. Custom kwargs are NOT
    # passed through the constructor: xbmcgui.WindowXMLDialog.__new__ takes
    # a fixed 4-arg signature and forwarding extra keywords through it is
    # unreliable across Kodi builds. Class-level defaults keep onInit safe
    # even if something goes wrong before the attributes are assigned.
    movie = {}
    genre_labels = ''
    pool_size = 0
    result = None

    def __init__(self, *args, **kwargs):
        super().__init__()

    def onInit(self):
        m = self.movie
        title = m.get('title') or m.get('name') or 'Unknown'
        date = m.get('release_date') or ''
        year = date[:4] if len(date) >= 4 and date[:4].isdigit() else ''

        rating = ''
        try:
            if m.get('vote_average'):
                rating = '{0:.1f}'.format(float(m['vote_average']))
        except (TypeError, ValueError):
            pass

        self.setProperty('title', title)
        self.setProperty('year', year)
        self.setProperty('rating', rating)
        self.setProperty('votes', str(m.get('vote_count') or ''))
        self.setProperty('plot', m.get('overview') or 'No synopsis available.')
        self.setProperty('genres', self.genre_labels)
        self.setProperty('pool', str(self.pool_size))
        self.setProperty(
            'poster', POSTER_BASE + m['poster_path'] if m.get('poster_path') else '')
        self.setProperty(
            'fanart', FANART_BASE + m['backdrop_path'] if m.get('backdrop_path') else '')

        # Trailer button is only useful if the addon is actually installed.
        try:
            xbmcaddon.Addon('script.mp.trailerfinder')
            self.setProperty('has_trailer', 'true')
        except Exception:
            self.setProperty('has_trailer', '')

        self.setFocusId(CTRL_PLAY)

    def onAction(self, action):
        if action.getId() in (xbmcgui.ACTION_PREVIOUS_MENU,
                              xbmcgui.ACTION_NAV_BACK):
            self.result = None
            self.close()

    def onClick(self, control_id):
        if control_id == CTRL_PLAY:
            self.result = 'play'
        elif control_id == CTRL_TRAILER:
            self.result = 'trailer'
        elif control_id == CTRL_SPIN:
            self.result = 'spin'
        elif control_id in (CTRL_CLOSE, CTRL_GENRES):
            self.result = 'genres' if control_id == CTRL_GENRES else None
        else:
            return
        self.close()


def _show_reveal(movie, genre_labels, pool_size):
    w = RouletteWindow('DialogRoulette.xml', ADDON_PATH, 'default', '1080i')
    w.movie = movie
    w.genre_labels = genre_labels
    w.pool_size = pool_size
    w.result = None
    w.doModal()
    result = w.result
    del w
    return result


# ----------------------------------------------------------------------
# Actions
# ----------------------------------------------------------------------

def _play(tmdb_id, label):
    """
    Hand off to MP SuperLite. CRITICAL: we must NOT start playback from
    inside this plugin invocation. SuperLite resolves via setResolvedUrl,
    and Kodi can't run that resolve until THIS invocation returns — but
    this invocation is what's trying to start playback. That deadlocks
    the GUI and SuperLite never even gets invoked (no [mpsuperlite] log).
    Neither PlayMedia nor Player().play() escapes this; the problem is the
    context, not the method.

    AlarmClock registers the command with Kodi's main application loop and
    returns immediately. Our invocation then unwinds, and ~1s later the
    PlayMedia fires from a clean main-loop context where SuperLite can
    resolve normally. (A background thread can't be used: Kodi blocks on
    plugin threads before ending the invocation, which keeps the deadlock.)
    """
    url = SUPERLITE_PLAY.format(tmdb_id)
    _log('handing off to SuperLite (deferred via AlarmClock): {0}'.format(url))
    xbmcgui.Dialog().notification(
        ADDON_NAME, 'Playing: {0}'.format(label),
        xbmcgui.NOTIFICATION_INFO, 3500)
    xbmc.executebuiltin(
        'AlarmClock(mpsroulette,PlayMedia({0}),00:01,silent)'.format(url))


def _play_trailer(tmdb_id):
    """
    Same deferral reasoning as _play: the trailer script ends in a
    PlayMedia, so it must not run while our modal is unwinding.
    """
    cmd = TRAILER_SCRIPT.format(tmdb_id)
    _log('launching trailer (deferred via AlarmClock): {0}'.format(cmd))
    xbmc.executebuiltin(
        'AlarmClock(mpstrailer,{0},00:01,silent)'.format(cmd))


# ----------------------------------------------------------------------
# Entry point
# ----------------------------------------------------------------------

def run():
    """
    Entry point for the roulette flow (called from the window button and
    from default.py's action=roulette route).

    The genre picker always opens on a fresh launch, but preselects last
    session's choice so re-spinning the same genres is one OK press.
    "Spin again" inside the reveal card doesn't re-prompt at all.
    """
    if not ADDON.getSetting('tmdb_api_key').strip():
        xbmcgui.Dialog().ok(ADDON_NAME,
                            'Set your TMDB API key in addon settings first.')
        return

    tmdb = TMDB()

    remembered_ids, _remembered_labels = _remembered_genres()
    genre_ids, genre_labels = _choose_genres(
        tmdb, preselect_ids=remembered_ids.split('|') if remembered_ids else None)
    if not genre_ids:
        return
    _remember_genres(genre_ids, genre_labels)

    is_watched = _get_trakt_watched_checker()
    pool = []

    while True:
        if not pool:
            progress = xbmcgui.DialogProgress()
            progress.create(ADDON_NAME, 'Spinning the reel...')
            try:
                pool = _build_pool(tmdb, genre_ids, is_watched, progress)
            finally:
                progress.close()

        if not pool:
            if is_watched is None:
                msg = ('No movies found for those genres. Check your TMDB '
                       'API key and connectivity.')
            else:
                msg = ('No unwatched movies left for those genres. '
                       'Try adding more genres.')
            if not xbmcgui.Dialog().yesno(ADDON_NAME, msg,
                                          yeslabel='Pick genres',
                                          nolabel='Close'):
                return
            genre_ids, genre_labels = _choose_genres(tmdb)
            if not genre_ids:
                return
            _remember_genres(genre_ids, genre_labels)
            continue

        # Draw without replacement so "Spin again" never repeats a title
        # within the session's pool.
        pick = pool.pop(random.randrange(len(pool)))
        title = pick.get('title') or pick.get('name') or 'Unknown'
        year = (pick.get('release_date') or '')[:4]
        label = '{0}{1}'.format(title, ' ({0})'.format(year) if year else '')

        _log('picked {0} tmdb_id={1} ({2} left in pool)'.format(
            label, pick.get('id'), len(pool)))

        action = _show_reveal(pick, genre_labels, len(pool) + 1)

        if action == 'play':
            _play(pick['id'], label)
            return
        if action == 'trailer':
            _play_trailer(pick['id'])
            return
        if action == 'spin':
            continue
        if action == 'genres':
            new_ids, new_labels = _choose_genres(
                tmdb, preselect_ids=genre_ids.split('|'))
            if new_ids:
                genre_ids, genre_labels = new_ids, new_labels
                _remember_genres(genre_ids, genre_labels)
                pool = []  # genres changed, rebuild
            continue
        return  # closed / cancelled
