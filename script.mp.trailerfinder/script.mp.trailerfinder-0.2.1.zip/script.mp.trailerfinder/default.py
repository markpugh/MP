# -*- coding: utf-8 -*-
"""
MP Trailer Finder — find a movie/TV trailer and play it via the YouTube addon.

Usage from Kodi context menu / skin.

  PREFERRED (exact, zero YouTube quota) — pass the TMDB id:
    RunScript(script.mp.trailerfinder, find, $INFO[ListItem.Property(tmdb_id)], movie)
    RunScript(script.mp.trailerfinder, find, $INFO[ListItem.Property(tmdb_id)], tv)

  FALLBACK (title based) — when no id is available:
    RunScript(script.mp.trailerfinder, findtitle, $INFO[ListItem.Title], $INFO[ListItem.Year], movie)
    RunScript(script.mp.trailerfinder, findtitle, $INFO[ListItem.TVShowTitle], , tv)

Lookup order:
  1. Local cache (30 day TTL for hits, 12 hour TTL for misses).
  2. TMDB /{type}/{id}/videos. This is ID keyed, so it cannot return a
     different movie's trailer, it costs nothing against YouTube's quota,
     and it is the studio's own registered trailer.
  3. If we only have a title, TMDB /search/{type} to resolve an id first,
     then step 2.
  4. YouTube Data API search as a last resort, scored and sanity checked
     rather than blindly taking result [0].

v0.2.0 changed the primary path from YouTube search to TMDB. v0.1.0
burned 100 quota units per lookup against a 10,000/day key, so roughly
100 trailers a day and then everything 403'd. It also matched on title
text, which is why remakes and reaction videos sometimes played instead
of the trailer. Both API keys are still baked in as defaults; TMDB just
means the YouTube quota is barely touched now.
"""
import json
import os
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs


ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')

TMDB_BASE = 'https://api.themoviedb.org/3'
YOUTUBE_API_URL = 'https://www.googleapis.com/youtube/v3/search'

# Baked-in personal keys. These are the owner's own keys and are kept as
# defaults so a fresh install works with nothing to configure. Both are
# overridable in settings if you ever need to swap them.
#
# The YouTube key is only touched on the search FALLBACK path now — the
# TMDB /videos lookup below handles the overwhelming majority of trailers
# at zero YouTube quota cost, which is the actual fix for the 403s.
#
# NOTE: keep the repo hosting this file PRIVATE. A public repo gets these
# scraped within hours and strangers drain the 10,000 unit daily quota,
# which is what makes trailers fail intermittently.
DEFAULT_YOUTUBE_API_KEY = 'AIzaSyCNonxVI7rm5y-qwFEmx9D-M2OwzHjH3CI'
DEFAULT_TMDB_API_KEY = '9b6d253a9ec18f3c1cab46a7b831de1a'

# Bump when the selection logic changes so stale picks get re-resolved
# instead of serving a bad cached video_id for another 30 days.
CACHE_VERSION = 2

CACHE_TTL_HIT = 30 * 24 * 60 * 60   # 30 days — trailers don't move once up
CACHE_TTL_MISS = 12 * 60 * 60       # 12 hours — don't burn a month on a blip
CACHE_MAX_ENTRIES = 5000

HTTP_TIMEOUT = 10

# Junk that outranks real trailers on YouTube relevance. Used only on the
# YouTube fallback path; TMDB results never need this.
_JUNK_PATTERNS = (
    'reaction', 'review', 'breakdown', 'explained', 'analysis',
    'fan made', 'fanmade', 'fan-made', 'concept trailer', 'parody',
    'recut', 'honest trailer', 'everything wrong', 'ending explained',
    'top 10', 'first look at', 'behind the scenes',
)

# Alternate cuts of the real trailer that studios also register on TMDB:
# accessibility versions, dubs, and territory variants. All legitimate,
# but not what you want when you press "play trailer" — they otherwise
# tie with the standard cut and win on list order.
_VARIANT_PATTERNS = (
    'sign language', 'asl', 'basl', 'audio description', 'described',
    'subtitled', 'subtitle', 'dubbed', 'dub)', 'latino', 'espanol',
    'español', 'legendado', 'dublado', 'vostfr', 'sous-titr',
)


# ----------------------------------------------------------------------
# Small helpers
# ----------------------------------------------------------------------

def _log(msg, level=xbmc.LOGINFO):
    xbmc.log('[{0}] {1}'.format(ADDON_ID, msg), level=level)


def _setting(key, default=''):
    try:
        return (ADDON.getSetting(key) or '').strip() or default
    except Exception:
        return default


def _tmdb_api_key():
    """
    TMDB key, in priority order:
      1. This addon's own setting (lets you override per install)
      2. Whatever MP SuperSearch is already configured with
      3. The baked-in default
    """
    key = _setting('tmdb_api_key')
    if key:
        return key
    try:
        key = (xbmcaddon.Addon('plugin.video.mpsupersearch')
               .getSetting('tmdb_api_key') or '').strip()
        if key:
            return key
    except Exception:
        pass
    return DEFAULT_TMDB_API_KEY


def _youtube_api_key():
    """YouTube key: addon setting if set, otherwise the baked-in default."""
    return _setting('youtube_api_key') or DEFAULT_YOUTUBE_API_KEY


def _tmdb_language():
    lang = _setting('tmdb_language')
    if lang:
        return lang
    try:
        return (xbmcaddon.Addon('plugin.video.mpsupersearch')
                .getSetting('language') or 'en-US').strip() or 'en-US'
    except Exception:
        return 'en-US'


def _normalize(text):
    """Lowercase, strip punctuation, collapse whitespace. For title matching."""
    if not text:
        return ''
    text = re.sub(r'[^\w\s]', ' ', str(text).lower())
    return re.sub(r'\s+', ' ', text).strip()


def _get_json(url, sanitize=None):
    """GET + parse JSON. Returns (data, http_status). data is None on failure."""
    display = url.replace(sanitize, '***') if sanitize else url
    _log('GET {0}'.format(display))
    try:
        req = urllib.request.Request(url, headers={
            'User-Agent': '{0}/{1}'.format(ADDON_ID, ADDON.getAddonInfo('version')),
            'Accept': 'application/json',
        })
        with urllib.request.urlopen(req, timeout=HTTP_TIMEOUT) as resp:
            return json.loads(resp.read().decode('utf-8')), resp.status
    except urllib.error.HTTPError as e:
        body = ''
        try:
            body = e.read().decode('utf-8')[:300]
        except Exception:
            pass
        _log('HTTP {0} for {1}: {2}'.format(e.code, display, body), xbmc.LOGERROR)
        return None, e.code
    except Exception as e:
        _log('Request failed for {0}: {1}'.format(display, e), xbmc.LOGERROR)
        return None, 0


# ----------------------------------------------------------------------
# Cache
# ----------------------------------------------------------------------

def _cache_path():
    profile = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    if not os.path.isdir(profile):
        os.makedirs(profile, exist_ok=True)
    return os.path.join(profile, 'trailer_cache.json')


def _load_cache():
    p = _cache_path()
    if not os.path.isfile(p):
        return {}
    try:
        with open(p, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        _log('Cache load failed (rebuilding): {0}'.format(e), xbmc.LOGWARNING)
        return {}


def _save_cache(cache):
    if len(cache) > CACHE_MAX_ENTRIES:
        items = sorted(cache.items(), key=lambda kv: kv[1].get('ts', 0))
        cache = dict(items[len(items) - CACHE_MAX_ENTRIES:])
    try:
        with open(_cache_path(), 'w', encoding='utf-8') as f:
            json.dump(cache, f)
    except Exception as e:
        _log('Cache save failed: {0}'.format(e), xbmc.LOGWARNING)


def _cache_key(kind, ident):
    return 'v{0}|{1}|{2}'.format(CACHE_VERSION, kind, ident)


def _cache_get(cache, key):
    """
    Returns (found, video_id). found=True with video_id=None means a
    cached MISS that hasn't expired yet, so don't re-hit the network.
    """
    entry = cache.get(key)
    if not entry:
        return False, None
    video_id = entry.get('video_id')
    ttl = CACHE_TTL_HIT if video_id else CACHE_TTL_MISS
    if time.time() - entry.get('ts', 0) > ttl:
        return False, None
    return True, video_id


def _cache_put(cache, key, video_id):
    cache[key] = {'video_id': video_id, 'ts': int(time.time())}


# ----------------------------------------------------------------------
# TMDB — the primary path
# ----------------------------------------------------------------------

def _tmdb_videos(tmdb_type, tmdb_id, api_key, language):
    """
    Fetch the video list for a TMDB id. Tries the user's language first,
    then falls back to an unfiltered call — TMDB filters /videos by
    language, and plenty of titles only have their trailer registered
    under a different locale, which used to read as "no trailer found".
    """
    endpoint = '{0}/{1}/{2}/videos'.format(TMDB_BASE, tmdb_type, tmdb_id)

    attempts = [{'api_key': api_key, 'language': language},
                {'api_key': api_key}]
    for params in attempts:
        url = endpoint + '?' + urllib.parse.urlencode(params)
        data, _status = _get_json(url, sanitize=api_key)
        results = (data or {}).get('results') or []
        if results:
            return results
    return []


def _score_tmdb_video(v, language):
    """
    Rank TMDB video entries. Higher is better; None means unusable.

    TMDB returns teasers, clips, featurettes and behind-the-scenes in the
    same list, often with the teaser first. Taking [0] is how you end up
    playing a 12 second teaser instead of the trailer.
    """
    if (v.get('site') or '').lower() != 'youtube':
        return None
    if not v.get('key'):
        return None

    vtype = (v.get('type') or '').lower()
    name = (v.get('name') or '').lower()

    type_scores = {'trailer': 100, 'teaser': 60, 'clip': 20, 'featurette': 10}
    score = type_scores.get(vtype)
    if score is None:
        return None  # behind the scenes, bloopers, etc.

    if v.get('official'):
        score += 30
    if 'official trailer' in name:
        score += 25
    elif 'trailer' in name:
        score += 10
    # "Final Trailer" / "Main Trailer" are usually a better cut than teaser 1
    if re.search(r'\b(final|main)\b', name):
        score += 8

    # Demote accessibility and localised variants below the standard cut.
    # Big enough to lose a tie, small enough that a variant still wins if
    # it's the only trailer registered.
    if any(p in name for p in _VARIANT_PATTERNS):
        score -= 45

    # Prefer the user's language, then English, then anything.
    iso = (v.get('iso_639_1') or '').lower()
    want = (language or 'en-US').split('-')[0].lower()
    if iso == want:
        score += 15
    elif iso == 'en':
        score += 8

    try:
        if int(v.get('size') or 0) >= 1080:
            score += 5
    except (TypeError, ValueError):
        pass

    return score


def _pick_tmdb_video(videos, language):
    best, best_score = None, None
    for v in videos:
        s = _score_tmdb_video(v, language)
        if s is None:
            continue
        if best_score is None or s > best_score:
            best, best_score = v, s
    if not best:
        return None
    _log('TMDB pick: {0!r} type={1} official={2} score={3} key={4}'.format(
        (best.get('name') or '')[:70], best.get('type'),
        best.get('official'), best_score, best.get('key')))
    return best.get('key')


def _tmdb_resolve_id(title, year, tmdb_type, api_key, language):
    """Title -> TMDB id, for the fallback path where no id was passed in."""
    params = {'api_key': api_key, 'language': language,
              'query': title, 'include_adult': 'false'}
    if year:
        params['year' if tmdb_type == 'movie' else 'first_air_date_year'] = str(year)

    url = '{0}/search/{1}?{2}'.format(
        TMDB_BASE, tmdb_type, urllib.parse.urlencode(params))
    data, _status = _get_json(url, sanitize=api_key)
    results = (data or {}).get('results') or []

    # Retry without the year — a title whose Kodi year is off by one
    # (release vs. air vs. region) otherwise returns nothing at all.
    if not results and year:
        params.pop('year', None)
        params.pop('first_air_date_year', None)
        url = '{0}/search/{1}?{2}'.format(
            TMDB_BASE, tmdb_type, urllib.parse.urlencode(params))
        data, _status = _get_json(url, sanitize=api_key)
        results = (data or {}).get('results') or []

    if not results:
        return None

    wanted = _normalize(title)
    exact = next((r for r in results
                  if _normalize(r.get('title') or r.get('name')) == wanted), None)
    pick = exact or results[0]
    _log('TMDB resolved {0!r} -> id={1} ({2})'.format(
        title, pick.get('id'), pick.get('title') or pick.get('name')))
    return pick.get('id')


def _tmdb_resolve_multi(title, year, api_key, language):
    """
    Resolve a bare title to (tmdb_type, tmdb_id) without being told whether
    it's a film or a show.

    The skin's context menu only hands us ListItem.Title and ListItem.Year,
    which could be either. /search/multi sorts that out in one call, and
    means a TV entry no longer gets searched against the movie endpoint and
    silently missed.
    """
    params = {'api_key': api_key, 'language': language,
              'query': title, 'include_adult': 'false'}
    url = '{0}/search/multi?{1}'.format(TMDB_BASE, urllib.parse.urlencode(params))
    data, _status = _get_json(url, sanitize=api_key)
    results = [r for r in ((data or {}).get('results') or [])
               if r.get('media_type') in ('movie', 'tv')]
    if not results:
        return None, None

    wanted = _normalize(title)

    def rank(r):
        name = _normalize(r.get('title') or r.get('name'))
        date = r.get('release_date') or r.get('first_air_date') or ''
        score = 0
        if name == wanted:
            score += 100
        elif wanted and wanted in name:
            score += 40
        # Year is a weak signal here: for an episode row the skin gives us
        # the episode's year, not the show's, so treat it as a tiebreak.
        if year and date[:4] == str(year):
            score += 10
        score += min(int(r.get('popularity') or 0), 50) / 100.0
        return score

    pick = max(results, key=rank)
    _log('TMDB multi resolved {0!r} -> {1} id={2} ({3})'.format(
        title, pick.get('media_type'), pick.get('id'),
        pick.get('title') or pick.get('name')))
    return pick.get('media_type'), pick.get('id')


# ----------------------------------------------------------------------
# YouTube Data API — fallback only, user's own key
# ----------------------------------------------------------------------

def _youtube_search(title, year):
    """
    Last resort when TMDB has no registered trailer.

    Cost: 100 units per call against a 10,000/day quota. In v0.1.0 this
    was the ONLY path, so ~100 lookups a day exhausted it and everything
    started 403ing. It's now reached only when TMDB has nothing, which is
    rare, so the quota stops being the bottleneck.

    Scored across a pool of 10, not blindly [0].
    """
    key = _youtube_api_key()
    if not key:
        _log('No YouTube API key configured; skipping search fallback.')
        return None

    query = ' '.join(p for p in (title, str(year or ''), 'official trailer') if p)
    params = {
        'part': 'snippet',
        'q': query,
        'type': 'video',
        'maxResults': '10',      # score a pool instead of trusting rank 1
        'safeSearch': 'none',
        'order': 'relevance',
        'key': key,
    }
    # NOTE: videoEmbeddable=true is deliberately NOT set. Plenty of studio
    # trailers disable embedding, and filtering on it was silently hiding
    # legitimate results. plugin.video.youtube's /play/ route plays them fine.

    url = YOUTUBE_API_URL + '?' + urllib.parse.urlencode(params)
    data, status = _get_json(url, sanitize=key)

    if data is None:
        if status == 403:
            xbmcgui.Dialog().notification(
                ADDON_NAME, 'YouTube quota exhausted or key rejected.',
                xbmcgui.NOTIFICATION_WARNING, 4000)
        return None

    items = data.get('items') or []
    if not items:
        _log('YouTube returned 0 results for {0!r}'.format(query))
        return None

    wanted = _normalize(title)
    best, best_score = None, -1
    for it in items:
        vid = (it.get('id') or {}).get('videoId')
        if not vid:
            continue
        snip = it.get('snippet') or {}
        name = (snip.get('title') or '')
        low = name.lower()

        if any(j in low for j in _JUNK_PATTERNS):
            continue
        # The result must actually name the thing we asked for.
        if wanted and wanted not in _normalize(name):
            continue

        score = 0
        if 'official trailer' in low:
            score += 40
        elif 'trailer' in low:
            score += 20
        if 'teaser' in low:
            score += 5
        if year and str(year) in name:
            score += 5
        # Studio channels self-identify far more reliably than any
        # channel-id allowlist we could maintain.
        channel = (snip.get('channelTitle') or '').lower()
        if any(w in channel for w in ('pictures', 'studios', 'films', 'movies',
                                      'entertainment', 'trailers')):
            score += 15

        if score > best_score:
            best, best_score = vid, score

    if not best:
        _log('YouTube results all rejected as junk for {0!r}'.format(query))
        return None

    _log('YouTube fallback pick: {0} (score {1})'.format(best, best_score))
    return best


# ----------------------------------------------------------------------
# Playback
# ----------------------------------------------------------------------

def _youtube_addon_installed():
    try:
        xbmcaddon.Addon('plugin.video.youtube')
        return True
    except Exception:
        return False


def _play_video(video_id):
    """
    Hand off to plugin.video.youtube. incognito=true keeps trailer plays
    out of the user's YouTube watch history and out of Kodi's resume
    points, which is what you want for a 2 minute trailer.
    """
    url = ('plugin://plugin.video.youtube/play/'
           '?video_id={0}&incognito=true'.format(video_id))
    _log('Playing: {0}'.format(url))
    xbmc.executebuiltin('PlayMedia({0})'.format(url))


# ----------------------------------------------------------------------
# Orchestration
# ----------------------------------------------------------------------

def _resolve_video_id(tmdb_type, tmdb_id, title, year, cache):
    """
    Returns (video_id_or_None, cache_key_or_None). cache_key is None when
    there was nothing stable to key on.
    """
    api_key = _tmdb_api_key()
    language = _tmdb_language()

    # --- id path -------------------------------------------------------
    if tmdb_id:
        key = _cache_key(tmdb_type, tmdb_id)
        found, vid = _cache_get(cache, key)
        if found:
            _log('Cache {0} for {1}'.format('hit' if vid else 'miss', key))
            return vid, key
        if api_key:
            videos = _tmdb_videos(tmdb_type, tmdb_id, api_key, language)
            vid = _pick_tmdb_video(videos, language)
            if vid:
                return vid, key
            _log('TMDB has no usable trailer for {0}/{1}'.format(tmdb_type, tmdb_id),
                 xbmc.LOGWARNING)
        else:
            _log('No TMDB API key set; cannot use the ID path.', xbmc.LOGWARNING)
        # fall through to the title based fallback
    else:
        key = _cache_key('q', '{0}|{1}|{2}'.format(
            _normalize(title), year or '', tmdb_type))
        found, vid = _cache_get(cache, key)
        if found:
            _log('Cache {0} for {1}'.format('hit' if vid else 'miss', key))
            return vid, key

    if not title:
        return None, key

    # --- title -> TMDB id -> videos -------------------------------------
    if api_key and not tmdb_id:
        if tmdb_type:
            resolved_type = tmdb_type
            resolved = _tmdb_resolve_id(title, year, tmdb_type, api_key, language)
        else:
            # Caller didn't say movie or tv (the skin context menu can't
            # know). Let TMDB decide from the title itself.
            resolved_type, resolved = _tmdb_resolve_multi(
                title, year, api_key, language)
        if resolved:
            videos = _tmdb_videos(resolved_type, resolved, api_key, language)
            vid = _pick_tmdb_video(videos, language)
            if vid:
                return vid, key

    # --- YouTube search fallback ----------------------------------------
    return _youtube_search(title, year), key


def find_and_play(tmdb_type=None, tmdb_id=None, title='', year=None):
    # tmdb_type None means "unknown, work it out from the title".
    if tmdb_type not in ('movie', 'tv', None):
        tmdb_type = None
    if tmdb_id and not tmdb_type:
        tmdb_type = 'movie'  # an id is meaningless without a type
    title = (title or '').strip()
    year = (str(year).strip() or None) if year else None

    if not tmdb_id and not title:
        xbmcgui.Dialog().notification(
            ADDON_NAME, 'Nothing to search for',
            xbmcgui.NOTIFICATION_WARNING, 3000)
        return

    if not _youtube_addon_installed():
        xbmcgui.Dialog().ok(
            ADDON_NAME,
            'The YouTube addon (plugin.video.youtube) is not installed. '
            'Install it, then try again.')
        return

    # Safety net only — both keys have baked-in defaults, so this fires
    # solely if someone deliberately blanks them in settings.
    if not _tmdb_api_key() and not _youtube_api_key():
        xbmcgui.Dialog().ok(
            ADDON_NAME,
            'Both API keys have been cleared in settings. Restore at least '
            'the TMDB key to look up trailers.')
        ADDON.openSettings()
        return

    cache = _load_cache()
    busy = xbmcgui.DialogProgressBG()
    busy.create(ADDON_NAME, 'Finding trailer...')
    try:
        video_id, cache_key = _resolve_video_id(
            tmdb_type, tmdb_id, title, year, cache)
    finally:
        try:
            busy.close()
        except Exception:
            pass

    if cache_key:
        # Cache misses too, on a short TTL, so a title with genuinely no
        # trailer doesn't re-hit the network on every single click.
        _cache_put(cache, cache_key, video_id)
        _save_cache(cache)

    if not video_id:
        xbmcgui.Dialog().notification(
            ADDON_NAME, 'No trailer found',
            xbmcgui.NOTIFICATION_INFO, 3000)
        return

    _play_video(video_id)


def clear_cache():
    try:
        p = _cache_path()
        if os.path.isfile(p):
            os.remove(p)
        xbmcgui.Dialog().notification(
            ADDON_NAME, 'Trailer cache cleared',
            xbmcgui.NOTIFICATION_INFO, 2500)
    except Exception as e:
        _log('Cache clear failed: {0}'.format(e), xbmc.LOGERROR)


def _normalize_type(value):
    """Map anything the skin might hand us onto 'movie', 'tv', or None."""
    v = (value or '').strip().lower()
    if v in ('movie', 'movies', 'film'):
        return 'movie'
    if v in ('tv', 'tvshow', 'tvshows', 'show', 'season', 'episode'):
        return 'tv'
    return None


def _parse_args(args):
    """
    Accept three calling conventions, because the skin context menu in the
    wild predates the others and re-patching every install is not something
    to rely on:

      1. keyword:  find, title=X, year=Y, dbtype=Z, tvshowtitle=W
      2. by id:    find, <tmdb_id>, <movie|tv>
      3. legacy:   find, <title>, <year>          <- what MP Build patches
                                                     into Arctic Fuse today

    Returns a dict with tmdb_id / tmdb_type / title / year.
    """
    out = {'tmdb_id': None, 'tmdb_type': None, 'title': '', 'year': ''}

    kw = {}
    pos = []
    for a in args:
        if '=' in a and not a.split('=', 1)[0].strip().isdigit():
            k, v = a.split('=', 1)
            kw[k.strip().lower()] = v.strip()
        else:
            pos.append(a.strip())

    if kw:
        out['tmdb_type'] = _normalize_type(kw.get('tmdb_type') or kw.get('dbtype'))
        tid = (kw.get('tmdb_id') or '').strip()
        out['tmdb_id'] = tid if tid.isdigit() else None
        # For a series, the show title is the right query; the episode's own
        # title and year would both send the search off course.
        if out['tmdb_type'] == 'tv' and kw.get('tvshowtitle'):
            out['title'] = kw['tvshowtitle']
        else:
            out['title'] = kw.get('title', '')
            out['year'] = kw.get('year', '')
        return out

    if pos and pos[0].isdigit():
        # Convention 2: an id, optionally with its type.
        out['tmdb_id'] = pos[0]
        out['tmdb_type'] = _normalize_type(pos[1] if len(pos) > 1 else '') or 'movie'
        return out

    # Convention 3: title, then year, then possibly a type.
    out['title'] = pos[0] if pos else ''
    if len(pos) > 1 and pos[1].isdigit() and len(pos[1]) == 4:
        out['year'] = pos[1]
        out['tmdb_type'] = _normalize_type(pos[2] if len(pos) > 2 else '')
    else:
        out['tmdb_type'] = _normalize_type(pos[1] if len(pos) > 1 else '')
    return out


def main():
    args = [a for a in sys.argv[1:]]
    if not args:
        xbmcgui.Dialog().ok(
            ADDON_NAME,
            'This addon is invoked from the Kodi context menu. '
            'Direct invocation is not supported.')
        return

    action = args[0]

    if action in ('find', 'findtitle'):
        p = _parse_args(args[1:])
        _log('{0} -> tmdb_id={1!r} type={2!r} title={3!r} year={4!r}'.format(
            action, p['tmdb_id'], p['tmdb_type'], p['title'], p['year']))
        find_and_play(tmdb_type=p['tmdb_type'], tmdb_id=p['tmdb_id'],
                      title=p['title'], year=p['year'])

    elif action == 'clearcache':
        clear_cache()

    else:
        _log('Unknown action: {0!r}'.format(action), xbmc.LOGWARNING)


if __name__ == '__main__':
    main()
