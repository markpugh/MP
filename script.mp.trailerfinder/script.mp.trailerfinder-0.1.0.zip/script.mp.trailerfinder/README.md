# MP Trailer Finder

Lightweight Kodi addon that finds and plays movie/TV trailers directly from YouTube.

Used by MP Build's context-menu integration to provide always-available trailer playback regardless of TMDb metadata coverage.

## Features

- Finds the official trailer for any movie or TV show via YouTube Data API v3
- Plays the trailer at highest available quality through the standard YouTube addon
- 30-day local cache to minimize API quota usage
- Bypasses SafeSearch (requires the YouTube addon to be signed in for age-restricted content)

## Usage

Invoke from a Kodi context menu or skin shortcut:

```
RunScript(script.mp.trailerfinder, find, ${title}, ${year})
```

For TV shows, pass the show title (not the episode title):

```
RunScript(script.mp.trailerfinder, find, ${tvshow_title}, ${year})
```

## Requirements

- `plugin.video.youtube` installed and signed in
- For age-restricted (red-band) trailers, the YouTube account must be 18+ verified
