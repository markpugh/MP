# -*- coding: utf-8 -*-
"""
MP Trailer Finder — find a movie/TV trailer on YouTube and play it.

Usage from Kodi context menu:
    RunScript(script.mp.trailerfinder, find, $INFO[ListItem.Title], $INFO[ListItem.Year])

For TV episodes/seasons (where the show title is the right query, not episode title):
    RunScript(script.mp.trailerfinder, find, $INFO[ListItem.TVShowTitle], $INFO[ListItem.Year])

Workflow:
  1. Build query: "{title} {year} official trailer"
  2. Check 30-day local cache for previous lookups
  3. If miss: hit YouTube Data API v3 with safeSearch=none
  4. Pick the first result video_id
  5. Play via plugin://plugin.video.youtube/play/?video_id=XXX

The local cache is critical for quota management — at 100 units per
search.list call against a 10000/day free quota, that's only 100 unique
trailer searches per day across all users sharing the key. Cached hits
are 0 quota.
"""
import json
import os
import sys
import time
import urllib.parse
import urllib.request

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs


ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')

# YouTube Data API v3 key. Restricted to YouTube Data API v3 only in
# Google Cloud console — worst case if this leaks is someone burning
# the daily quota, can't be used for billable services.
YOUTUBE_API_KEY = 'AIzaSyCNonxVI7rm5y-qwFEmx9D-M2OwzHjH3CI'
YOUTUBE_API_URL = 'https://www.googleapis.com/youtube/v3/search'

# Cache TTL: 30 days. Trailers don't move once they're up; this keeps
# repeat searches free against the daily quota.
CACHE_TTL_SECONDS = 30 * 24 * 60 * 60


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log('[{0}] {1}'.format(ADDON_ID, msg), level=level)


def _cache_path():
    """Per-user cache file for title → video_id mappings."""
    profile = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    if not os.path.isdir(profile):
        os.makedirs(profile)
    return os.path.join(profile, 'trailer_cache.json')


def _load_cache():
    p = _cache_path()
    if not os.path.isfile(p):
        return {}
    try:
        with open(p, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        _log('Cache load failed (will rebuild): {0}'.format(e), xbmc.LOGWARNING)
        return {}


def _save_cache(cache):
    """
    Save cache, but cap at 5000 entries to prevent unbounded growth.
    When over cap, drop the 1000 oldest entries by timestamp.
    """
    if len(cache) > 5000:
        # Sort by ts ascending, drop oldest 1000
        items = sorted(cache.items(), key=lambda kv: kv[1].get('ts', 0))
        cache = dict(items[1000:])
    try:
        with open(_cache_path(), 'w', encoding='utf-8') as f:
            json.dump(cache, f)
    except Exception as e:
        _log('Cache save failed: {0}'.format(e), xbmc.LOGWARNING)


def _cache_get(cache, key):
    """Returns the cached video_id or None if missing/expired."""
    entry = cache.get(key)
    if not entry:
        return None
    if time.time() - entry.get('ts', 0) > CACHE_TTL_SECONDS:
        return None
    return entry.get('video_id')


def _cache_put(cache, key, video_id):
    cache[key] = {'video_id': video_id, 'ts': int(time.time())}


def _build_query(title, year):
    """
    Construct the YouTube search query. Format chosen empirically — for
    movies, "{title} {year} official trailer" returns the studio
    upload as the first result >95% of the time. Including the year
    helps disambiguate remakes (e.g. "Dune 1984" vs "Dune 2021").
    """
    parts = [title.strip()]
    if year:
        parts.append(str(year).strip())
    parts.append('official trailer')
    return ' '.join(parts)


def _youtube_search(query):
    """
    Hit YouTube Data API v3 search.list endpoint. Returns the top
    video_id or None on any failure.

    Cost: 100 quota units per call. Free tier is 10000/day = ~100
    uncached searches per day across the whole shared key.
    """
    params = {
        'part': 'snippet',
        'q': query,
        'type': 'video',
        'maxResults': '1',
        'safeSearch': 'none',          # don't filter age-restricted results
        'videoEmbeddable': 'true',     # only embeddable = playable in third-party players
        'order': 'relevance',
        'key': YOUTUBE_API_KEY,
    }
    url = YOUTUBE_API_URL + '?' + urllib.parse.urlencode(params)
    _log('Querying YouTube API for: {0!r}'.format(query))

    try:
        req = urllib.request.Request(url, headers={
            'User-Agent': '{0}/0.1.0'.format(ADDON_ID),
            'Accept': 'application/json',
        })
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode('utf-8'))
    except urllib.error.HTTPError as e:
        # Common HTTPErrors:
        #   403: quota exhausted, or key disabled, or daily limit
        #   400: bad request (shouldn't happen with our params)
        body = ''
        try:
            body = e.read().decode('utf-8')[:300]
        except Exception:
            pass
        _log('YouTube API HTTPError {0}: {1}'.format(e.code, body), xbmc.LOGERROR)
        if e.code == 403:
            xbmcgui.Dialog().notification(
                ADDON_NAME,
                'YouTube quota exhausted — try again tomorrow.',
                xbmcgui.NOTIFICATION_WARNING, 4000)
        return None
    except Exception as e:
        _log('YouTube API failed: {0}'.format(e), xbmc.LOGERROR)
        return None

    items = data.get('items') or []
    if not items:
        _log('YouTube API returned 0 results for {0!r}'.format(query))
        return None

    first = items[0]
    video_id = (first.get('id') or {}).get('videoId')
    title = (first.get('snippet') or {}).get('title') or '(unknown)'
    _log('Top result: {0!r} (id={1})'.format(title[:80], video_id))
    return video_id


def _play_video(video_id):
    """
    Hand off to plugin.video.youtube for direct playback at highest
    available quality (the YouTube addon picks the best stream based
    on its own settings).
    """
    play_url = 'plugin://plugin.video.youtube/play/?video_id={0}'.format(video_id)
    _log('Playing: {0}'.format(play_url))
    xbmc.executebuiltin('PlayMedia({0})'.format(play_url))


def _youtube_addon_installed():
    """Confirm plugin.video.youtube is present before trying to use it."""
    try:
        xbmcaddon.Addon('plugin.video.youtube')
        return True
    except Exception:
        return False


def find_and_play(title, year=None):
    """
    Main entry point. Find a trailer for {title} ({year}) and play it.
    Shows a brief notification on failure so the user isn't left
    staring at a frozen menu wondering what happened.
    """
    if not title or not title.strip():
        xbmcgui.Dialog().notification(
            ADDON_NAME, 'No title to search', xbmcgui.NOTIFICATION_WARNING, 3000)
        return

    if not _youtube_addon_installed():
        xbmcgui.Dialog().ok(
            ADDON_NAME,
            'YouTube addon (plugin.video.youtube) is not installed. '
            'Please install it from the Kodi addon repository, then sign '
            'in to your Google account to enable trailer playback.')
        return

    query = _build_query(title, year)
    cache = _load_cache()

    # Cache lookup
    video_id = _cache_get(cache, query)
    if video_id:
        _log('Cache hit for {0!r}'.format(query))
        _play_video(video_id)
        return

    # Cache miss — hit the API
    xbmcgui.Dialog().notification(
        ADDON_NAME, 'Finding trailer…',
        xbmcgui.NOTIFICATION_INFO, 1500)

    video_id = _youtube_search(query)
    if not video_id:
        xbmcgui.Dialog().notification(
            ADDON_NAME, 'No trailer found on YouTube',
            xbmcgui.NOTIFICATION_INFO, 3000)
        return

    # Cache the result and play
    _cache_put(cache, query, video_id)
    _save_cache(cache)
    _play_video(video_id)


def main():
    args = sys.argv[1:]
    if not args:
        xbmcgui.Dialog().ok(
            ADDON_NAME,
            'This addon is invoked from the Kodi context menu. '
            'Direct invocation is not supported.')
        return

    action = args[0]
    if action == 'find':
        title = args[1] if len(args) > 1 else ''
        year = args[2] if len(args) > 2 else ''
        find_and_play(title, year)
    else:
        _log('Unknown action: {0!r}'.format(action), xbmc.LOGWARNING)


if __name__ == '__main__':
    main()
